#!/usr/bin/env python3
import csv, re, time, sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests
from bs4 import BeautifulSoup

INDEX = "https://gamewith.jp/terrysp/article/show/131758"
OUT = Path("app/src/main/assets/monsters.csv")
HEADERS = {"User-Agent": "Mozilla/5.0 (Android app data build; educational/personal use)"}
session = requests.Session()
session.headers.update(HEADERS)

def get(url, tries=4):
    last=None
    for i in range(tries):
        try:
            r=session.get(url, timeout=20)
            r.raise_for_status()
            return r.text
        except Exception as e:
            last=e
            time.sleep(1.5*(i+1))
    raise last

def index_links(html):
    soup=BeautifulSoup(html,"html.parser")
    out={}
    # GameWith's figure page links each monster name to its individual article.
    for a in soup.find_all("a", href=True):
        text=" ".join(a.get_text(" ", strip=True).split())
        href=a["href"]
        if not text or "/terrysp/article/show/" not in href:
            continue
        m=re.search(r'(\d{3})$', href.rstrip("/"))
        # Do not trust the article id; use the nearby No. table where possible.
        # For robustness, collect all monster-looking links and later map by individual page No.
        if len(text) <= 30:
            url = href if href.startswith("http") else "https://gamewith.jp"+href
            out[url]=text
    return out

def parse_page(url, anchor_name):
    html=get(url)
    txt=" ".join(BeautifulSoup(html,"html.parser").get_text(" ", strip=True).split())
    mno=re.search(r"図鑑No\.\s*(\d+)",txt)
    rank=re.search(r"\b(SS|S|A|B|C|D|E|F)ランク\b",txt)
    size=re.search(r"\b([SMG])サイズ\b",txt)
    fam=re.search(r"(スライム|ドラゴン|自然|魔獣|物質|悪魔|ゾンビ|？？？)系統",txt)
    if not (mno and rank and size and fam):
        raise RuntimeError(f"metadata parse failed: {url} / {anchor_name}")
    return int(mno.group(1)), anchor_name, rank.group(1), fam.group(1), size.group(1), url

def main():
    html=get(INDEX)
    links=index_links(html)
    # The page includes navigation links to category pages. Keep only links whose text
    # matches a known monster name by validating individual pages. We also dedupe by URL.
    print(f"Candidate links: {len(links)}")
    rows=[]
    errors=[]
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs={ex.submit(parse_page,u,n):(u,n) for u,n in links.items()}
        for fut in as_completed(futs):
            u,n=futs[fut]
            try:
                rows.append(fut.result())
            except Exception as e:
                errors.append(str(e))
    by_no={r[0]:r for r in rows}
    if len(by_no) < 659:
        # The index may include only visible links in some renderings. Fail loudly rather than ship partial data.
        print(f"Parsed unique monster records: {len(by_no)}")
        print("Errors:", len(errors))
        for e in errors[:20]: print(e)
        sys.exit("Could not obtain all 659 GameWith monster records.")
    rows=[by_no[i] for i in range(1,660)]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.writer(f); w.writerow(["no","name","rank","family","size"])
        for no,name,rank,fam,size,url in rows:
            w.writerow([no,name,rank,fam,size])
    print("Wrote",OUT,"records:",len(rows))
    print("Sample:", rows[:3], rows[-1])

if __name__=="__main__":
    main()
