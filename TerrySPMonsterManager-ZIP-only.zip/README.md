# TerrySPMonsterManager

シンプルな Android / Gradle プロジェクトです。

- `app/` — Android アプリ
- `gradle/wrapper/` — Gradle Wrapper
- `build.gradle.kts` — ルート設定
- `settings.gradle.kts` — プロジェクト設定
- `gradlew` / `gradlew.bat` — Gradle Wrapper
- `.github/workflows/build-apk.yml` — GitHub Actions

GitHub Actions はリポジトリ直下から直接 `./gradlew :app:assembleDebug` を実行し、
`app-debug.apk` を Artifact としてアップロードします。


## Monster data generation

`app/src/main/assets/monsters.csv` is generated during GitHub Actions by
`tools/scrape_gamewith.py`. The workflow validates that 659 monster records
were generated before starting the Android build.

This is required because the app displays the contents of `monsters.csv`;
an empty/header-only CSV results in `図鑑 0体` and an empty list.
