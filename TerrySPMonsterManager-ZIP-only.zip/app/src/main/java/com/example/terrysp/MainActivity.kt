package com.example.terrysp

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

data class Monster(val no:Int,val name:String,val rank:String,val family:String,val size:String)

class MainActivity : Activity() {
    private lateinit var search: EditText
    private lateinit var rank: Spinner
    private lateinit var family: Spinner
    private lateinit var size: Spinner
    private lateinit var onlyUnowned: CheckBox
    private lateinit var list: LinearLayout
    private lateinit var stats: TextView
    private val monsters = mutableListOf<Monster>()
    private val pref by lazy { getSharedPreferences("monster_state", MODE_PRIVATE) }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        loadData()
        buildUi()
        refresh()
    }

    private fun loadData() {
        monsters.clear()
        BufferedReader(InputStreamReader(assets.open("monsters.csv"), StandardCharsets.UTF_8)).useLines { seq ->
            seq.drop(1).forEach { raw ->
                val line = raw.removePrefix("\uFEFF").trim()
                if (line.isBlank()) return@forEach

                // The generated file has five simple CSV columns:
                // no,name,rank,family,size
                val p = line.split(",", limit = 5)
                if (p.size == 5) {
                    val no = p[0].trim().toIntOrNull() ?: return@forEach
                    monsters += Monster(
                        no = no,
                        name = p[1].trim(),
                        rank = p[2].trim(),
                        family = p[3].trim(),
                        size = p[4].trim()
                    )
                }
            }
        }
    }

    private fun getInt(key:String) = pref.getInt(key,0)
    private fun setInt(key:String,v:Int) = pref.edit().putInt(key, v.coerceAtLeast(0)).apply()
    private fun owned(m:Monster) = getInt("m${m.no}") + getInt("f${m.no}")

    private fun buildUi() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,12,12,4)}
        root.addView(TextView(this).apply{text="テリワンSP 管理帳";textSize=24f;setTextColor(Color.DKGRAY)})
        stats=TextView(this).apply{textSize=14f}
        root.addView(stats)

        search=EditText(this).apply{hint="名前・図鑑No.で検索";setSingleLine()}
        root.addView(search)

        val filters=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        rank=spinner(arrayOf("ランク:すべて","SS","S","A","B","C","D","E","F"))
        family=spinner(arrayOf("系統:すべて","スライム","ドラゴン","自然","魔獣","物質","悪魔","ゾンビ","？？？"))
        size=spinner(arrayOf("サイズ:すべて","S","M","G"))
        filters.addView(rank,LinearLayout.LayoutParams(0,56,1f))
        filters.addView(family,LinearLayout.LayoutParams(0,56,1f))
        filters.addView(size,LinearLayout.LayoutParams(0,56,1f))
        root.addView(filters)

        onlyUnowned=CheckBox(this).apply{text="未所持のみ"}
        root.addView(onlyUnowned)

        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        buttons.addView(Button(this).apply{text="バックアップ";setOnClickListener{backup() }},LinearLayout.LayoutParams(0,54,1f))
        buttons.addView(Button(this).apply{text="復元";setOnClickListener{restore() }},LinearLayout.LayoutParams(0,54,1f))
        root.addView(buttons)

        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)

        val watcher=object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}
            override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){refresh()}
            override fun afterTextChanged(e:android.text.Editable?){}
        }
        search.addTextChangedListener(watcher)
        rank.onItemSelectedListener=listener()
        family.onItemSelectedListener=listener()
        size.onItemSelectedListener=listener()
        onlyUnowned.setOnCheckedChangeListener{_,_->refresh()}
    }

    private fun spinner(items:Array<String>)=Spinner(this).apply{
        adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items)
    }
    private fun listener()=object:AdapterView.OnItemSelectedListener{
        override fun onNothingSelected(p:AdapterView<*>?){}
        override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){refresh()}
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        val q=search.text.toString().trim()
        val r=rank.selectedItem?.toString()?:"ランク:すべて"
        val f=family.selectedItem?.toString()?:"系統:すべて"
        val s=size.selectedItem?.toString()?:"サイズ:すべて"
        val filtered=monsters.filter{
            (q.isEmpty() || it.name.contains(q,true) || it.no.toString()==q) &&
            (r=="ランク:すべて" || it.rank==r) &&
            (f=="系統:すべて" || it.family==f) &&
            (s=="サイズ:すべて" || it.size==s) &&
            (!onlyUnowned.isChecked || owned(it)==0)
        }
        val kinds=monsters.count{owned(it)>0}
        val total=monsters.sumOf{owned(it)}
        stats.text="図鑑 ${monsters.size}体 / 所持種類 $kinds / 総所持数 $total / 表示 ${filtered.size}"
        list.removeAllViews()
        filtered.forEach{addRow(it)}
    }

    private fun addRow(m:Monster) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,10,8,10)}
        val title=TextView(this).apply{
            text=String.format("%03d  %s  [%s / %s / %s]",m.no,m.name,m.rank,m.family,m.size)
            textSize=17f
        }
        box.addView(title)
        val counts=LinearLayout(this)
        addCounter(counts,"♂","m${m.no}",m)
        addCounter(counts,"♀","f${m.no}",m)
        box.addView(counts)
        val memo=EditText(this).apply{
            hint="メモ"
            setText(pref.getString("note${m.no}",""))
            setSingleLine()
            setOnFocusChangeListener{_,has->if(!has)pref.edit().putString("note${m.no}",text.toString()).apply()}
        }
        box.addView(memo)
        list.addView(box)
        list.addView(View(this).apply{setBackgroundColor(0xffdddddd.toInt())},LinearLayout.LayoutParams(-1,1))
    }

    private fun addCounter(parent:LinearLayout,label:String,key:String,m:Monster){
        val value=TextView(this).apply{text="$label ${getInt(key)}";textSize=16f;gravity=Gravity.CENTER}
        parent.addView(value,LinearLayout.LayoutParams(0,58,1f))
        parent.addView(Button(this).apply{text="−";setOnClickListener{setInt(key,getInt(key)-1);refresh()}},LinearLayout.LayoutParams(48,58))
        parent.addView(Button(this).apply{text="＋";setOnClickListener{setInt(key,getInt(key)+1);refresh()}},LinearLayout.LayoutParams(48,58))
    }

    private fun backup(){
        val arr=JSONArray()
        for(m in monsters){
            val o=JSONObject()
            o.put("no",m.no);o.put("male",getInt("m${m.no}"));o.put("female",getInt("f${m.no}"));o.put("favorite",pref.getBoolean("fav${m.no}",false));o.put("note",pref.getString("note${m.no}",""))
            arr.put(o)
        }
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/json";putExtra(Intent.EXTRA_TITLE,"terrysp_backup.json")}
        startActivityForResult(Intent.createChooser(intent,"バックアップ保存"),1001)
        backupPayload=arr.toString()
    }
    private var backupPayload=""
    private fun restore(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE)}
        startActivityForResult(intent,1002)
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(res!=RESULT_OK || data?.data==null)return
        try{
            if(req==1001){
                contentResolver.openOutputStream(data.data!!)!!.use{it.write(backupPayload.toByteArray(StandardCharsets.UTF_8))}
                Toast.makeText(this,"バックアップを保存しました",Toast.LENGTH_SHORT).show()
            }else if(req==1002){
                val text=contentResolver.openInputStream(data.data!!)!!.bufferedReader().readText()
                val arr=JSONArray(text);val e=pref.edit()
                for(i in 0 until arr.length()){
                    val o=arr.getJSONObject(i);val no=o.getInt("no")
                    e.putInt("m$no",o.optInt("male",0));e.putInt("f$no",o.optInt("female",0))
                    e.putBoolean("fav$no",o.optBoolean("favorite",false));e.putString("note$no",o.optString("note",""))
                }
                e.apply();refresh();Toast.makeText(this,"復元しました",Toast.LENGTH_SHORT).show()
            }
        }catch(ex:Exception){Toast.makeText(this,"ファイルを読み込めませんでした",Toast.LENGTH_LONG).show()}
    }
}
