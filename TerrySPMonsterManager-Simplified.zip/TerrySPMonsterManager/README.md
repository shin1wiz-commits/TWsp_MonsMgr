# TerrySPMonsterManager

シンプルな Android / Gradle プロジェクトです。

- `app/` — Android アプリ
- `gradle/wrapper/` — Gradle Wrapper
- `build.gradle.kts` — ルート設定
- `settings.gradle.kts` — プロジェクト設定
- `gradlew` / `gradlew.bat` — Gradle Wrapper
- `.github/workflows/build-apk.yml` — GitHub Actions

GitHub Actions はリポジトリ直下から直接 `./gradlew :app:assembleDebug` を実行し、
`app-debug.apk` を Artifact としてアップロードします。
