plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

android {
    namespace = "com.example.terrysp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.terrysp"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// Android Gradle Plugin does not support JavaCompile --release.
// Keep Java compilation configured through Android's source/target settings.
tasks.withType<JavaCompile>().configureEach {
    options.release.set(null)
}
