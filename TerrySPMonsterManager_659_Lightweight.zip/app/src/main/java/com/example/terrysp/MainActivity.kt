package com.example.terrysp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

private data class Monster(
    val no: Int,
    val name: String,
    val rank: String,
    val family: String,
    val size: String
)

class MainActivity : Activity() {
    private lateinit var search: EditText
    private lateinit var rank: Spinner
    private lateinit var family: Spinner
    private lateinit var size: Spinner
    private lateinit var onlyUnowned: CheckBox
    private lateinit var list: ListView
    private lateinit var stats: TextView

    private val monsters = mutableListOf<Monster>()
    private val filtered = mutableListOf<Monster>()
    private val maleCounts = HashMap<Int, Int>()
    private val femaleCounts = HashMap<Int, Int>()
    private val notes = HashMap<Int, String>()
    private val favorites = HashMap<Int, Boolean>()
    private val pref by lazy { getSharedPreferences("monster_state", MODE_PRIVATE) }
    private lateinit var adapter: MonsterAdapter

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        loadData()
        loadState()
        buildUi()
        applyFilter()
    }

    private fun loadData() {
        monsters.clear()
        BufferedReader(InputStreamReader(assets.open("monsters.csv"), StandardCharsets.UTF_8)).useLines { lines ->
            lines.drop(1).forEach { raw ->
                val line = raw.removePrefix("\uFEFF").trim().removeSuffix("\r")
                if (line.isBlank()) return@forEach
                val p = line.split(',', limit = 5)
                if (p.size != 5) return@forEach
                val no = p[0].trim().toIntOrNull() ?: return@forEach
                monsters += Monster(
                    no = no,
                    name = p[1].trim(),
                    rank = p[2].trim(),
                    family = p[3].trim(),
                    size = p[4].trim()
                )
            }
        }
        monsters.sortBy { it.no }
    }

    private fun loadState() {
        maleCounts.clear()
        femaleCounts.clear()
        notes.clear()
        favorites.clear()
        monsters.forEach { m ->
            maleCounts[m.no] = pref.getInt("m${m.no}", 0)
            femaleCounts[m.no] = pref.getInt("f${m.no}", 0)
            notes[m.no] = pref.getString("note${m.no}", "") ?: ""
            favorites[m.no] = pref.getBoolean("fav${m.no}", false)
        }
    }

    private fun male(no: Int) = maleCounts[no] ?: 0
    private fun female(no: Int) = femaleCounts[no] ?: 0
    private fun owned(m: Monster) = male(m.no) + female(m.no)

    private fun setCount(no: Int, maleValue: Int? = null, femaleValue: Int? = null) {
        if (maleValue != null) maleCounts[no] = maleValue.coerceAtLeast(0)
        if (femaleValue != null) femaleCounts[no] = femaleValue.coerceAtLeast(0)
        val e = pref.edit()
        if (maleValue != null) e.putInt("m$no", male(no))
        if (femaleValue != null) e.putInt("f$no", female(no))
        e.apply()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(4))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "テリワンSP 管理帳"
            textSize = 24f
            setTextColor(Color.rgb(45, 45, 45))
            setPadding(0, 0, 0, dp(2))
        })

        stats = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, dp(6))
        }
        root.addView(stats)

        search = EditText(this).apply {
            hint = "名前・図鑑No.で検索"
            setSingleLine(true)
            textSize = 16f
            setPadding(dp(10), 0, dp(10), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))

        val filters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        rank = makeSpinner(rankItems())
        family = makeSpinner(familyItems())
        size = makeSpinner(sizeItems())
        filters.addView(rank, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        filters.addView(family, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(2); marginEnd = dp(2) })
        filters.addView(size, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })
        root.addView(filters)

        onlyUnowned = CheckBox(this).apply {
            text = "未所持のみ"
            textSize = 14f
            setPadding(0, 0, 0, 0)
        }
        root.addView(onlyUnowned, LinearLayout.LayoutParams(-1, dp(44)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        buttons.addView(Button(this).apply {
            text = "バックアップ"
            textSize = 13f
            setOnClickListener { backup() }
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        buttons.addView(Button(this).apply {
            text = "復元"
            textSize = 13f
            setOnClickListener { restore() }
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(4) })
        root.addView(buttons)

        list = ListView(this).apply {
            divider = null
            dividerHeight = 0
            setPadding(0, dp(4), 0, 0)
            clipToPadding = false
            isVerticalScrollBarEnabled = true
            isScrollbarFadingEnabled = true
            itemsCanFocus = true
        }
        adapter = MonsterAdapter(this)
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applyFilter() }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        search.addTextChangedListener(watcher)
        rank.onItemSelectedListener = filterListener()
        family.onItemSelectedListener = filterListener()
        size.onItemSelectedListener = filterListener()
        onlyUnowned.setOnCheckedChangeListener { _, _ -> applyFilter() }
    }

    private fun rankItems(): Array<String> {
        val order = listOf("SS", "S", "A", "B", "C", "D", "E", "F")
        return arrayOf("ランク:すべて") + order.filter { r -> monsters.any { it.rank == r } }.toTypedArray()
    }

    private fun familyItems(): Array<String> = arrayOf("系統:すべて") + monsters.map { it.family }.distinct()
        .sorted().toTypedArray()

    private fun sizeItems(): Array<String> = arrayOf("サイズ:すべて") + monsters.map { it.size }.distinct()
        .sorted().toTypedArray()

    private fun makeSpinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun filterListener() = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { applyFilter() }
    }

    private fun applyFilter() {
        if (!::adapter.isInitialized) return
        val q = search.text?.toString()?.trim().orEmpty()
        val r = rank.selectedItem?.toString() ?: "ランク:すべて"
        val f = family.selectedItem?.toString() ?: "系統:すべて"
        val s = size.selectedItem?.toString() ?: "サイズ:すべて"

        filtered.clear()
        filtered.addAll(monsters.filter { m ->
            val queryOk = q.isEmpty() || m.name.contains(q, ignoreCase = true) || m.no.toString() == q
            val rankOk = r == "ランク:すべて" || m.rank == r
            val familyOk = f == "系統:すべて" || m.family == f
            val sizeOk = s == "サイズ:すべて" || m.size == s
            val ownedOk = !onlyUnowned.isChecked || owned(m) == 0
            queryOk && rankOk && familyOk && sizeOk && ownedOk
        })
        adapter.notifyDataSetChanged()
        updateStats()
    }

    private fun updateStats() {
        val kinds = monsters.count { owned(it) > 0 }
        val total = monsters.sumOf { owned(it) }
        stats.text = "図鑑 ${monsters.size}体 / 所持種類 $kinds / 総所持数 $total / 表示 ${filtered.size}"
    }

    private fun changeCount(m: Monster, maleType: Boolean, delta: Int) {
        val old = if (maleType) male(m.no) else female(m.no)
        val next = (old + delta).coerceAtLeast(0)
        if (maleType) setCount(m.no, maleValue = next) else setCount(m.no, femaleValue = next)
        adapter.notifyDataSetChanged()
        updateStats()
    }

    private inner class MonsterAdapter(context: Context) : BaseAdapter() {
        private val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

        override fun getCount() = filtered.size
        override fun getItem(position: Int) = filtered[position]
        override fun getItemId(position: Int) = filtered[position].no.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: createRow()
            val m = getItem(position)
            bindRow(row, m)
            return row
        }

        private fun createRow(): LinearLayout {
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.WHITE)
            }

            box.addView(TextView(this@MainActivity).apply {
                tag = "title"
                textSize = 16f
                setTextColor(Color.rgb(35, 35, 35))
                setPadding(0, 0, 0, dp(4))
            }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

            val counters = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            counters.addView(makeCounterLabel("male"), LinearLayout.LayoutParams(0, dp(44), 1f))
            counters.addView(makeCounterButton("mminus"), LinearLayout.LayoutParams(dp(44), dp(44)))
            counters.addView(makeCounterButton("mplus"), LinearLayout.LayoutParams(dp(44), dp(44)))
            counters.addView(Space(this@MainActivity), LinearLayout.LayoutParams(dp(8), dp(1)))
            counters.addView(makeCounterLabel("female"), LinearLayout.LayoutParams(0, dp(44), 1f))
            counters.addView(makeCounterButton("fminus"), LinearLayout.LayoutParams(dp(44), dp(44)))
            counters.addView(makeCounterButton("fplus"), LinearLayout.LayoutParams(dp(44), dp(44)))
            box.addView(counters)

            box.addView(EditText(this@MainActivity).apply {
                tag = "memo"
                hint = "メモ"
                setSingleLine(true)
                textSize = 14f
                setPadding(dp(8), 0, dp(8), 0)
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(4) })

            box.addView(View(this@MainActivity).apply {
                tag = "divider"
                setBackgroundColor(Color.rgb(225, 225, 225))
            }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(7) })
            return box
        }

        private fun makeCounterLabel(tagValue: String) = TextView(this@MainActivity).apply {
            tag = tagValue
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.DKGRAY)
        }

        private fun makeCounterButton(tagValue: String) = Button(this@MainActivity).apply {
            tag = tagValue
            textSize = 18f
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
        }

        private fun bindRow(row: LinearLayout, m: Monster) {
            val title = row.findViewWithTag<TextView>("title")
            title.text = String.format("%03d  %s  [%s / %s / %s]", m.no, m.name, m.rank, m.family, m.size)

            val maleLabel = row.findViewWithTag<TextView>("male")
            val femaleLabel = row.findViewWithTag<TextView>("female")
            maleLabel.text = "♂ ${male(m.no)}"
            femaleLabel.text = "♀ ${female(m.no)}"

            row.findViewWithTag<Button>("mminus").apply {
                text = "−"
                setOnClickListener { changeCount(m, true, -1) }
            }
            row.findViewWithTag<Button>("mplus").apply {
                text = "+"
                setOnClickListener { changeCount(m, true, 1) }
            }
            row.findViewWithTag<Button>("fminus").apply {
                text = "−"
                setOnClickListener { changeCount(m, false, -1) }
            }
            row.findViewWithTag<Button>("fplus").apply {
                text = "+"
                setOnClickListener { changeCount(m, false, 1) }
            }

            val memo = row.findViewWithTag<EditText>("memo")
            (memo.getTag(1001) as? TextWatcher)?.let { memo.removeTextChangedListener(it) }
            memo.setText(notes[m.no].orEmpty())
            memo.setSelection(memo.text.length)
            val watcher = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    notes[m.no] = s?.toString().orEmpty()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            }
            memo.addTextChangedListener(watcher)
            memo.setTag(1001, watcher)
            memo.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) pref.edit().putString("note${m.no}", notes[m.no].orEmpty()).apply()
            }
        }
    }

    private fun backup() {
        val arr = JSONArray()
        for (m in monsters) {
            val o = JSONObject()
            o.put("no", m.no)
            o.put("male", male(m.no))
            o.put("female", female(m.no))
            o.put("favorite", favorites[m.no] ?: false)
            o.put("note", notes[m.no].orEmpty())
            arr.put(o)
        }
        backupPayload = arr.toString()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "terrysp_backup.json")
        }
        startActivityForResult(Intent.createChooser(intent, "バックアップ保存"), 1001)
    }

    private var backupPayload = ""

    private fun restore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/json"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 1002)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data?.data == null) return
        try {
            if (req == 1001) {
                contentResolver.openOutputStream(data.data!!)?.use {
                    it.write(backupPayload.toByteArray(StandardCharsets.UTF_8))
                }
                Toast.makeText(this, "バックアップを保存しました", Toast.LENGTH_SHORT).show()
            } else if (req == 1002) {
                val text = contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText() ?: return
                val arr = JSONArray(text)
                val e = pref.edit()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val no = o.getInt("no")
                    val m = o.optInt("male", 0).coerceAtLeast(0)
                    val f = o.optInt("female", 0).coerceAtLeast(0)
                    val n = o.optString("note", "")
                    val fav = o.optBoolean("favorite", false)
                    maleCounts[no] = m
                    femaleCounts[no] = f
                    notes[no] = n
                    favorites[no] = fav
                    e.putInt("m$no", m)
                    e.putInt("f$no", f)
                    e.putBoolean("fav$no", fav)
                    e.putString("note$no", n)
                }
                e.apply()
                adapter.notifyDataSetChanged()
                updateStats()
                Toast.makeText(this, "復元しました", Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "ファイルを読み込めませんでした", Toast.LENGTH_LONG).show()
        }
    }
}
