# TerrySP Monster Manager 1.2

659体のモンスター情報を `app/src/main/assets/monsters.csv` から読み込む軽量版です。

## 最適化内容
- 起動時のデータ読み込みを軽量化
- SharedPreferences の読み込みを一括取得
- 一覧行から常設 EditText を削除し、必要時だけメモ編集ダイアログを表示
- 一覧行をコンパクト化してスクロール時の負荷を軽減
- フィルターを画面幅に合わせて2段構成に変更
- 外部ライブラリを追加せず、Android標準Viewのみで構成
- `monsters.csv` はそのまま編集可能

## データ
CSVは `app/src/main/assets/monsters.csv` にあります。
ヘッダーは次の形式です。

`no,name,rank,family,size`

## GitHub Actions
このZIPをリポジトリに置き、別途 `build-apk.yml` をGitHub Actionsへ配置してビルドします。

## v2.7.1
判断用アイコンをゲーム内の四角い枠基準で正規化し、枠外背景とランク/性別/パーティ表示領域を照合対象から除外しました。未登録個体は、表示用アイコン＋モンスター名の候補を見ながらタップして登録できます。候補外は図鑑No./名前検索を利用できます。同じ解析内に同一アイコンが複数ある場合は、1体の登録後に高一致個体を再判定します。
