plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val fixedStoreFile = System.getenv("TERRYSP_SIGNING_STORE_FILE")
val fixedStorePassword = System.getenv("TERRYSP_STORE_PASSWORD")
val fixedKeyAlias = System.getenv("TERRYSP_KEY_ALIAS")
val fixedKeyPassword = System.getenv("TERRYSP_KEY_PASSWORD")
val fixedSigningReady = listOf(fixedStoreFile, fixedStorePassword, fixedKeyAlias, fixedKeyPassword).all { !it.isNullOrBlank() }

android {
    namespace = "com.example.terrysp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.terrysp"
        minSdk = 23
        targetSdk = 35
        versionCode = 27
        versionName = "2.8.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    signingConfigs {
        create("fixedRelease") {
            if (fixedSigningReady) {
                storeFile = file(fixedStoreFile!!)
                storePassword = fixedStorePassword
                keyAlias = fixedKeyAlias
                keyPassword = fixedKeyPassword
            }
        }
    }

    buildTypes {
        release {
            // Keep release behavior close to the well-tested debug builds during this migration.
            isMinifyEnabled = false
            isShrinkResources = false
            if (fixedSigningReady) {
                signingConfig = signingConfigs.getByName("fixedRelease")
            }
        }
    }
}
