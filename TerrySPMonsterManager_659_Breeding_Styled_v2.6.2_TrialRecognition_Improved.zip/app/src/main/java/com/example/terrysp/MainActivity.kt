package com.example.terrysp

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

private data class Monster(
    val no: Int,
    val name: String,
    val rank: String,
    val family: String,
    val size: String
)

private data class TrialRecognition(
    val no: Int,
    val sex: Int,
    val confidence: Double,
    val secondNo: Int = -1,
    val margin: Double = 0.0,
    val accepted: Boolean = true
)

private data class BreedingRecipe(
    val id: Int,
    val resultNo: Int?,
    val resultName: String,
    val resultRank: String,
    val resultFamily: String,
    val resultSize: String,
    val type: String,
    val parents: List<String>,
    val parentTypes: List<String>,
    val note: String
)

class MainActivity : Activity() {
    private val monsters = mutableListOf<Monster>()
    private val monsterByName = HashMap<String, Monster>()
    private val recipes = mutableListOf<BreedingRecipe>()

    private val maleCounts = HashMap<Int, Int>()
    private val femaleCounts = HashMap<Int, Int>()
    private val bothCounts = HashMap<Int, Int>()
    private val notes = HashMap<Int, String>()
    private val favorites = HashMap<Int, Boolean>()
    private val pref by lazy { getSharedPreferences("monster_state", MODE_PRIVATE) }
    private var backupPayload = ""
    private var pendingImageMonsterNo: Int? = null
    private val imageDownloadCancel = AtomicBoolean(false)
    private val altemaZukanUrl = "https://altema.jp/terrysp/zukan"

    // Management page
    private lateinit var manageSearch: EditText
    private lateinit var manageMatchMode: Spinner
    private lateinit var manageRank: Spinner
    private lateinit var manageFamily: Spinner
    private lateinit var manageSize: Spinner
    private lateinit var onlyUnowned: CheckBox
    private lateinit var manageList: ListView
    private lateinit var manageStats: TextView
    private lateinit var monsterAdapter: MonsterAdapter
    private val filteredMonsters = mutableListOf<Monster>()

    // Breeding page
    private lateinit var breedSearch: EditText
    private lateinit var breedDirection: Spinner
    private lateinit var breedMatchMode: Spinner
    private lateinit var breedSort: Spinner
    private lateinit var breedSortOrder: Spinner
    private lateinit var breedType: Spinner
    private lateinit var breedRank: Spinner
    private lateinit var breedFamily: Spinner
    private lateinit var breedSize: Spinner
    private lateinit var breedList: ListView
    private lateinit var breedStats: TextView
    private lateinit var breedingAdapter: BreedingAdapter
    private val filteredRecipes = mutableListOf<BreedingRecipe>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val bg = Color.rgb(244, 247, 250)
    private val card = Color.WHITE
    private val primary = Color.rgb(41, 98, 255)
    private val primarySoft = Color.rgb(232, 240, 255)
    private val breedingColor = Color.rgb(0, 137, 123)
    private val breedingSoft = Color.rgb(229, 245, 242)
    private val accentOrange = Color.rgb(251, 140, 0)
    private val dangerSoft = Color.rgb(255, 235, 238)
    private val textMain = Color.rgb(35, 42, 52)
    private val textSub = Color.rgb(90, 100, 115)
    private val divider = Color.rgb(225, 230, 236)

    private fun roundedBg(color: Int, radiusDp: Int = 10): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }
    }

    private fun styleButton(button: Button, color: Int, textColor: Int = Color.WHITE) {
        button.background = roundedBg(color, 9)
        button.setTextColor(textColor)
        button.isAllCaps = false
        button.minHeight = 0
        button.minWidth = 0
        button.setPadding(dp(8), 0, dp(8), 0)
    }

    private fun styleCountButton(button: Button, textColor: Int) {
        button.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(9).toFloat()
            setStroke(dp(1), Color.rgb(215, 222, 230))
        }
        button.setTextColor(textColor)
        button.isAllCaps = false
        button.minHeight = 0
        button.minWidth = 0
        button.setPadding(0, 0, 0, 0)
    }

    private fun addTag(container: LinearLayout, text: String, color: Int) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundedBg(color, 12)
            setPadding(dp(9), dp(3), dp(9), dp(3))
        }
        container.addView(tv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(5) })
    }

    private fun rankColor(rank: String): Int = when(rank) {
        "SS" -> Color.rgb(198, 146, 20)
        "S" -> Color.rgb(123, 31, 162)
        "A" -> Color.rgb(211, 47, 47)
        "B" -> Color.rgb(239, 108, 0)
        "C" -> Color.rgb(30, 136, 229)
        "D" -> Color.rgb(67, 160, 71)
        "E" -> Color.rgb(96, 125, 139)
        else -> Color.rgb(120, 120, 120)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        showLoading()
        try {
            loadMonsters()
            loadBreeding()
            loadState()
            showManagementPage()
        } catch (t: Throwable) {
            showStartupError(t)
        }
    }

    private fun showLoading() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(TextView(this).apply {
            text = "テリワンSP 管理帳を起動しています…"
            textSize = 16f
            setTextColor(textSub)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(root)
    }

    private fun showStartupError(t: Throwable) {
        val root = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        box.addView(TextView(this).apply {
            text = "テリワンSP 管理帳\n\n起動中にエラーが発生しました。\n\n${t::class.java.simpleName}: ${t.message ?: "メッセージなし"}"
            textSize = 16f
            setTextColor(Color.rgb(150, 0, 0))
            setTextIsSelectable(true)
        })
        box.addView(Button(this).apply {
            text = "再試行"
            setOnClickListener {
                try {
                    loadMonsters()
                    loadBreeding()
                    loadState()
                    showManagementPage()
                } catch (e: Throwable) { showStartupError(e) }
            }
        })
        root.addView(box)
        setContentView(root)
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cur.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out.add(cur.toString()); cur.setLength(0) }
                else -> cur.append(c)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun loadMonsters() {
        monsters.clear()
        monsterByName.clear()
        BufferedReader(InputStreamReader(assets.open("monsters.csv"), StandardCharsets.UTF_8)).use { br ->
            br.readLine()
            br.forEachLine { raw ->
                val p = parseCsvLine(raw.removePrefix("\uFEFF").removeSuffix("\r"))
                if (p.size < 5) return@forEachLine
                val no = p[0].trim().toIntOrNull() ?: return@forEachLine
                val m = Monster(no, p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim())
                monsters += m
                monsterByName[m.name] = m
            }
        }
        monsters.sortBy { it.no }
    }

    private fun loadBreeding() {
        recipes.clear()
        BufferedReader(InputStreamReader(assets.open("breeding.csv"), StandardCharsets.UTF_8)).use { br ->
            val header = parseCsvLine(br.readLine().removePrefix("\uFEFF"))
            val ix = header.withIndex().associate { it.value.trim() to it.index }
            fun get(p: List<String>, name: String): String {
                val n = ix[name] ?: return ""
                return if (n < p.size) p[n].trim() else ""
            }
            br.forEachLine { raw ->
                if (raw.isBlank()) return@forEachLine
                val p = parseCsvLine(raw.removeSuffix("\r"))
                val name = get(p, "result_name")
                if (name.isBlank()) return@forEachLine
                val parents = (1..4).map { get(p, "parent$it") }.filter { it.isNotBlank() }
                val parentTypes = (1..4).map { get(p, "parent${it}_type") }.take(parents.size)
                recipes += BreedingRecipe(
                    get(p, "recipe_id").toIntOrNull() ?: recipes.size + 1,
                    get(p, "result_no").toIntOrNull(),
                    name,
                    get(p, "result_rank"),
                    get(p, "result_family"),
                    get(p, "result_size"),
                    get(p, "recipe_type"),
                    parents,
                    parentTypes,
                    get(p, "note")
                )
            }
        }
    }

    private fun loadState() {
        maleCounts.clear(); femaleCounts.clear(); bothCounts.clear(); notes.clear(); favorites.clear()
        val all = pref.all
        monsters.forEach { m ->
            maleCounts[m.no] = (all["m${m.no}"] as? Int) ?: 0
            femaleCounts[m.no] = (all["f${m.no}"] as? Int) ?: 0
            bothCounts[m.no] = (all["b${m.no}"] as? Int) ?: 0
            notes[m.no] = (all["note${m.no}"] as? String).orEmpty()
            favorites[m.no] = (all["fav${m.no}"] as? Boolean) ?: false
        }
    }

    private fun topMenu(active: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(7))

            fun tab(text: String, index: Int, color: Int, action: () -> Unit) = Button(this@MainActivity).apply {
                this.text = text
                textSize = 13f
                setOnClickListener { action() }
                styleButton(
                    this,
                    if (active == index) color else Color.rgb(225,230,236),
                    if (active == index) Color.WHITE else textMain
                )
            }

            addView(tab("管理表", 0, primary) { showManagementPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
            addView(tab("配合表", 1, breedingColor) { showBreedingPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
            addView(tab("設定", 2, Color.rgb(69, 90, 100)) { showSettingsPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3) })
        }
    }

    private fun makeSpinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun filterListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action()
    }

    private fun watcher(action: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = action()
        override fun afterTextChanged(s: Editable?) = Unit
    }

    private fun textMatches(value: String, query: String, exact: Boolean): Boolean {
        if (query.isEmpty()) return true
        return if (exact) value.equals(query, ignoreCase = true)
        else value.contains(query, ignoreCase = true)
    }

    private fun firstParentName(r: BreedingRecipe): String =
        r.parents.firstOrNull().orEmpty()

    private fun firstParentNo(r: BreedingRecipe): Int =
        r.parents.mapNotNull { monsterByName[it]?.no }.minOrNull() ?: Int.MAX_VALUE


    private fun monsterIconDir(): File =
        File(filesDir, "monster_icons").apply { mkdirs() }

    private fun monsterIconFile(no: Int): File =
        File(monsterIconDir(), String.format("monster_%03d.img", no))

    private fun applyMonsterIcon(image: ImageView, fallback: TextView, m: Monster) {
        val file = monsterIconFile(m.no)
        if (file.isFile) {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap != null) {
                image.setImageBitmap(bitmap)
                image.visibility = View.VISIBLE
                fallback.visibility = View.GONE
                return
            }
        }
        image.setImageDrawable(null)
        image.visibility = View.GONE
        fallback.visibility = View.VISIBLE
        fallback.text = m.rank
        fallback.background = roundedBg(rankColor(m.rank), 22)
    }

    private fun openImageMenu(m: Monster) {
        val hasImage = monsterIconFile(m.no).isFile
        val items = if (hasImage) {
            arrayOf("画像を変更", "画像を削除", "キャンセル")
        } else {
            arrayOf("画像を登録", "キャンセル")
        }

        AlertDialog.Builder(this)
            .setTitle("No.${m.no} ${m.name}\nモンスターアイコン")
            .setItems(items) { dialog, which ->
                if (hasImage) {
                    when (which) {
                        0 -> selectMonsterImage(m)
                        1 -> {
                            monsterIconFile(m.no).delete()
                            if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                            Toast.makeText(this, "画像を削除しました", Toast.LENGTH_SHORT).show()
                        }
                        else -> dialog.dismiss()
                    }
                } else {
                    if (which == 0) selectMonsterImage(m) else dialog.dismiss()
                }
            }
            .show()
    }

    private fun selectMonsterImage(m: Monster) {
        pendingImageMonsterNo = m.no
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            },
            1003
        )
    }

    private fun saveSelectedMonsterImage(uri: android.net.Uri, no: Int) {
        val target = monsterIconFile(no)
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("画像ファイルを開けませんでした")

        if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
        Toast.makeText(this, "モンスター画像を登録しました", Toast.LENGTH_SHORT).show()
    }

    private fun decodeHtml(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun stripHtml(value: String): String =
        decodeHtml(value.replace(Regex("(?is)<[^>]+>"), " "))
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun tagAttribute(tag: String, name: String): String? {
        val pattern = Regex("(?is)\\b" + Regex.escape(name) + "\\s*=\\s*[\"']([^\"']*)[\"']")
        return pattern.find(tag)?.groupValues?.getOrNull(1)?.let(::decodeHtml)?.takeIf { it.isNotBlank() }
    }

    private fun imageUrlFromTag(tag: String): String? {
        val attrs = listOf("data-src", "data-original", "data-lazy-src", "src")
        return attrs.asSequence().mapNotNull { tagAttribute(tag, it) }
            .map { raw ->
                when {
                    raw.startsWith("//") -> "https:$raw"
                    raw.startsWith("/") -> "https://altema.jp$raw"
                    raw.startsWith("http://") || raw.startsWith("https://") -> raw
                    else -> null
                }
            }
            .filterNotNull()
            .firstOrNull()
    }

    private fun fetchText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseAltemaImageUrls(html: String): Map<Int, String> {
        val result = HashMap<Int, String>()
        val byName = monsters.associateBy { it.name }

        // Most entries on the zukan page are links that contain both the icon and monster name.
        Regex("(?is)<a\\b[^>]*>(.*?)</a>").findAll(html).forEach { match ->
            val body = match.groupValues[1]
            val text = stripHtml(body)
            val monster = byName[text] ?: return@forEach
            val imgTag = Regex("(?is)<img\\b[^>]*>").find(body)?.value ?: return@forEach
            val url = imageUrlFromTag(imgTag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }

        // Fallback for layouts where the image itself carries the monster name in alt/title.
        Regex("(?is)<img\\b[^>]*>").findAll(html).forEach { match ->
            val tag = match.value
            val label = tagAttribute(tag, "alt") ?: tagAttribute(tag, "title") ?: return@forEach
            val monster = byName[label] ?: return@forEach
            val url = imageUrlFromTag(tag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }
        return result
    }

    private fun parseMonsterDetailImageUrl(html: String, monsterName: String): String? {
        // Individual monster pages are used as a fallback when an icon on the index page
        // cannot be associated correctly (currently needed for No.080 ミストウイング).
        Regex("(?is)<img\\b[^>]*>").findAll(html).forEach { match ->
            val tag = match.value
            val alt = tagAttribute(tag, "alt") ?: ""
            val title = tagAttribute(tag, "title") ?: ""
            if (alt.contains(monsterName) || title.contains(monsterName)) {
                imageUrlFromTag(tag)?.let { return it }
            }
        }
        return null
    }

    private fun fallbackAltemaImageUrl(m: Monster): String? {
        // Altema's No.080 entry is exceptional on the zukan page.
        // Its individual monster page is stable and supplies the same game icon.
        if (m.no == 80 && m.name == "ミストウイング") {
            val detailHtml = fetchText("https://altema.jp/terrysp/monster/430")
            return parseMonsterDetailImageUrl(detailHtml, m.name)
        }
        return null
    }

    private fun downloadIcon(url: String, no: Int) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Referer", altemaZukanUrl)
        }
        val tmp = File(monsterIconDir(), String.format("monster_%03d.tmp", no))
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            conn.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
            if (BitmapFactory.decodeFile(tmp.absolutePath) == null) {
                throw IllegalStateException("画像として読み込めません")
            }
            val target = monsterIconFile(no)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        } finally {
            conn.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun confirmAltemaImageDownload() {
        AlertDialog.Builder(this)
            .setTitle("アルテマ画像を一括取得")
            .setMessage("アルテマのモンスター図鑑ページから、No.に対応するアイコンをこの端末内へ保存します。\n\n通信環境によって数分かかる場合があります。既に登録済みの画像は上書きします。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("取得開始") { _, _ -> startAltemaImageDownload() }
            .show()
    }

    private fun startAltemaImageDownload() {
        imageDownloadCancel.set(false)
        val status = TextView(this).apply {
            text = "図鑑ページを確認しています…"
            textSize = 14f
            setTextColor(textMain)
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = monsters.size
            progress = 0
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(status, LinearLayout.LayoutParams(-1, -2))
            addView(progress, LinearLayout.LayoutParams(-1, dp(18)).apply {
                marginStart = dp(16); marginEnd = dp(16); bottomMargin = dp(10)
            })
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("画像を取得中")
            .setView(box)
            .setNegativeButton("中止") { _, _ -> imageDownloadCancel.set(true) }
            .setCancelable(false)
            .create()
        dialog.show()

        Thread {
            var saved = 0
            var failed = 0
            var matched = 0
            try {
                val html = fetchText(altemaZukanUrl)
                val urls = parseAltemaImageUrls(html).toMutableMap()
                // Fill exceptional/missing entries from their individual monster pages.
                monsters.filter { !urls.containsKey(it.no) }.forEach { m ->
                    try { fallbackAltemaImageUrl(m)?.let { urls[m.no] = it } } catch (_: Throwable) { }
                }
                matched = urls.size
                if (urls.isEmpty()) throw IllegalStateException("図鑑ページからモンスター画像を検出できませんでした")

                monsters.forEachIndexed { index, m ->
                    if (imageDownloadCancel.get()) return@forEachIndexed
                    val url = urls[m.no]
                    if (url != null) {
                        try {
                            downloadIcon(url, m.no)
                            saved++
                        } catch (_: Throwable) {
                            failed++
                        }
                    }
                    if (index % 4 == 0 || index == monsters.lastIndex) {
                        val p = index + 1
                        runOnUiThread {
                            progress.progress = p
                            status.text = "確認 $p / ${monsters.size}　保存 $saved　失敗 $failed"
                        }
                    }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    if (dialog.isShowing) dialog.dismiss()
                    AlertDialog.Builder(this)
                        .setTitle("画像取得に失敗しました")
                        .setMessage("${t.message ?: t::class.java.simpleName}\n\nページ構成や通信状態が変わっている可能性があります。個別の画像登録機能は引き続き使用できます。")
                        .setPositiveButton("閉じる", null)
                        .show()
                }
                return@Thread
            }

            runOnUiThread {
                if (dialog.isShowing) dialog.dismiss()
                if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                val stopped = imageDownloadCancel.get()
                AlertDialog.Builder(this)
                    .setTitle(if (stopped) "画像取得を中止しました" else "画像取得が完了しました")
                    .setMessage("ページ内で対応を確認: ${matched}体\n端末へ保存: ${saved}体\n取得失敗: ${failed}体")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }


    private fun exportMonsterImagesZip() {
        val imageCount = monsters.count { monsterIconFile(it.no).isFile }
        if (imageCount == 0) {
            Toast.makeText(this, "書き出せる取得済み画像がありません", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("取得済み画像をZIP書き出し")
            .setMessage("端末内に保存されている取得済みモンスター画像 ${imageCount}体分を、図鑑No.とモンスター名付きのPNG画像としてZIPにまとめます。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("保存先を選ぶ") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_TITLE, "TerrySP_monster_icons.zip")
                }, 1004)
            }
            .show()
    }

    private fun safeZipName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "monster" }

    private fun writeMonsterImagesZip(uri: android.net.Uri) {
        Toast.makeText(this, "画像ZIPを書き出しています…", Toast.LENGTH_SHORT).show()
        Thread {
            var saved = 0
            var failed = 0
            try {
                contentResolver.openOutputStream(uri)?.use { raw ->
                    ZipOutputStream(raw.buffered()).use { zip ->
                        monsters.forEach { m ->
                            val source = monsterIconFile(m.no)
                            if (!source.isFile) return@forEach
                            val bitmap = BitmapFactory.decodeFile(source.absolutePath)
                            if (bitmap == null) {
                                failed++
                                return@forEach
                            }
                            try {
                                val entryName = String.format("%03d_%s.png", m.no, safeZipName(m.name))
                                zip.putNextEntry(ZipEntry(entryName))
                                if (bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, zip)) saved++ else failed++
                                zip.closeEntry()
                            } catch (_: Throwable) {
                                failed++
                                try { zip.closeEntry() } catch (_: Throwable) { }
                            } finally {
                                bitmap.recycle()
                            }
                        }
                    }
                } ?: throw IllegalStateException("保存先を開けませんでした")
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPを書き出しました")
                        .setMessage("保存: ${saved}体\n失敗: ${failed}体\n\nファイル名: TerrySP_monster_icons.zip")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("ZIP書き出しに失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName)
                        .setPositiveButton("閉じる", null)
                        .show()
                }
            }
        }.start()
    }

    // ---------------- Management page ----------------

    private fun showManagementPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(6))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(0))
        root.addView(TextView(this).apply {
            text = "モンスター管理表"
            textSize = 20f
            setTextColor(textMain)
            setPadding(0, dp(5), 0, 0)
        })
        manageStats = TextView(this).apply {
            textSize = 13f; setTextColor(textSub); setPadding(0, dp(2), 0, dp(4))
        }
        root.addView(manageStats)
        root.addView(TextView(this).apply {
            text = "アイコンをタップして個別登録 / バックアップ・画像操作は設定タブ"
            textSize = 11f
            setTextColor(textSub)
            setPadding(0, 0, 0, dp(3))
        })
        manageSearch = EditText(this).apply {
            hint = "名前・図鑑No.で検索"; setSingleLine(true); textSize = 16f
        }
        root.addView(manageSearch, LinearLayout.LayoutParams(-1, dp(46)))

        manageMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        root.addView(manageMatchMode, LinearLayout.LayoutParams(-1, dp(40)))

        val f1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manageRank = makeSpinner(rankItems())
        manageFamily = makeSpinner(familyItems())
        f1.addView(manageRank, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f1.addView(manageFamily, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(3) })
        root.addView(f1)

        val f2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        manageSize = makeSpinner(sizeItems())
        onlyUnowned = CheckBox(this).apply { text = "未所持のみ"; textSize = 14f }
        f2.addView(manageSize, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f2.addView(onlyUnowned, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(3) })
        root.addView(f2)

        manageList = ListView(this).apply {
            divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = true
        }
        monsterAdapter = MonsterAdapter(this)
        manageList.adapter = monsterAdapter
        root.addView(manageList, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        manageSearch.addTextChangedListener(watcher { applyManagementFilter() })
        manageMatchMode.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageRank.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageFamily.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageSize.onItemSelectedListener = filterListener { applyManagementFilter() }
        onlyUnowned.setOnCheckedChangeListener { _, _ -> applyManagementFilter() }
        applyManagementFilter()
    }

    private fun rankItems() = arrayOf("ランク:すべて") +
        listOf("SS","S","A","B","C","D","E","F").filter { r -> monsters.any { it.rank == r } }.toTypedArray()
    private fun familyItems() = arrayOf("系統:すべて") + monsters.map { it.family }.distinct().sorted().toTypedArray()
    private fun sizeItems() = arrayOf("サイズ:すべて") + monsters.map { it.size }.distinct().sorted().toTypedArray()

    private fun male(no: Int) = maleCounts[no] ?: 0
    private fun female(no: Int) = femaleCounts[no] ?: 0
    private fun both(no: Int) = bothCounts[no] ?: 0
    private fun owned(m: Monster) = male(m.no) + female(m.no) + both(m.no)

    private fun setCount(no: Int, mv: Int? = null, fv: Int? = null, bv: Int? = null) {
        if (mv != null) maleCounts[no] = mv.coerceAtLeast(0)
        if (fv != null) femaleCounts[no] = fv.coerceAtLeast(0)
        if (bv != null) bothCounts[no] = bv.coerceAtLeast(0)
        pref.edit().apply {
            if (mv != null) putInt("m$no", male(no))
            if (fv != null) putInt("f$no", female(no))
            if (bv != null) putInt("b$no", both(no))
        }.apply()
    }

    private fun applyManagementFilter() {
        if (!::monsterAdapter.isInitialized) return
        val q = manageSearch.text?.toString()?.trim().orEmpty()
        val exact = manageMatchMode.selectedItemPosition == 1
        val r = manageRank.selectedItem?.toString() ?: "ランク:すべて"
        val f = manageFamily.selectedItem?.toString() ?: "系統:すべて"
        val s = manageSize.selectedItem?.toString() ?: "サイズ:すべて"
        filteredMonsters.clear()
        filteredMonsters.addAll(monsters.filter { m ->
            (q.isEmpty() || textMatches(m.name, q, exact) || (if (exact) m.no.toString() == q else m.no.toString().contains(q))) &&
            (r == "ランク:すべて" || m.rank == r) &&
            (f == "系統:すべて" || m.family == f) &&
            (s == "サイズ:すべて" || m.size == s) &&
            (!onlyUnowned.isChecked || owned(m) == 0)
        })
        monsterAdapter.notifyDataSetChanged()
        val kinds = monsters.count { owned(it) > 0 }
        manageStats.text = "図鑑 ${monsters.size}体 / 所持種類 $kinds / 総所持数 ${monsters.sumOf { owned(it) }} / 表示 ${filteredMonsters.size}"
    }

    private fun changeCount(m: Monster, sex: Int, delta: Int) {
        val current = when (sex) { 0 -> male(m.no); 1 -> female(m.no); else -> both(m.no) }
        val next = (current + delta).coerceAtLeast(0)
        when (sex) {
            0 -> setCount(m.no, mv = next)
            1 -> setCount(m.no, fv = next)
            else -> setCount(m.no, bv = next)
        }
        monsterAdapter.notifyDataSetChanged()
        applyManagementFilter()
    }

    private inner class MonsterAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredMonsters.size
        override fun getItem(position: Int) = filteredMonsters[position]
        override fun getItemId(position: Int) = getItem(position).no.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView as? LinearLayout ?: createRow()
            bind(row, getItem(position))
            return row
        }

        private fun createRow(): LinearLayout {
            val outer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(4), dp(3), dp(4))
            }

            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = roundedBg(card, 12)
                elevation = dp(2).toFloat()
                tag = "card"
            }

            val header = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            header.addView(FrameLayout(this@MainActivity).apply {
                tag = "iconFrame"

                addView(ImageView(this@MainActivity).apply {
                    tag = "iconImage"
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    visibility = View.GONE
                    background = roundedBg(Color.rgb(235,238,242), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))

                addView(TextView(this@MainActivity).apply {
                    tag = "iconFallback"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = roundedBg(Color.rgb(96,125,139), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })

            header.addView(TextView(this@MainActivity).apply {
                tag = "title"
                textSize = 16f
                maxLines = 2
                setTextColor(textMain)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            header.addView(Button(this@MainActivity).apply {
                tag = "breed"
                text = "配合"
                textSize = 12f
                styleButton(this, breedingColor)
            }, LinearLayout.LayoutParams(dp(62), dp(38)).apply { marginEnd = dp(4) })

            header.addView(Button(this@MainActivity).apply {
                tag = "memo"
                text = "メモ"
                textSize = 12f
                styleButton(this, accentOrange)
            }, LinearLayout.LayoutParams(dp(54), dp(38)))

            box.addView(header)

            val tags = LinearLayout(this@MainActivity).apply {
                tag = "tags"
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(52), dp(5), 0, dp(7))
            }
            box.addView(tags)

            val counts = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            fun countGroup(labelTag: String, minusTag: String, plusTag: String): LinearLayout =
                LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    // Keep the count and its +/- buttons visually together.
                    // The previous weighted label expanded into the spare width and made
                    // the count look detached from the buttons, especially with 3 sexes.
                    addView(label(labelTag), LinearLayout.LayoutParams(dp(40), dp(38)))
                    addView(btn(minusTag), LinearLayout.LayoutParams(dp(29), dp(38)).apply {
                        marginStart = dp(1); marginEnd = dp(1)
                    })
                    addView(btn(plusTag), LinearLayout.LayoutParams(dp(29), dp(38)).apply {
                        marginStart = dp(1)
                    })
                }

            val maleGroup = countGroup("male", "mminus", "mplus")
            val femaleGroup = countGroup("female", "fminus", "fplus")
            val bothGroup = countGroup("both", "bminus", "bplus")

            counts.addView(maleGroup, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(1) })
            counts.addView(femaleGroup, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(1); marginEnd = dp(1) })
            counts.addView(bothGroup, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(1) })

            box.addView(counts)
            outer.addView(box)
            return outer
        }

        private fun label(t: String) = TextView(this@MainActivity).apply {
            tag=t
            textSize=if (t == "both") 14.5f else 16f
            gravity=Gravity.CENTER
            setTextColor(when (t) {
                "male" -> primary
                "female" -> Color.rgb(220, 70, 80)
                else -> Color.rgb(0, 150, 90)
            })
        }
        private fun btn(t: String) = Button(this@MainActivity).apply {
            tag=t
            textSize=20f
            when(t) {
                "mplus", "fplus", "bplus" -> styleCountButton(this, primary)
                "mminus", "fminus", "bminus" -> styleCountButton(this, Color.rgb(220, 70, 80))
                else -> { textSize = 15f; styleButton(this, accentOrange) }
            }
        }

        private fun bind(row: LinearLayout, m: Monster) {
            row.findViewWithTag<TextView>("title").text =
                String.format("No.%03d  %s", m.no, m.name)

            val iconImage = row.findViewWithTag<ImageView>("iconImage")
            val iconFallback = row.findViewWithTag<TextView>("iconFallback")
            val iconFrame = row.findViewWithTag<FrameLayout>("iconFrame")

            applyMonsterIcon(iconImage, iconFallback, m)
            iconFrame.setOnClickListener { openImageMenu(m) }
            iconFrame.setOnLongClickListener {
                openImageMenu(m)
                true
            }

            val tags = row.findViewWithTag<LinearLayout>("tags")
            tags.removeAllViews()
            addTag(tags, m.rank, rankColor(m.rank))
            addTag(tags, m.family, breedingColor)
            addTag(tags, m.size, Color.rgb(96,125,139))

            val cardView = row.findViewWithTag<LinearLayout>("card")
            cardView.background = roundedBg(
                if (owned(m) > 0) primarySoft else card,
                12
            )

            row.findViewWithTag<TextView>("male").text = "♂ ${male(m.no)}"
            row.findViewWithTag<TextView>("female").text = "♀ ${female(m.no)}"
            row.findViewWithTag<TextView>("both").text = "♂♀ ${both(m.no)}"
            row.findViewWithTag<Button>("breed").setOnClickListener { showBreedingForMonster(m) }
            row.findViewWithTag<Button>("mminus").apply { text="−"; setOnClickListener { changeCount(m,0,-1) } }
            row.findViewWithTag<Button>("mplus").apply { text="+"; setOnClickListener { changeCount(m,0,1) } }
            row.findViewWithTag<Button>("fminus").apply { text="−"; setOnClickListener { changeCount(m,1,-1) } }
            row.findViewWithTag<Button>("fplus").apply { text="+"; setOnClickListener { changeCount(m,1,1) } }
            row.findViewWithTag<Button>("bminus").apply { text="−"; setOnClickListener { changeCount(m,2,-1) } }
            row.findViewWithTag<Button>("bplus").apply { text="+"; setOnClickListener { changeCount(m,2,1) } }
            row.findViewWithTag<Button>("memo").apply { text="メモ"; setOnClickListener { editMemo(m) } }
        }
    }

    // ---------------- Breeding page ----------------


    // ---------------- Settings / trial import ----------------

    private fun showSettingsPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(2))
        root.addView(TextView(this).apply {
            text = "設定"
            textSize = 20f
            setTextColor(textMain)
            setPadding(0, dp(5), 0, dp(3))
        })
        root.addView(TextView(this).apply {
            text = "管理データ・モンスター画像・試験機能をここにまとめています。"
            textSize = 12f
            setTextColor(textSub)
            setPadding(0, 0, 0, dp(9))
        })

        fun sectionTitle(textValue: String) = TextView(this).apply {
            text = textValue
            textSize = 15f
            setTextColor(textMain)
            setPadding(dp(3), dp(11), 0, dp(5))
        }
        fun actionButton(textValue: String, color: Int, action: () -> Unit) = Button(this).apply {
            text = textValue
            textSize = 13f
            styleButton(this, color)
            setOnClickListener { action() }
        }
        fun note(textValue: String) = TextView(this).apply {
            text = textValue
            textSize = 11f
            setTextColor(textSub)
            setPadding(dp(5), dp(3), dp(5), dp(5))
        }

        root.addView(sectionTitle("管理データ"))
        val backupRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        backupRow.addView(actionButton("バックアップ", primary) { backup() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
        backupRow.addView(actionButton("復元", Color.rgb(96,125,139)) { restore() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3) })
        root.addView(backupRow)
        root.addView(note("対象: ♂・♀・♂♀の所有数 / お気に入り / メモ（モンスター画像は含みません）"))

        root.addView(sectionTitle("モンスター画像"))
        root.addView(actionButton("アルテマからモンスター画像を一括取得", breedingColor) { confirmAltemaImageDownload() }, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(actionButton("保存したZIPからモンスター画像を読み込み", Color.rgb(0,105,92)) { startMonsterImagesZipImport() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        root.addView(actionButton("取得済みモンスター画像をZIP書き出し", Color.rgb(69,90,100)) { exportMonsterImagesZip() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        root.addView(note("ZIP読み込みは、このアプリで書き出した TerrySP_monster_icons.zip に対応します。既存画像は同じ図鑑No.の画像で上書きされます。"))

        root.addView(sectionTitle("試験機能"))
        root.addView(actionButton("所有状態取得（スクリーンショット解析）", Color.rgb(46,125,50)) { startTrialOwnershipImport() }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(note("配合画面の『預かり所』スクリーンショットを複数選択できます。右上のパーティ表示は除外し、左下の青=♂ / 赤=♀ / 緑=♂♀を判定します。認識結果を確認してから管理表へ反映します。"))

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun startMonsterImagesZipImport() {
        AlertDialog.Builder(this)
            .setTitle("モンスター画像ZIPを読み込み")
            .setMessage("このアプリで書き出した TerrySP_monster_icons.zip を選択してください。\n\nZIP内の図鑑No.を読み取り、端末内のモンスター画像へ登録します。同じ図鑑No.の既存画像は上書きされます。所有数・メモ・お気に入りには影響しません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("ZIPを選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/zip"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 1006)
            }
            .show()
    }

    private fun importMonsterImagesZip(uri: Uri) {
        Toast.makeText(this, "画像ZIPを読み込んでいます…", Toast.LENGTH_SHORT).show()
        Thread {
            var imported = 0
            var skipped = 0
            var failed = 0
            val importedNos = HashSet<Int>()
            try {
                val iconDir = File(filesDir, "monster_icons").apply { mkdirs() }
                contentResolver.openInputStream(uri)?.use { raw ->
                    ZipInputStream(raw.buffered()).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            if (!entry.isDirectory) {
                                val fileName = entry.name.substringAfterLast('/')
                                val no = parseMonsterNoFromZipName(fileName)
                                if (no == null || no !in 1..659 || no in importedNos) {
                                    skipped++
                                } else {
                                    try {
                                        // Exported icons are small PNGs. Cap each inflated entry to 4 MiB.
                                        val bytes = java.io.ByteArrayOutputStream()
                                        val buf = ByteArray(8192)
                                        var total = 0
                                        while (true) {
                                            val n = zip.read(buf)
                                            if (n <= 0) break
                                            total += n
                                            if (total > 4 * 1024 * 1024) throw IllegalArgumentException("画像が大きすぎます")
                                            bytes.write(buf, 0, n)
                                        }
                                        val bitmap = BitmapFactory.decodeByteArray(bytes.toByteArray(), 0, bytes.size())
                                        if (bitmap == null || bitmap.width < 8 || bitmap.height < 8) {
                                            failed++
                                        } else {
                                            val outFile = File(iconDir, "monster_${no.toString().padStart(3,'0')}.img")
                                            outFile.outputStream().buffered().use { out ->
                                                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                                                    throw IllegalStateException("画像保存に失敗しました")
                                                }
                                            }
                                            importedNos.add(no)
                                            imported++
                                        }
                                    } catch (_: Throwable) {
                                        failed++
                                    }
                                }
                            }
                            try { zip.closeEntry() } catch (_: Throwable) { }
                        }
                    }
                } ?: throw IllegalStateException("ZIPを開けませんでした")
                runOnUiThread {
                    if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPを読み込みました")
                        .setMessage("登録: ${imported}体\nスキップ: ${skipped}件\n失敗: ${failed}件\n\n同じ図鑑No.の画像は上書きされています。")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPの読み込みに失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }.start()
    }

    private fun parseMonsterNoFromZipName(fileName: String): Int? {
        // Current export format: 001_スライム.png
        Regex("^(\\d{1,3})(?:[_\\-. ]|$)").find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        // Also accept the app's internal-style name if a user has archived it manually.
        Regex("^monster[_-]?(\\d{1,3})", RegexOption.IGNORE_CASE).find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        return null
    }

    private fun startTrialOwnershipImport() {
        val iconDir = File(filesDir, "monster_icons")
        val imageCount = monsters.count { File(iconDir, "monster_${it.no.toString().padStart(3,'0')}.img").exists() }
        if (imageCount < 20) {
            AlertDialog.Builder(this)
                .setTitle("モンスター画像が不足しています")
                .setMessage("試験機能では取得済みのモンスター画像を照合に使用します。現在 ${imageCount}体分です。\n\n先に『アルテマからモンスター画像を一括取得』または『保存したZIPからモンスター画像を読み込み』を実行してください。")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("試験機能: 所有状態取得")
            .setMessage("テリワンSPの配合画面で『預かり所』を表示したスクリーンショットを選択します。\n\n・1ページ15枠を解析\n・右上の赤フラッグ/青矢印は判定対象外\n・左下の青=♂ / 赤=♀ / 緑=♂♀\n・同じ個体が複数画像に含まれる場合は重複集計されます\n\n現在は試験版のため、反映前に必ず認識結果を確認してください。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("画像を選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 1005)
            }
            .show()
    }

    private fun handleTrialScreenshots(data: Intent) {
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        data.data?.let { if (!uris.contains(it)) uris.add(it) }
        if (uris.isEmpty()) return

        Toast.makeText(this, "${uris.size}枚を解析しています…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val refs = loadTrialReferenceBitmaps()
                val results = mutableListOf<TrialRecognition>()
                var failedPages = 0
                uris.forEach { uri ->
                    val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    if (bmp == null) failedPages++ else results.addAll(analyzeTrialScreenshot(bmp, refs))
                }
                runOnUiThread { showTrialResults(results, uris.size, failedPages) }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("解析に失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun loadTrialReferenceBitmaps(): Map<Int, Bitmap> {
        val out = HashMap<Int, Bitmap>()
        val dir = File(filesDir, "monster_icons")
        monsters.forEach { m ->
            val f = File(dir, "monster_${m.no.toString().padStart(3,'0')}.img")
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.let { out[m.no] = it }
        }
        return out
    }

    private fun analyzeTrialScreenshot(src: Bitmap, refs: Map<Int, Bitmap>): List<TrialRecognition> {
        // v2.6.2: icon boxes are cropped more tightly than v2.6.1.
        // This reduces the influence of the rank badge, sex badge and party markers.
        val xNorm = doubleArrayOf(0.126, 0.312, 0.498, 0.685, 0.872)
        val yNorm = doubleArrayOf(0.215, 0.292, 0.369)
        val side = (src.width * 0.094).toInt().coerceAtLeast(44)
        val results = mutableListOf<TrialRecognition>()
        for (yn in yNorm) for (xn in xNorm) {
            val cx = (src.width * xn).toInt()
            val cy = (src.height * yn).toInt()
            val left = (cx - side/2).coerceIn(0, src.width-1)
            val top = (cy - side/2).coerceIn(0, src.height-1)
            val w = side.coerceAtMost(src.width-left)
            val h = side.coerceAtMost(src.height-top)
            if (w < 20 || h < 20) continue
            val crop = Bitmap.createBitmap(src, left, top, w, h)
            val sex = detectTrialSex(crop)
            val match = matchTrialMonsterV262(crop, refs)
            crop.recycle()
            if (sex >= 0 && match.no > 0) {
                // Do not silently accept ambiguous matches. They remain visible in the result dialog.
                val accepted = match.score >= 0.56 && match.margin >= 0.025
                results.add(TrialRecognition(match.no, sex, match.score, match.secondNo, match.margin, accepted))
            }
        }
        return results
    }

    private fun detectTrialSex(crop: Bitmap): Int {
        // Only the lower-left overlay is inspected. Top-right party markers are never inspected.
        val x0 = 0
        val x1 = (crop.width * 0.34).toInt().coerceAtMost(crop.width)
        val y0 = (crop.height * 0.57).toInt()
        val y1 = crop.height
        var blue = 0; var red = 0; var green = 0
        for (y in y0 until y1 step 2) for (x in x0 until x1 step 2) {
            val c = crop.getPixel(x,y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (b > 105 && b > r * 1.18 && b > g * 1.04) blue++
            if (r > 115 && r > g * 1.18 && r > b * 1.08) red++
            if (g > 100 && g > r * 1.08 && g > b * 1.01) green++
        }
        val max = maxOf(blue, red, green)
        if (max < 3) return -1
        return when(max) { blue -> 0; red -> 1; else -> 2 }
    }

    private data class TrialMatch(val no: Int, val score: Double, val secondNo: Int, val margin: Double)

    private fun matchTrialMonsterV262(crop: Bitmap, refs: Map<Int, Bitmap>): TrialMatch {
        // Multi-feature comparison designed for the TerrySP icon artwork.
        // 1) ignore the three overlay corners, 2) compare colour and edge structure,
        // 3) allow a small alignment shift, 4) require separation from the second candidate.
        val size = 30
        val c = Bitmap.createScaledBitmap(crop, size, size, true)
        val cp = IntArray(size*size); c.getPixels(cp,0,size,0,0,size,size)
        val cGray = IntArray(size*size)
        for (i in cp.indices) {
            val px = cp[i]
            cGray[i] = (Color.red(px)*30 + Color.green(px)*59 + Color.blue(px)*11) / 100
        }

        var bestNo = -1; var bestScore = -1.0
        var secondNo = -1; var secondScore = -1.0

        fun ignored(x: Int, y: Int): Boolean {
            // top-left rank badge / bottom-left sex badge / top-right party badge
            if (x < 9 && y < 9) return true
            if (x < 10 && y > 18) return true
            if (x > 20 && y < 10) return true
            // outermost frame is less useful than monster artwork
            if (x < 2 || y < 2 || x > 27 || y > 27) return true
            return false
        }

        refs.forEach { (no, refBmp) ->
            val r = Bitmap.createScaledBitmap(refBmp, size, size, true)
            val rp = IntArray(size*size); r.getPixels(rp,0,size,0,0,size,size)
            val rGray = IntArray(size*size)
            for (i in rp.indices) {
                val px = rp[i]
                rGray[i] = (Color.red(px)*30 + Color.green(px)*59 + Color.blue(px)*11) / 100
            }

            var candidateBest = -1.0
            for (dy in -2..2) for (dx in -2..2) {
                var colorDiff = 0.0
                var edgeDiff = 0.0
                var n = 0
                for (y in 3 until 27) for (x in 3 until 27) {
                    if (ignored(x,y)) continue
                    val rx = x + dx; val ry = y + dy
                    if (rx !in 2..27 || ry !in 2..27 || ignored(rx,ry)) continue
                    val a = cp[y*size+x]; val b = rp[ry*size+rx]
                    val dr = Color.red(a)-Color.red(b)
                    val dg = Color.green(a)-Color.green(b)
                    val db = Color.blue(a)-Color.blue(b)
                    colorDiff += (dr*dr + dg*dg + db*db).toDouble() / 3.0

                    val cgx = cGray[y*size + (x+1)] - cGray[y*size + (x-1)]
                    val cgy = cGray[(y+1)*size + x] - cGray[(y-1)*size + x]
                    val rgx = rGray[ry*size + (rx+1).coerceAtMost(29)] - rGray[ry*size + (rx-1).coerceAtLeast(0)]
                    val rgy = rGray[(ry+1).coerceAtMost(29)*size + rx] - rGray[(ry-1).coerceAtLeast(0)*size + rx]
                    val ed = kotlin.math.abs(cgx-rgx) + kotlin.math.abs(cgy-rgy)
                    edgeDiff += ed.toDouble()
                    n++
                }
                if (n > 30) {
                    val colorRmse = kotlin.math.sqrt(colorDiff/n) / 255.0
                    val edgeMean = (edgeDiff/n) / 510.0
                    val score = (1.0 - (colorRmse*0.68 + edgeMean*0.32)).coerceIn(0.0,1.0)
                    if (score > candidateBest) candidateBest = score
                }
            }
            if (candidateBest > bestScore) {
                secondScore = bestScore; secondNo = bestNo
                bestScore = candidateBest; bestNo = no
            } else if (candidateBest > secondScore) {
                secondScore = candidateBest; secondNo = no
            }
            if (r !== refBmp) r.recycle()
        }
        c.recycle()
        return TrialMatch(bestNo, bestScore, secondNo, (bestScore-secondScore).coerceAtLeast(0.0))
    }

    private fun showTrialResults(results: List<TrialRecognition>, pages: Int, failedPages: Int) {
        if (results.isEmpty()) {
            AlertDialog.Builder(this).setTitle("認識できませんでした")
                .setMessage("${pages}枚を解析しましたが、候補を取得できませんでした。\n\n配合画面の『預かり所』が画面上部に表示された、今回と同じ形式のスクリーンショットを使用してください。")
                .setPositiveButton("OK", null).show()
            return
        }
        val accepted = results.filter { it.accepted }
        val pending = results.filter { !it.accepted }
        val grouped = accepted.groupBy { Pair(it.no,it.sex) }.mapValues { it.value.size }
            .toSortedMap(compareBy<Pair<Int,Int>> { it.first }.thenBy { it.second })
        val sexText = arrayOf("♂","♀","♂♀")
        val lines = grouped.entries.mapNotNull { e ->
            val m = monsters.firstOrNull { it.no == e.key.first } ?: return@mapNotNull null
            val avg = accepted.filter { it.no == e.key.first && it.sex == e.key.second }.map { it.confidence }.average()
            "No.${m.no.toString().padStart(3,'0')} ${m.name}  ${sexText[e.key.second]} ×${e.value}  ${(avg*100).toInt()}%"
        }
        val pendingLines = pending.take(15).map { r ->
            val a = monsters.firstOrNull { it.no == r.no }?.name ?: "No.${r.no}"
            val b = monsters.firstOrNull { it.no == r.secondNo }?.name ?: "候補なし"
            "${sexText[r.sex]}  ${a} ${(r.confidence*100).toInt()}% / 次点 ${b}  差${(r.margin*100).toInt()}%"
        }
        val msg = buildString {
            append("解析画像: ${pages}枚")
            if (failedPages > 0) append("（読込失敗 ${failedPages}枚）")
            append("\n検出枠: ${results.size}体")
            append("\n自動確定: ${accepted.size}体 / 判定保留: ${pending.size}体")
            if (accepted.isNotEmpty()) {
                append("\n\n【自動確定】\n")
                append(lines.take(40).joinToString("\n"))
            }
            if (pending.isNotEmpty()) {
                append("\n\n【判定保留（管理表へ加算しません）】\n")
                append(pendingLines.joinToString("\n"))
                if (pending.size > pendingLines.size) append("\n…ほか ${pending.size-pendingLines.size}体")
            }
            append("\n\nv2.6.2では1位と2位の差が小さい候補を自動反映しません。『管理表へ加算』では自動確定分だけを加算します。")
        }
        AlertDialog.Builder(this)
            .setTitle("所有状態 解析結果（v2.6.2）")
            .setMessage(msg)
            .setNegativeButton("キャンセル", null)
            .setNeutralButton("結果だけ確認", null)
            .setPositiveButton(if (accepted.isEmpty()) "確定候補なし" else "確定分を加算") { _, _ ->
                if (accepted.isEmpty()) {
                    Toast.makeText(this, "自動確定できた候補がありません", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val edit = pref.edit()
                grouped.forEach { (key, count) ->
                    val no = key.first
                    when(key.second) {
                        0 -> { maleCounts[no] = male(no)+count; edit.putInt("m$no", male(no)) }
                        1 -> { femaleCounts[no] = female(no)+count; edit.putInt("f$no", female(no)) }
                        else -> { bothCounts[no] = both(no)+count; edit.putInt("b$no", both(no)) }
                    }
                }
                edit.apply()
                Toast.makeText(this, "自動確定した ${accepted.size}体を所有数へ加算しました", Toast.LENGTH_LONG).show()
                showManagementPage()
            }.show()
    }

    private fun showBreedingPage(query: String = "", direction: Int = 0) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(7),dp(10),dp(4)); setBackgroundColor(bg)
        }
        root.addView(topMenu(1))
        root.addView(TextView(this).apply {
            text="配合表"; textSize=20f; setTextColor(textMain); setPadding(0,dp(5),0,0)
        })
        breedStats = TextView(this).apply { textSize=13f; setTextColor(textSub); setPadding(0,dp(2),0,dp(4)) }
        root.addView(breedStats)

        breedDirection = makeSpinner(arrayOf("子 → 親を検索","親 → 子を検索"))
        breedDirection.setSelection(direction)
        root.addView(breedDirection, LinearLayout.LayoutParams(-1,dp(43)))

        breedSearch = EditText(this).apply {
            hint = if (direction == 0) "子モンスター名・図鑑No." else "親モンスター名・系統条件"
            setSingleLine(true); textSize=16f; setText(query)
        }
        root.addView(breedSearch, LinearLayout.LayoutParams(-1,dp(46)))

        val searchOptions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        breedMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        breedSortOrder = makeSpinner(arrayOf("昇順", "降順"))
        searchOptions.addView(breedMatchMode, LinearLayout.LayoutParams(0,dp(40),1f).apply { marginEnd=dp(3) })
        searchOptions.addView(breedSortOrder, LinearLayout.LayoutParams(0,dp(40),1f).apply { marginStart=dp(3) })
        root.addView(searchOptions)

        breedSort = makeSpinner(arrayOf("ソート:結果No", "ソート:結果名", "ソート:親No", "ソート:親名", "ソート:配合種別"))
        root.addView(breedSort, LinearLayout.LayoutParams(-1,dp(40)))

        val f1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        breedType = makeSpinner(arrayOf("配合:すべて","2体配合","4体配合"))
        breedRank = makeSpinner(rankItems())
        f1.addView(breedType, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginEnd=dp(3)})
        f1.addView(breedRank, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginStart=dp(3)})
        root.addView(f1)

        val f2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        breedFamily = makeSpinner(familyItems())
        breedSize = makeSpinner(sizeItems())
        f2.addView(breedFamily, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginEnd=dp(3)})
        f2.addView(breedSize, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginStart=dp(3)})
        root.addView(f2)

        breedList = ListView(this).apply { dividerHeight=1; isVerticalScrollBarEnabled=true }
        breedingAdapter = BreedingAdapter(this)
        breedList.adapter = breedingAdapter
        root.addView(breedList, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)

        breedSearch.addTextChangedListener(watcher { applyBreedingFilter() })
        breedMatchMode.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSort.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSortOrder.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedDirection.onItemSelectedListener = filterListener {
            breedSearch.hint = if (breedDirection.selectedItemPosition == 0) "子モンスター名・図鑑No." else "親モンスター名・系統条件"
            applyBreedingFilter()
        }
        breedType.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedRank.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedFamily.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSize.onItemSelectedListener = filterListener { applyBreedingFilter() }
        applyBreedingFilter()
    }

    private fun showBreedingForMonster(m: Monster) {
        showBreedingPage(m.name, 0)
    }

    private fun applyBreedingFilter() {
        if (!::breedingAdapter.isInitialized) return
        val q = breedSearch.text?.toString()?.trim().orEmpty()
        val exact = breedMatchMode.selectedItemPosition == 1
        val direction = breedDirection.selectedItemPosition
        val type = breedType.selectedItem?.toString() ?: "配合:すべて"
        val rank = breedRank.selectedItem?.toString() ?: "ランク:すべて"
        val family = breedFamily.selectedItem?.toString() ?: "系統:すべて"
        val size = breedSize.selectedItem?.toString() ?: "サイズ:すべて"

        filteredRecipes.clear()
        filteredRecipes.addAll(recipes.filter { r ->
            val resultMonster = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
            val qOk = if (q.isEmpty()) true else if (direction == 0) {
                textMatches(r.resultName, q, exact) ||
                    (if (exact) r.resultNo?.toString() == q else r.resultNo?.toString()?.contains(q) == true)
            } else {
                r.parents.any { textMatches(it, q, exact) }
            }
            qOk &&
            (type == "配合:すべて" || r.type == type) &&
            (rank == "ランク:すべて" || resultMonster?.rank == rank || r.resultRank == rank) &&
            (family == "系統:すべて" || resultMonster?.family == family || r.resultFamily == family) &&
            (size == "サイズ:すべて" || resultMonster?.size == size || r.resultSize == size)
        })
        val sortMode = breedSort.selectedItemPosition
        val desc = breedSortOrder.selectedItemPosition == 1
        val comparator = when(sortMode) {
            1 -> compareBy<BreedingRecipe> { it.resultName.lowercase() }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            2 -> compareBy<BreedingRecipe> { firstParentNo(it) }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            3 -> compareBy<BreedingRecipe> { firstParentName(it).lowercase() }.thenBy { it.resultName.lowercase() }
            4 -> compareBy<BreedingRecipe> { it.type }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            else -> compareBy<BreedingRecipe> { it.resultNo ?: Int.MAX_VALUE }.thenBy { it.resultName.lowercase() }
        }
        filteredRecipes.sortWith(if (desc) comparator.reversed() else comparator)

        breedingAdapter.notifyDataSetChanged()
        breedStats.text = "配合レシピ ${recipes.size}件 / 表示 ${filteredRecipes.size}件"
    }

    private inner class BreedingAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredRecipes.size
        override fun getItem(position: Int) = filteredRecipes[position]
        override fun getItemId(position: Int) = getItem(position).id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val outer = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(4), dp(4), dp(4))

                val recipeCard = LinearLayout(this@MainActivity).apply {
                    tag = "recipeCard"
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(11), dp(9), dp(11), dp(9))
                    background = roundedBg(Color.WHITE, 12)
                    elevation = dp(1).toFloat()
                }

                recipeCard.addView(TextView(this@MainActivity).apply {
                    tag = "parentLine"
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    background = roundedBg(breedingColor, 9)
                })

                recipeCard.addView(LinearLayout(this@MainActivity).apply {
                    tag = "childrenBox"
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(7), 0, 0)
                })

                addView(recipeCard)
            }

            val r = getItem(position)
            val parentLine = outer.findViewWithTag<TextView>("parentLine")
            val childrenBox = outer.findViewWithTag<LinearLayout>("childrenBox")

            val resultNoText = r.resultNo?.let { String.format("No.%03d", it) } ?: "No.---"
            parentLine.text = "親  $resultNoText  ${r.resultName}   [${r.type}]"

            childrenBox.removeAllViews()
            r.parents.take(4).forEachIndexed { index, name ->
                val childNo = monsterByName[name]?.no
                val childNoText = childNo?.let { String.format("No.%03d", it) } ?: "条件"
                val tv = TextView(this@MainActivity).apply {
                    text = "子${index + 1}  $childNoText  $name"
                    textSize = 14f
                    setTextColor(textMain)
                    setPadding(dp(9), dp(6), dp(9), dp(6))
                    background = roundedBg(
                        if (index % 2 == 0) primarySoft else breedingSoft,
                        8
                    )
                }
                childrenBox.addView(tv, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(4) })
            }

            outer.setOnClickListener { showRecipeDetail(r) }
            return outer
        }
    }

    private fun showRecipeDetail(r: BreedingRecipe) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8)) }
        val m = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
        box.addView(TextView(this).apply {
            text = buildString {
                append(if (m != null) "No.${m.no} ${m.name}" else r.resultName)
                if (m != null) append("\n${m.rank} / ${m.family} / ${m.size}")
                append("\n\n【このモンスターを作る親】\n")
                append(r.parents.joinToString(" × "))
                append("\n\n配合種別: ${r.type}")
                if (r.note.isNotBlank()) append("\n備考: ${r.note}")
            }
            textSize=16f; setTextColor(textSub)
        })

        box.addView(TextView(this).apply {
            text="\n親から子を調べる"; textSize=15f; setTextColor(textMain)
        })
        r.parents.distinct().forEach { parent ->
            val pm = monsterByName[parent]
            if (pm != null) {
                box.addView(Button(this).apply {
                    text = "${pm.name} を親にした子を検索"
                    setOnClickListener { showBreedingPage(pm.name,1) }
                })
            } else {
                box.addView(Button(this).apply {
                    text = "$parent で子を検索"
                    setOnClickListener { showBreedingPage(parent,1) }
                })
            }
        }

        val children = recipes.filter { rr -> rr.parents.any { it == r.resultName } }.map { it.resultName }.distinct()
        if (children.isNotEmpty()) {
            box.addView(TextView(this).apply {
                text="\n【${r.resultName}を親に使う子】\n${children.joinToString(" / ")}"
                textSize=15f; setTextColor(textSub)
            })
        }
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("配合詳細")
            .setView(scroll)
            .setNegativeButton("閉じる",null)
            .setPositiveButton("この子で検索") { _,_ -> showBreedingPage(r.resultName,0) }
            .show()
    }

    // ---------------- Memo / backup ----------------

    private fun editMemo(m: Monster) {
        val input = EditText(this).apply {
            setSingleLine(false); minLines=2; maxLines=5; setText(notes[m.no].orEmpty()); setSelection(text.length)
        }
        val container = FrameLayout(this).apply {
            setPadding(dp(16),0,dp(16),0)
            addView(input, FrameLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this).setTitle("No.${m.no} ${m.name} のメモ").setView(container)
            .setNegativeButton("キャンセル",null)
            .setPositiveButton("保存") { _,_ ->
                notes[m.no]=input.text.toString()
                pref.edit().putString("note${m.no}",notes[m.no].orEmpty()).apply()
            }.show()
    }

    private fun backup() {
        val arr=JSONArray()
        monsters.forEach { m ->
            arr.put(JSONObject().apply {
                put("no",m.no); put("male",male(m.no)); put("female",female(m.no)); put("both",both(m.no))
                put("favorite",favorites[m.no] ?: false); put("note",notes[m.no].orEmpty())
            })
        }
        backupPayload=arr.toString()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type="application/json"; putExtra(Intent.EXTRA_TITLE,"terrysp_backup.json")
        },1001)
    }

    private fun restore() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="application/json"; addCategory(Intent.CATEGORY_OPENABLE)
        },1002)
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if (res != RESULT_OK || data == null) {
            if (req == 1003) pendingImageMonsterNo = null
            return
        }
        // Multiple image selection may return only clipData and no data URI.
        if (req != 1005 && data.data == null) {
            if (req == 1003) pendingImageMonsterNo = null
            return
        }
        try {
            if(req==1005) {
                handleTrialScreenshots(data)
            } else if(req==1006) {
                importMonsterImagesZip(data.data!!)
            } else if(req==1003) {
                val no = pendingImageMonsterNo
                pendingImageMonsterNo = null
                if (no != null) saveSelectedMonsterImage(data.data!!, no)
            } else if(req==1004) {
                writeMonsterImagesZip(data.data!!)
            } else if(req==1001) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPayload.toByteArray(StandardCharsets.UTF_8)) }
                Toast.makeText(this,"バックアップを保存しました",Toast.LENGTH_SHORT).show()
            } else if(req==1002) {
                val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText() ?: return
                val arr=JSONArray(text); val e=pref.edit()
                for(i in 0 until arr.length()) {
                    val o=arr.getJSONObject(i); val no=o.getInt("no")
                    val mv=o.optInt("male",0).coerceAtLeast(0); val fv=o.optInt("female",0).coerceAtLeast(0)
                    val bv=o.optInt("both",0).coerceAtLeast(0)
                    val n=o.optString("note",""); val fav=o.optBoolean("favorite",false)
                    maleCounts[no]=mv; femaleCounts[no]=fv; bothCounts[no]=bv; notes[no]=n; favorites[no]=fav
                    e.putInt("m$no",mv).putInt("f$no",fv).putInt("b$no",bv).putString("note$no",n).putBoolean("fav$no",fav)
                }
                e.apply()
                if (::monsterAdapter.isInitialized) applyManagementFilter()
                Toast.makeText(this,"復元しました",Toast.LENGTH_SHORT).show()
            }
        } catch (_:Exception) {
            Toast.makeText(this,"ファイルを読み込めませんでした",Toast.LENGTH_LONG).show()
        }
    }
}
