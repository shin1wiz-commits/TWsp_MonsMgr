# TerrySP Monster Manager 1.2

659体のモンスター情報を `app/src/main/assets/monsters.csv` から読み込む軽量版です。

## 最適化内容
- 起動時のデータ読み込みを軽量化
- SharedPreferences の読み込みを一括取得
- 一覧行から常設 EditText を削除し、必要時だけメモ編集ダイアログを表示
- 一覧行をコンパクト化してスクロール時の負荷を軽減
- フィルターを画面幅に合わせて2段構成に変更
- 外部ライブラリを追加せず、Android標準Viewのみで構成
- `monsters.csv` はそのまま編集可能

## データ
CSVは `app/src/main/assets/monsters.csv` にあります。
ヘッダーは次の形式です。

`no,name,rank,family,size`

## GitHub Actions
このZIPをリポジトリに置き、別途 `build-apk.yml` をGitHub Actionsへ配置してビルドします。

## v2.7.1
判断用アイコンをゲーム内の四角い枠基準で正規化し、枠外背景とランク/性別/パーティ表示領域を照合対象から除外しました。未登録個体は、表示用アイコン＋モンスター名の候補を見ながらタップして登録できます。候補外は図鑑No./名前検索を利用できます。同じ解析内に同一アイコンが複数ある場合は、1体の登録後に高一致個体を再判定します。

## v2.7.4 試験機能
判断用アイコンの切り出しを、個別枠の最終判定から「15枠全体の共通5×3グリッド推定」に変更しました。
右端・下端の中央値と共通アイコン幅を使い、全個体を同じサイズ/同じ幾何で切り出します。


## v2.7.5 試験機能

預かり所の5×3理論グリッドを主基準にし、実スクリーンショットに合わせて行間隔と枠サイズを再校正しました。枠検出は数px以内の全体補正だけに制限し、個体の絵柄による切り出しズレを抑えます。

v2.7.7: MediaProjectionを使ったアプリ内画面録画開始に対応。通知から録画停止し、管理アプリへ戻ると録画動画をそのまま所有状態解析できます。音声は録音しません。

## v2.7.9 trial
Video page detection was adjusted for sparse final warehouse pages. The warehouse filter now uses fixed UI/background anchors rather than the number of populated monster slots, and the last five seconds receive a denser rescue scan before recognition.


## v2.8.1 trial
Floating start/stop recording panel and top-3 candidate similarity display. The similarity value is an internal image-comparison score, not a probability of correctness.

v2.8.2: 設定メニュー再整理、所有状態/判断用アイコンの個別ZIPバックアップ・リストア、各種リセット、アイコン状態一覧、解析成功後の録画完了通知自動消去を追加。


## v2.8.10
高度な配合ルートで4体配合の全親/祖父母を表示し、表示ツリー基準の重複除外と循環ルート除外を追加しました。
