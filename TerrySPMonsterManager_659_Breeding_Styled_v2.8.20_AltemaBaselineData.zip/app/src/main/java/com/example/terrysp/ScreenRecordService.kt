package com.example.terrysp

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class ScreenRecordService : Service() {
    companion object {
        const val ACTION_START = "com.example.terrysp.action.START_SCREEN_RECORD"
        const val ACTION_STOP = "com.example.terrysp.action.STOP_SCREEN_RECORD"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "terrysp_screen_record"
        private const val NOTIFICATION_ID = 2761
        private const val PREF_NAME = "monster_state"
        private const val PREF_PENDING_VIDEO = "pending_recorded_video_v277"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private val stopping = AtomicBoolean(false)
    private var recordingStartedAt = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopRecording(fromProjectionCallback = true)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRecording(fromProjectionCallback = false)
            ACTION_START -> startRecording(intent)
        }
        return START_NOT_STICKY
    }

    private fun startRecording(intent: Intent) {
        if (projection != null || recorder != null) return
        createChannel()
        startProjectionForeground(buildRecordingNotification())

        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (resultCode != Activity.RESULT_OK || resultData == null) {
                throw IllegalArgumentException("画面録画の許可情報がありません")
            }

            val metrics = displayMetricsForRecording()
            var width = metrics.first
            var height = metrics.second
            val density = metrics.third
            // H.264 encoders generally require even dimensions.
            width -= width % 2
            height -= height % 2
            if (width <= 0 || height <= 0) throw IllegalStateException("画面サイズを取得できませんでした")

            val dir = File(filesDir, "recordings").apply { mkdirs() }
            val file = File(dir, "terrysp_record_${System.currentTimeMillis()}.mp4")
            outputFile = file

            val mediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder = mediaRecorder
            mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mediaRecorder.setOutputFile(file.absolutePath)
            mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mediaRecorder.setVideoEncodingBitRate(8_000_000)
            mediaRecorder.setVideoFrameRate(30)
            mediaRecorder.setVideoSize(width, height)
            mediaRecorder.prepare()

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, resultData)
            projection = mp
            mp.registerCallback(projectionCallback, null)
            virtualDisplay = mp.createVirtualDisplay(
                "TerrySP ownership capture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mediaRecorder.surface,
                null,
                null
            )
            mediaRecorder.start()
            recordingStartedAt = System.currentTimeMillis()
            refreshRecordingNotification()
        } catch (t: Throwable) {
            cleanupAfterFailure()
            try { startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_SET_WAITING }) } catch (_: Throwable) { }
            notifyFailure(t.message ?: t::class.java.simpleName)
            stopSelf()
        }
    }

    private fun displayMetricsForRecording(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.maximumWindowMetrics.bounds
            Triple(bounds.width(), bounds.height(), resources.configuration.densityDpi)
        } else {
            @Suppress("DEPRECATION")
            val display = wm.defaultDisplay
            val point = Point()
            @Suppress("DEPRECATION")
            display.getRealSize(point)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            display.getRealMetrics(metrics)
            Triple(point.x, point.y, metrics.densityDpi)
        }
    }

    private fun stopRecording(fromProjectionCallback: Boolean) {
        if (!stopping.compareAndSet(false, true)) return
        var validVideo = false
        try {
            try {
                recorder?.stop()
                validVideo = outputFile?.let { it.isFile && it.length() > 16_384L } == true
            } catch (_: Throwable) {
                validVideo = false
            }
            try { recorder?.reset() } catch (_: Throwable) { }
            try { recorder?.release() } catch (_: Throwable) { }
            recorder = null
            try { virtualDisplay?.release() } catch (_: Throwable) { }
            virtualDisplay = null

            val mp = projection
            projection = null
            if (mp != null) {
                try { mp.unregisterCallback(projectionCallback) } catch (_: Throwable) { }
                if (!fromProjectionCallback) {
                    try { mp.stop() } catch (_: Throwable) { }
                }
            }

            val file = outputFile
            outputFile = null
            if (validVideo && file != null) {
                getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit()
                    .putString(PREF_PENDING_VIDEO, file.absolutePath)
                    .apply()
                showFinishedNotification()
            } else {
                try { file?.delete() } catch (_: Throwable) { }
                notifyFailure("録画時間が短すぎるか、動画の保存に失敗しました")
            }
        } finally {
            try { startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_HIDE }) } catch (_: Throwable) { }
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun cleanupAfterFailure() {
        try { recorder?.reset() } catch (_: Throwable) { }
        try { recorder?.release() } catch (_: Throwable) { }
        recorder = null
        try { virtualDisplay?.release() } catch (_: Throwable) { }
        virtualDisplay = null
        projection?.let { mp ->
            try { mp.unregisterCallback(projectionCallback) } catch (_: Throwable) { }
            try { mp.stop() } catch (_: Throwable) { }
        }
        projection = null
        outputFile?.let { try { it.delete() } catch (_: Throwable) { } }
        outputFile = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "所有状態の画面録画", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "テリワンSPの預かり所を読み取るための画面録画"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun startProjectionForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun mainActivityPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(this, 41, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notificationBuilder(): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
    }

    private fun buildRecordingNotification(): Notification {
        val stopIntent = Intent(this, ScreenRecordService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 42, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return notificationBuilder()
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("● 録画中：テリワンSP 所有状態")
            .setContentText("▶ でページ送り / 終わったら［録画停止］")
            .setWhen(if (recordingStartedAt > 0L) recordingStartedAt else System.currentTimeMillis())
            .setUsesChronometer(true)
            .setShowWhen(true)
            .setContentIntent(mainActivityPendingIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "録画停止", stopPending)
            .build()
    }


    private fun refreshRecordingNotification() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, buildRecordingNotification())
        } catch (_: Throwable) { }
    }

    private fun showFinishedNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = notificationBuilder()
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("録画が完了しました")
            .setContentText("タップすると動画を自動解析します")
            .setContentIntent(mainActivityPendingIntent())
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIFICATION_ID + 1, notification)
    }

    private fun notifyFailure(message: String) {
        createChannel()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = notificationBuilder()
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("画面録画に失敗しました")
            .setContentText(message.take(80))
            .setContentIntent(mainActivityPendingIntent())
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIFICATION_ID + 2, notification)
    }

    override fun onDestroy() {
        if ((projection != null || recorder != null) && !stopping.get()) {
            stopRecording(fromProjectionCallback = false)
        }
        super.onDestroy()
    }
}
