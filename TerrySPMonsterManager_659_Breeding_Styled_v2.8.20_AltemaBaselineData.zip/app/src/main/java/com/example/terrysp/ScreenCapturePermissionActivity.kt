package com.example.terrysp

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/**
 * Tiny translucent bridge used only for the Android MediaProjection consent UI.
 *
 * The overlay launches this Activity instead of bringing MainActivity to the
 * foreground.  Because this window is transparent, TerrySP remains visually
 * behind the system consent dialog.  As soon as consent returns, the recording
 * foreground service is started and this Activity finishes immediately.
 */
class ScreenCapturePermissionActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 2810
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
        if (savedInstanceState == null) requestProjectionPermission()
    }

    private fun requestProjectionPermission() {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val captureIntent = if (Build.VERSION.SDK_INT >= 34) {
                manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            } else {
                manager.createScreenCaptureIntent()
            }
            startActivityForResult(captureIntent, REQUEST_CAPTURE)
        } catch (t: Throwable) {
            restoreWaitingOverlay()
            Toast.makeText(applicationContext, "録画許可画面を開けませんでした", Toast.LENGTH_SHORT).show()
            finishWithoutAnimation()
        }
    }

    @Deprecated("Deprecated in Android API; retained for minSdk compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return

        if (resultCode != RESULT_OK || data == null) {
            restoreWaitingOverlay()
            finishWithoutAnimation()
            return
        }

        try {
            val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenRecordService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)

            // The panel changes state while the transparent bridge is closing.
            // No normal manager Activity is shown between consent and TerrySP.
            startService(Intent(this, RecordingOverlayService::class.java).apply {
                action = RecordingOverlayService.ACTION_SET_RECORDING
            })
        } catch (t: Throwable) {
            restoreWaitingOverlay()
            Toast.makeText(applicationContext, "画面録画を開始できませんでした", Toast.LENGTH_SHORT).show()
        } finally {
            finishWithoutAnimation()
        }
    }

    private fun restoreWaitingOverlay() {
        try {
            startService(Intent(this, RecordingOverlayService::class.java).apply {
                action = RecordingOverlayService.ACTION_SET_WAITING
            })
        } catch (_: Throwable) { }
    }

    private fun finishWithoutAnimation() {
        finish()
        overridePendingTransition(0, 0)
    }
}
