package com.example.terrysp

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class RecordingOverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.example.terrysp.action.OVERLAY_SHOW"
        const val ACTION_SET_WAITING = "com.example.terrysp.action.OVERLAY_WAITING"
        const val ACTION_SET_RECORDING = "com.example.terrysp.action.OVERLAY_RECORDING"
        const val ACTION_HIDE = "com.example.terrysp.action.OVERLAY_HIDE"
        const val EXTRA_REQUEST_RECORD_PERMISSION = "request_record_permission_v280"
        private const val PREF_NAME = "monster_state"
    }

    private enum class State { WAITING, RECORDING, STOPPING }
    private var state = State.WAITING
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var status: TextView? = null
    private var actionButton: Button? = null
    private var recordingStartedAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val timer = object : Runnable {
        override fun run() {
            if (state == State.RECORDING) {
                updateUi()
                handler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> { state = State.WAITING; showPanel(); updateUi() }
            ACTION_SET_WAITING -> { state = State.WAITING; recordingStartedAt = 0L; showPanel(); updateUi() }
            ACTION_SET_RECORDING -> {
                state = State.RECORDING
                recordingStartedAt = System.currentTimeMillis()
                showPanel(); updateUi(); handler.removeCallbacks(timer); handler.post(timer)
            }
            ACTION_HIDE -> hideAndStop()
        }
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.argb(70, 255, 255, 255))
    }

    private fun showPanel() {
        if (panel != null) return
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = windowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = rounded(Color.argb(235, 28, 32, 38), 12)
            elevation = dp(8).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val drag = TextView(this).apply {
            text = "≡  テリワンSP取得"
            textSize = 12f; setTextColor(Color.WHITE); setPadding(dp(4), dp(3), dp(8), dp(3))
        }
        val close = Button(this).apply {
            text = "×"; textSize = 15f; setTextColor(Color.WHITE); background = rounded(Color.TRANSPARENT, 8)
            minWidth = 0; minHeight = 0; setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { if (state != State.RECORDING) hideAndStop() }
        }
        header.addView(drag, LinearLayout.LayoutParams(0, dp(32), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(32)))
        root.addView(header, LinearLayout.LayoutParams(dp(220), dp(32)))

        status = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(6)) }
        root.addView(status, LinearLayout.LayoutParams(dp(220), dp(34)))
        actionButton = Button(this).apply {
            isAllCaps = false; minWidth = 0; minHeight = 0; textSize = 14f
            setOnClickListener { onActionButton() }
        }
        root.addView(actionButton, LinearLayout.LayoutParams(dp(220), dp(46)))

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val savedX = getSharedPreferences(PREF_NAME, MODE_PRIVATE).getInt("overlay_x_v280", (screenW - dp(240)) / 2)
        val savedY = getSharedPreferences(PREF_NAME, MODE_PRIVATE).getInt("overlay_y_v280", screenH - dp(210))
        val overlayType = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX.coerceIn(0, maxOf(0, screenW - dp(240)))
            y = savedY.coerceIn(0, maxOf(0, screenH - dp(150)))
        }
        params = lp
        panel = root
        try { windowManager.addView(root, lp) } catch (_: Throwable) { panel = null; stopSelf(); return }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        drag.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = p.x; startY = p.y; true }
                MotionEvent.ACTION_MOVE -> {
                    val maxX = maxOf(0, screenW - dp(240)); val maxY = maxOf(0, screenH - dp(150))
                    p.x = (startX + (ev.rawX - downX).toInt()).coerceIn(0, maxX)
                    p.y = (startY + (ev.rawY - downY).toInt()).coerceIn(0, maxY)
                    try { wm?.updateViewLayout(panel, p) } catch (_: Throwable) { }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit().putInt("overlay_x_v280", p.x).putInt("overlay_y_v280", p.y).apply(); true
                }
                else -> false
            }
        }
    }

    private fun onActionButton() {
        when (state) {
            State.WAITING -> {
                status?.text = "録画許可を確認中…"
                actionButton?.isEnabled = false
                val i = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra(EXTRA_REQUEST_RECORD_PERMISSION, true)
                }
                try {
                    PendingIntent.getActivity(this, 2801, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE).send()
                } catch (t: Throwable) {
                    actionButton?.isEnabled = true; updateUi()
                    Toast.makeText(this, "録画許可画面を開けませんでした", Toast.LENGTH_SHORT).show()
                }
            }
            State.RECORDING -> {
                state = State.STOPPING; handler.removeCallbacks(timer); updateUi()
                getSharedPreferences(PREF_NAME, MODE_PRIVATE).edit().putBoolean("recording_finalize_pending_v280", true).apply()
                try { startService(Intent(this, ScreenRecordService::class.java).apply { action = ScreenRecordService.ACTION_STOP }) } catch (_: Throwable) { }
                handler.postDelayed({
                    val i = Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP) }
                    try { PendingIntent.getActivity(this, 2802, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE).send() } catch (_: Throwable) { }
                    hideAndStop()
                }, 700L)
            }
            State.STOPPING -> Unit
        }
    }

    private fun updateUi() {
        when (state) {
            State.WAITING -> {
                status?.text = "待機中（まだ録画していません）"
                actionButton?.apply { isEnabled = true; text = "● 録画開始"; setTextColor(Color.WHITE); background = rounded(Color.rgb(0, 137, 123), 9) }
            }
            State.RECORDING -> {
                val sec = ((System.currentTimeMillis() - recordingStartedAt).coerceAtLeast(0L) / 1000L).toInt()
                status?.text = "● 録画中  %02d:%02d".format(sec / 60, sec % 60)
                actionButton?.apply { isEnabled = true; text = "■ 録画停止"; setTextColor(Color.WHITE); background = rounded(Color.rgb(198, 40, 40), 9) }
            }
            State.STOPPING -> {
                status?.text = "録画を保存しています…"
                actionButton?.apply { isEnabled = false; text = "停止処理中"; setTextColor(Color.WHITE); background = rounded(Color.rgb(90, 90, 90), 9) }
            }
        }
    }

    private fun hideAndStop() {
        handler.removeCallbacks(timer)
        panel?.let { try { wm?.removeView(it) } catch (_: Throwable) { } }
        panel = null; status = null; actionButton = null; params = null
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(timer)
        panel?.let { try { wm?.removeView(it) } catch (_: Throwable) { } }
        panel = null
        super.onDestroy()
    }
}
