package com.example.terrysp

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

private data class Monster(
    val no: Int,
    val name: String,
    val rank: String,
    val family: String,
    val size: String
)

private data class BreedingRecipe(
    val id: Int,
    val resultNo: Int?,
    val resultName: String,
    val resultRank: String,
    val resultFamily: String,
    val resultSize: String,
    val type: String,
    val parents: List<String>,
    val parentTypes: List<String>,
    val note: String
)

class MainActivity : Activity() {
    private val monsters = mutableListOf<Monster>()
    private val monsterByName = HashMap<String, Monster>()
    private val recipes = mutableListOf<BreedingRecipe>()

    private val maleCounts = HashMap<Int, Int>()
    private val femaleCounts = HashMap<Int, Int>()
    private val notes = HashMap<Int, String>()
    private val favorites = HashMap<Int, Boolean>()
    private val pref by lazy { getSharedPreferences("monster_state", MODE_PRIVATE) }
    private var backupPayload = ""
    private var pendingImageMonsterNo: Int? = null
    private val imageDownloadCancel = AtomicBoolean(false)
    private val altemaZukanUrl = "https://altema.jp/terrysp/zukan"

    // Management page
    private lateinit var manageSearch: EditText
    private lateinit var manageMatchMode: Spinner
    private lateinit var manageRank: Spinner
    private lateinit var manageFamily: Spinner
    private lateinit var manageSize: Spinner
    private lateinit var onlyUnowned: CheckBox
    private lateinit var manageList: ListView
    private lateinit var manageStats: TextView
    private lateinit var monsterAdapter: MonsterAdapter
    private val filteredMonsters = mutableListOf<Monster>()

    // Breeding page
    private lateinit var breedSearch: EditText
    private lateinit var breedDirection: Spinner
    private lateinit var breedMatchMode: Spinner
    private lateinit var breedSort: Spinner
    private lateinit var breedSortOrder: Spinner
    private lateinit var breedType: Spinner
    private lateinit var breedRank: Spinner
    private lateinit var breedFamily: Spinner
    private lateinit var breedSize: Spinner
    private lateinit var breedList: ListView
    private lateinit var breedStats: TextView
    private lateinit var breedingAdapter: BreedingAdapter
    private val filteredRecipes = mutableListOf<BreedingRecipe>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val bg = Color.rgb(244, 247, 250)
    private val card = Color.WHITE
    private val primary = Color.rgb(41, 98, 255)
    private val primarySoft = Color.rgb(232, 240, 255)
    private val breedingColor = Color.rgb(0, 137, 123)
    private val breedingSoft = Color.rgb(229, 245, 242)
    private val accentOrange = Color.rgb(251, 140, 0)
    private val dangerSoft = Color.rgb(255, 235, 238)
    private val textMain = Color.rgb(35, 42, 52)
    private val textSub = Color.rgb(90, 100, 115)
    private val divider = Color.rgb(225, 230, 236)

    private fun roundedBg(color: Int, radiusDp: Int = 10): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }
    }

    private fun styleButton(button: Button, color: Int, textColor: Int = Color.WHITE) {
        button.background = roundedBg(color, 9)
        button.setTextColor(textColor)
        button.isAllCaps = false
        button.minHeight = 0
        button.minWidth = 0
        button.setPadding(dp(8), 0, dp(8), 0)
    }

    private fun addTag(container: LinearLayout, text: String, color: Int) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundedBg(color, 12)
            setPadding(dp(9), dp(3), dp(9), dp(3))
        }
        container.addView(tv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(5) })
    }

    private fun rankColor(rank: String): Int = when(rank) {
        "SS" -> Color.rgb(198, 146, 20)
        "S" -> Color.rgb(123, 31, 162)
        "A" -> Color.rgb(211, 47, 47)
        "B" -> Color.rgb(239, 108, 0)
        "C" -> Color.rgb(30, 136, 229)
        "D" -> Color.rgb(67, 160, 71)
        "E" -> Color.rgb(96, 125, 139)
        else -> Color.rgb(120, 120, 120)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        showLoading()
        try {
            loadMonsters()
            loadBreeding()
            loadState()
            showManagementPage()
        } catch (t: Throwable) {
            showStartupError(t)
        }
    }

    private fun showLoading() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(TextView(this).apply {
            text = "テリワンSP 管理帳を起動しています…"
            textSize = 16f
            setTextColor(textSub)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(root)
    }

    private fun showStartupError(t: Throwable) {
        val root = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        box.addView(TextView(this).apply {
            text = "テリワンSP 管理帳\n\n起動中にエラーが発生しました。\n\n${t::class.java.simpleName}: ${t.message ?: "メッセージなし"}"
            textSize = 16f
            setTextColor(Color.rgb(150, 0, 0))
            setTextIsSelectable(true)
        })
        box.addView(Button(this).apply {
            text = "再試行"
            setOnClickListener {
                try {
                    loadMonsters()
                    loadBreeding()
                    loadState()
                    showManagementPage()
                } catch (e: Throwable) { showStartupError(e) }
            }
        })
        root.addView(box)
        setContentView(root)
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cur.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out.add(cur.toString()); cur.setLength(0) }
                else -> cur.append(c)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun loadMonsters() {
        monsters.clear()
        monsterByName.clear()
        BufferedReader(InputStreamReader(assets.open("monsters.csv"), StandardCharsets.UTF_8)).use { br ->
            br.readLine()
            br.forEachLine { raw ->
                val p = parseCsvLine(raw.removePrefix("\uFEFF").removeSuffix("\r"))
                if (p.size < 5) return@forEachLine
                val no = p[0].trim().toIntOrNull() ?: return@forEachLine
                val m = Monster(no, p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim())
                monsters += m
                monsterByName[m.name] = m
            }
        }
        monsters.sortBy { it.no }
    }

    private fun loadBreeding() {
        recipes.clear()
        BufferedReader(InputStreamReader(assets.open("breeding.csv"), StandardCharsets.UTF_8)).use { br ->
            val header = parseCsvLine(br.readLine().removePrefix("\uFEFF"))
            val ix = header.withIndex().associate { it.value.trim() to it.index }
            fun get(p: List<String>, name: String): String {
                val n = ix[name] ?: return ""
                return if (n < p.size) p[n].trim() else ""
            }
            br.forEachLine { raw ->
                if (raw.isBlank()) return@forEachLine
                val p = parseCsvLine(raw.removeSuffix("\r"))
                val name = get(p, "result_name")
                if (name.isBlank()) return@forEachLine
                val parents = (1..4).map { get(p, "parent$it") }.filter { it.isNotBlank() }
                val parentTypes = (1..4).map { get(p, "parent${it}_type") }.take(parents.size)
                recipes += BreedingRecipe(
                    get(p, "recipe_id").toIntOrNull() ?: recipes.size + 1,
                    get(p, "result_no").toIntOrNull(),
                    name,
                    get(p, "result_rank"),
                    get(p, "result_family"),
                    get(p, "result_size"),
                    get(p, "recipe_type"),
                    parents,
                    parentTypes,
                    get(p, "note")
                )
            }
        }
    }

    private fun loadState() {
        maleCounts.clear(); femaleCounts.clear(); notes.clear(); favorites.clear()
        val all = pref.all
        monsters.forEach { m ->
            maleCounts[m.no] = (all["m${m.no}"] as? Int) ?: 0
            femaleCounts[m.no] = (all["f${m.no}"] as? Int) ?: 0
            notes[m.no] = (all["note${m.no}"] as? String).orEmpty()
            favorites[m.no] = (all["fav${m.no}"] as? Boolean) ?: false
        }
    }

    private fun topMenu(active: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(7))

            val manage = Button(this@MainActivity).apply {
                text = "管理表"
                setOnClickListener { showManagementPage() }
                styleButton(
                    this,
                    if (active == 0) primary else Color.rgb(225,230,236),
                    if (active == 0) Color.WHITE else textMain
                )
            }
            val breed = Button(this@MainActivity).apply {
                text = "配合表"
                setOnClickListener { showBreedingPage() }
                styleButton(
                    this,
                    if (active == 1) breedingColor else Color.rgb(225,230,236),
                    if (active == 1) Color.WHITE else textMain
                )
            }

            addView(manage, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(4) })
            addView(breed, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4) })
        }
    }

    private fun makeSpinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun filterListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action()
    }

    private fun watcher(action: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = action()
        override fun afterTextChanged(s: Editable?) = Unit
    }

    private fun textMatches(value: String, query: String, exact: Boolean): Boolean {
        if (query.isEmpty()) return true
        return if (exact) value.equals(query, ignoreCase = true)
        else value.contains(query, ignoreCase = true)
    }

    private fun firstParentName(r: BreedingRecipe): String =
        r.parents.firstOrNull().orEmpty()

    private fun firstParentNo(r: BreedingRecipe): Int =
        r.parents.mapNotNull { monsterByName[it]?.no }.minOrNull() ?: Int.MAX_VALUE


    private fun monsterIconDir(): File =
        File(filesDir, "monster_icons").apply { mkdirs() }

    private fun monsterIconFile(no: Int): File =
        File(monsterIconDir(), String.format("monster_%03d.img", no))

    private fun applyMonsterIcon(image: ImageView, fallback: TextView, m: Monster) {
        val file = monsterIconFile(m.no)
        if (file.isFile) {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap != null) {
                image.setImageBitmap(bitmap)
                image.visibility = View.VISIBLE
                fallback.visibility = View.GONE
                return
            }
        }
        image.setImageDrawable(null)
        image.visibility = View.GONE
        fallback.visibility = View.VISIBLE
        fallback.text = m.rank
        fallback.background = roundedBg(rankColor(m.rank), 22)
    }

    private fun openImageMenu(m: Monster) {
        val hasImage = monsterIconFile(m.no).isFile
        val items = if (hasImage) {
            arrayOf("画像を変更", "画像を削除", "キャンセル")
        } else {
            arrayOf("画像を登録", "キャンセル")
        }

        AlertDialog.Builder(this)
            .setTitle("No.${m.no} ${m.name}\nモンスターアイコン")
            .setItems(items) { dialog, which ->
                if (hasImage) {
                    when (which) {
                        0 -> selectMonsterImage(m)
                        1 -> {
                            monsterIconFile(m.no).delete()
                            if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                            Toast.makeText(this, "画像を削除しました", Toast.LENGTH_SHORT).show()
                        }
                        else -> dialog.dismiss()
                    }
                } else {
                    if (which == 0) selectMonsterImage(m) else dialog.dismiss()
                }
            }
            .show()
    }

    private fun selectMonsterImage(m: Monster) {
        pendingImageMonsterNo = m.no
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            },
            1003
        )
    }

    private fun saveSelectedMonsterImage(uri: android.net.Uri, no: Int) {
        val target = monsterIconFile(no)
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("画像ファイルを開けませんでした")

        if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
        Toast.makeText(this, "モンスター画像を登録しました", Toast.LENGTH_SHORT).show()
    }

    private fun decodeHtml(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun stripHtml(value: String): String =
        decodeHtml(value.replace(Regex("(?is)<[^>]+>"), " "))
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun tagAttribute(tag: String, name: String): String? {
        val pattern = Regex("(?is)\\b" + Regex.escape(name) + "\\s*=\\s*[\"']([^\"']*)[\"']")
        return pattern.find(tag)?.groupValues?.getOrNull(1)?.let(::decodeHtml)?.takeIf { it.isNotBlank() }
    }

    private fun imageUrlFromTag(tag: String): String? {
        val attrs = listOf("data-src", "data-original", "data-lazy-src", "src")
        return attrs.asSequence().mapNotNull { tagAttribute(tag, it) }
            .map { raw ->
                when {
                    raw.startsWith("//") -> "https:$raw"
                    raw.startsWith("/") -> "https://altema.jp$raw"
                    raw.startsWith("http://") || raw.startsWith("https://") -> raw
                    else -> null
                }
            }
            .filterNotNull()
            .firstOrNull()
    }

    private fun fetchText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseAltemaImageUrls(html: String): Map<Int, String> {
        val result = HashMap<Int, String>()
        val byName = monsters.associateBy { it.name }

        // Most entries on the zukan page are links that contain both the icon and monster name.
        Regex("(?is)<a\\b[^>]*>(.*?)</a>").findAll(html).forEach { match ->
            val body = match.groupValues[1]
            val text = stripHtml(body)
            val monster = byName[text] ?: return@forEach
            val imgTag = Regex("(?is)<img\\b[^>]*>").find(body)?.value ?: return@forEach
            val url = imageUrlFromTag(imgTag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }

        // Fallback for layouts where the image itself carries the monster name in alt/title.
        Regex("(?is)<img\\b[^>]*>").findAll(html).forEach { match ->
            val tag = match.value
            val label = tagAttribute(tag, "alt") ?: tagAttribute(tag, "title") ?: return@forEach
            val monster = byName[label] ?: return@forEach
            val url = imageUrlFromTag(tag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }
        return result
    }

    private fun downloadIcon(url: String, no: Int) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Referer", altemaZukanUrl)
        }
        val tmp = File(monsterIconDir(), String.format("monster_%03d.tmp", no))
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            conn.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
            if (BitmapFactory.decodeFile(tmp.absolutePath) == null) {
                throw IllegalStateException("画像として読み込めません")
            }
            val target = monsterIconFile(no)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        } finally {
            conn.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun confirmAltemaImageDownload() {
        AlertDialog.Builder(this)
            .setTitle("アルテマ画像を一括取得")
            .setMessage("アルテマのモンスター図鑑ページから、No.に対応するアイコンをこの端末内へ保存します。\n\n通信環境によって数分かかる場合があります。既に登録済みの画像は上書きします。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("取得開始") { _, _ -> startAltemaImageDownload() }
            .show()
    }

    private fun startAltemaImageDownload() {
        imageDownloadCancel.set(false)
        val status = TextView(this).apply {
            text = "図鑑ページを確認しています…"
            textSize = 14f
            setTextColor(textMain)
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = monsters.size
            progress = 0
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(status, LinearLayout.LayoutParams(-1, -2))
            addView(progress, LinearLayout.LayoutParams(-1, dp(18)).apply {
                marginStart = dp(16); marginEnd = dp(16); bottomMargin = dp(10)
            })
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("画像を取得中")
            .setView(box)
            .setNegativeButton("中止") { _, _ -> imageDownloadCancel.set(true) }
            .setCancelable(false)
            .create()
        dialog.show()

        Thread {
            var saved = 0
            var failed = 0
            var matched = 0
            try {
                val html = fetchText(altemaZukanUrl)
                val urls = parseAltemaImageUrls(html)
                matched = urls.size
                if (urls.isEmpty()) throw IllegalStateException("図鑑ページからモンスター画像を検出できませんでした")

                monsters.forEachIndexed { index, m ->
                    if (imageDownloadCancel.get()) return@forEachIndexed
                    val url = urls[m.no]
                    if (url != null) {
                        try {
                            downloadIcon(url, m.no)
                            saved++
                        } catch (_: Throwable) {
                            failed++
                        }
                    }
                    if (index % 4 == 0 || index == monsters.lastIndex) {
                        val p = index + 1
                        runOnUiThread {
                            progress.progress = p
                            status.text = "確認 $p / ${monsters.size}　保存 $saved　失敗 $failed"
                        }
                    }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    if (dialog.isShowing) dialog.dismiss()
                    AlertDialog.Builder(this)
                        .setTitle("画像取得に失敗しました")
                        .setMessage("${t.message ?: t::class.java.simpleName}\n\nページ構成や通信状態が変わっている可能性があります。個別の画像登録機能は引き続き使用できます。")
                        .setPositiveButton("閉じる", null)
                        .show()
                }
                return@Thread
            }

            runOnUiThread {
                if (dialog.isShowing) dialog.dismiss()
                if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                val stopped = imageDownloadCancel.get()
                AlertDialog.Builder(this)
                    .setTitle(if (stopped) "画像取得を中止しました" else "画像取得が完了しました")
                    .setMessage("ページ内で対応を確認: $matched体\n端末へ保存: $saved体\n取得失敗: $failed体")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }

    // ---------------- Management page ----------------

    private fun showManagementPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(6))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(0))
        root.addView(TextView(this).apply {
            text = "モンスター管理表"
            textSize = 20f
            setTextColor(textMain)
            setPadding(0, dp(5), 0, 0)
        })
        manageStats = TextView(this).apply {
            textSize = 13f; setTextColor(textSub); setPadding(0, dp(2), 0, dp(4))
        }
        root.addView(manageStats)
        root.addView(TextView(this).apply {
            text = "アイコンをタップして個別登録 / 下のボタンでアルテマから一括取得"
            textSize = 11f
            setTextColor(textSub)
            setPadding(0, 0, 0, dp(3))
        })
        manageSearch = EditText(this).apply {
            hint = "名前・図鑑No.で検索"; setSingleLine(true); textSize = 16f
        }
        root.addView(manageSearch, LinearLayout.LayoutParams(-1, dp(46)))

        manageMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        root.addView(manageMatchMode, LinearLayout.LayoutParams(-1, dp(40)))

        val f1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manageRank = makeSpinner(rankItems())
        manageFamily = makeSpinner(familyItems())
        f1.addView(manageRank, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f1.addView(manageFamily, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(3) })
        root.addView(f1)

        val f2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        manageSize = makeSpinner(sizeItems())
        onlyUnowned = CheckBox(this).apply { text = "未所持のみ"; textSize = 14f }
        f2.addView(manageSize, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f2.addView(onlyUnowned, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(3) })
        root.addView(f2)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "バックアップ"; textSize = 13f; styleButton(this, primary)
            setOnClickListener { backup() }
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(3) })
        actions.addView(Button(this).apply {
            text = "復元"; textSize = 13f; styleButton(this, Color.rgb(96,125,139))
            setOnClickListener { restore() }
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(3) })
        root.addView(actions)

        root.addView(Button(this).apply {
            text = "アルテマからモンスター画像を一括取得"
            textSize = 13f
            styleButton(this, breedingColor)
            setOnClickListener { confirmAltemaImageDownload() }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(5) })

        manageList = ListView(this).apply {
            divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = true
        }
        monsterAdapter = MonsterAdapter(this)
        manageList.adapter = monsterAdapter
        root.addView(manageList, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        manageSearch.addTextChangedListener(watcher { applyManagementFilter() })
        manageMatchMode.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageRank.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageFamily.onItemSelectedListener = filterListener { applyManagementFilter() }
        manageSize.onItemSelectedListener = filterListener { applyManagementFilter() }
        onlyUnowned.setOnCheckedChangeListener { _, _ -> applyManagementFilter() }
        applyManagementFilter()
    }

    private fun rankItems() = arrayOf("ランク:すべて") +
        listOf("SS","S","A","B","C","D","E","F").filter { r -> monsters.any { it.rank == r } }.toTypedArray()
    private fun familyItems() = arrayOf("系統:すべて") + monsters.map { it.family }.distinct().sorted().toTypedArray()
    private fun sizeItems() = arrayOf("サイズ:すべて") + monsters.map { it.size }.distinct().sorted().toTypedArray()

    private fun male(no: Int) = maleCounts[no] ?: 0
    private fun female(no: Int) = femaleCounts[no] ?: 0
    private fun owned(m: Monster) = male(m.no) + female(m.no)

    private fun setCount(no: Int, mv: Int? = null, fv: Int? = null) {
        if (mv != null) maleCounts[no] = mv.coerceAtLeast(0)
        if (fv != null) femaleCounts[no] = fv.coerceAtLeast(0)
        pref.edit().apply {
            if (mv != null) putInt("m$no", male(no))
            if (fv != null) putInt("f$no", female(no))
        }.apply()
    }

    private fun applyManagementFilter() {
        if (!::monsterAdapter.isInitialized) return
        val q = manageSearch.text?.toString()?.trim().orEmpty()
        val exact = manageMatchMode.selectedItemPosition == 1
        val r = manageRank.selectedItem?.toString() ?: "ランク:すべて"
        val f = manageFamily.selectedItem?.toString() ?: "系統:すべて"
        val s = manageSize.selectedItem?.toString() ?: "サイズ:すべて"
        filteredMonsters.clear()
        filteredMonsters.addAll(monsters.filter { m ->
            (q.isEmpty() || textMatches(m.name, q, exact) || (if (exact) m.no.toString() == q else m.no.toString().contains(q))) &&
            (r == "ランク:すべて" || m.rank == r) &&
            (f == "系統:すべて" || m.family == f) &&
            (s == "サイズ:すべて" || m.size == s) &&
            (!onlyUnowned.isChecked || owned(m) == 0)
        })
        monsterAdapter.notifyDataSetChanged()
        val kinds = monsters.count { owned(it) > 0 }
        manageStats.text = "図鑑 ${monsters.size}体 / 所持種類 $kinds / 総所持数 ${monsters.sumOf { owned(it) }} / 表示 ${filteredMonsters.size}"
    }

    private fun changeCount(m: Monster, isMale: Boolean, delta: Int) {
        val next = ((if (isMale) male(m.no) else female(m.no)) + delta).coerceAtLeast(0)
        if (isMale) setCount(m.no, mv = next) else setCount(m.no, fv = next)
        monsterAdapter.notifyDataSetChanged()
        applyManagementFilter()
    }

    private inner class MonsterAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredMonsters.size
        override fun getItem(position: Int) = filteredMonsters[position]
        override fun getItemId(position: Int) = getItem(position).no.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView as? LinearLayout ?: createRow()
            bind(row, getItem(position))
            return row
        }

        private fun createRow(): LinearLayout {
            val outer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(4), dp(3), dp(4))
            }

            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = roundedBg(card, 12)
                elevation = dp(2).toFloat()
                tag = "card"
            }

            val header = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            header.addView(FrameLayout(this@MainActivity).apply {
                tag = "iconFrame"

                addView(ImageView(this@MainActivity).apply {
                    tag = "iconImage"
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    visibility = View.GONE
                    background = roundedBg(Color.rgb(235,238,242), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))

                addView(TextView(this@MainActivity).apply {
                    tag = "iconFallback"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = roundedBg(Color.rgb(96,125,139), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })

            header.addView(TextView(this@MainActivity).apply {
                tag = "title"
                textSize = 16f
                maxLines = 2
                setTextColor(textMain)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            header.addView(Button(this@MainActivity).apply {
                tag = "breed"
                text = "配合を見る"
                textSize = 12f
                styleButton(this, breedingColor)
            }, LinearLayout.LayoutParams(dp(82), dp(38)))

            box.addView(header)

            val tags = LinearLayout(this@MainActivity).apply {
                tag = "tags"
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(52), dp(5), 0, dp(7))
            }
            box.addView(tags)

            val counts = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val maleGroup = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            maleGroup.addView(label("male"), LinearLayout.LayoutParams(dp(54), dp(38)))
            maleGroup.addView(btn("mminus"), LinearLayout.LayoutParams(dp(40), dp(38)).apply { marginEnd = dp(3) })
            maleGroup.addView(btn("mplus"), LinearLayout.LayoutParams(dp(40), dp(38)))

            val femaleGroup = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            femaleGroup.addView(label("female"), LinearLayout.LayoutParams(dp(54), dp(38)))
            femaleGroup.addView(btn("fminus"), LinearLayout.LayoutParams(dp(40), dp(38)).apply { marginEnd = dp(3) })
            femaleGroup.addView(btn("fplus"), LinearLayout.LayoutParams(dp(40), dp(38)))

            counts.addView(maleGroup, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(4) })
            counts.addView(femaleGroup, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(4); marginEnd = dp(5) })
            counts.addView(btn("memo"), LinearLayout.LayoutParams(dp(58), dp(38)))

            box.addView(counts)
            outer.addView(box)
            return outer
        }

        private fun label(t: String) = TextView(this@MainActivity).apply {
            tag=t; textSize=14f; gravity=Gravity.CENTER_VERTICAL; setTextColor(textSub)
        }
        private fun btn(t: String) = Button(this@MainActivity).apply {
            tag=t; textSize=15f
            when(t) {
                "mplus", "fplus" -> styleButton(this, primary)
                "mminus", "fminus" -> styleButton(this, Color.rgb(229,115,115))
                else -> styleButton(this, accentOrange)
            }
        }

        private fun bind(row: LinearLayout, m: Monster) {
            row.findViewWithTag<TextView>("title").text =
                String.format("No.%03d  %s", m.no, m.name)

            val iconImage = row.findViewWithTag<ImageView>("iconImage")
            val iconFallback = row.findViewWithTag<TextView>("iconFallback")
            val iconFrame = row.findViewWithTag<FrameLayout>("iconFrame")

            applyMonsterIcon(iconImage, iconFallback, m)
            iconFrame.setOnClickListener { openImageMenu(m) }
            iconFrame.setOnLongClickListener {
                openImageMenu(m)
                true
            }

            val tags = row.findViewWithTag<LinearLayout>("tags")
            tags.removeAllViews()
            addTag(tags, m.rank, rankColor(m.rank))
            addTag(tags, m.family, breedingColor)
            addTag(tags, m.size, Color.rgb(96,125,139))

            val cardView = row.findViewWithTag<LinearLayout>("card")
            cardView.background = roundedBg(
                if (owned(m) > 0) primarySoft else card,
                12
            )

            row.findViewWithTag<TextView>("male").text = "♂ ${male(m.no)}"
            row.findViewWithTag<TextView>("female").text = "♀ ${female(m.no)}"
            row.findViewWithTag<Button>("breed").setOnClickListener { showBreedingForMonster(m) }
            row.findViewWithTag<Button>("mminus").apply { text="−"; setOnClickListener { changeCount(m,true,-1) } }
            row.findViewWithTag<Button>("mplus").apply { text="+"; setOnClickListener { changeCount(m,true,1) } }
            row.findViewWithTag<Button>("fminus").apply { text="−"; setOnClickListener { changeCount(m,false,-1) } }
            row.findViewWithTag<Button>("fplus").apply { text="+"; setOnClickListener { changeCount(m,false,1) } }
            row.findViewWithTag<Button>("memo").apply { text="メモ"; setOnClickListener { editMemo(m) } }
        }
    }

    // ---------------- Breeding page ----------------

    private fun showBreedingPage(query: String = "", direction: Int = 0) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(7),dp(10),dp(4)); setBackgroundColor(bg)
        }
        root.addView(topMenu(1))
        root.addView(TextView(this).apply {
            text="配合表"; textSize=20f; setTextColor(textMain); setPadding(0,dp(5),0,0)
        })
        breedStats = TextView(this).apply { textSize=13f; setTextColor(textSub); setPadding(0,dp(2),0,dp(4)) }
        root.addView(breedStats)

        breedDirection = makeSpinner(arrayOf("子 → 親を検索","親 → 子を検索"))
        breedDirection.setSelection(direction)
        root.addView(breedDirection, LinearLayout.LayoutParams(-1,dp(43)))

        breedSearch = EditText(this).apply {
            hint = if (direction == 0) "子モンスター名・図鑑No." else "親モンスター名・系統条件"
            setSingleLine(true); textSize=16f; setText(query)
        }
        root.addView(breedSearch, LinearLayout.LayoutParams(-1,dp(46)))

        val searchOptions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        breedMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        breedSortOrder = makeSpinner(arrayOf("昇順", "降順"))
        searchOptions.addView(breedMatchMode, LinearLayout.LayoutParams(0,dp(40),1f).apply { marginEnd=dp(3) })
        searchOptions.addView(breedSortOrder, LinearLayout.LayoutParams(0,dp(40),1f).apply { marginStart=dp(3) })
        root.addView(searchOptions)

        breedSort = makeSpinner(arrayOf("ソート:結果No", "ソート:結果名", "ソート:親No", "ソート:親名", "ソート:配合種別"))
        root.addView(breedSort, LinearLayout.LayoutParams(-1,dp(40)))

        val f1 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        breedType = makeSpinner(arrayOf("配合:すべて","2体配合","4体配合"))
        breedRank = makeSpinner(rankItems())
        f1.addView(breedType, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginEnd=dp(3)})
        f1.addView(breedRank, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginStart=dp(3)})
        root.addView(f1)

        val f2 = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        breedFamily = makeSpinner(familyItems())
        breedSize = makeSpinner(sizeItems())
        f2.addView(breedFamily, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginEnd=dp(3)})
        f2.addView(breedSize, LinearLayout.LayoutParams(0,dp(43),1f).apply{marginStart=dp(3)})
        root.addView(f2)

        breedList = ListView(this).apply { dividerHeight=1; isVerticalScrollBarEnabled=true }
        breedingAdapter = BreedingAdapter(this)
        breedList.adapter = breedingAdapter
        root.addView(breedList, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)

        breedSearch.addTextChangedListener(watcher { applyBreedingFilter() })
        breedMatchMode.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSort.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSortOrder.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedDirection.onItemSelectedListener = filterListener {
            breedSearch.hint = if (breedDirection.selectedItemPosition == 0) "子モンスター名・図鑑No." else "親モンスター名・系統条件"
            applyBreedingFilter()
        }
        breedType.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedRank.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedFamily.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSize.onItemSelectedListener = filterListener { applyBreedingFilter() }
        applyBreedingFilter()
    }

    private fun showBreedingForMonster(m: Monster) {
        showBreedingPage(m.name, 0)
    }

    private fun applyBreedingFilter() {
        if (!::breedingAdapter.isInitialized) return
        val q = breedSearch.text?.toString()?.trim().orEmpty()
        val exact = breedMatchMode.selectedItemPosition == 1
        val direction = breedDirection.selectedItemPosition
        val type = breedType.selectedItem?.toString() ?: "配合:すべて"
        val rank = breedRank.selectedItem?.toString() ?: "ランク:すべて"
        val family = breedFamily.selectedItem?.toString() ?: "系統:すべて"
        val size = breedSize.selectedItem?.toString() ?: "サイズ:すべて"

        filteredRecipes.clear()
        filteredRecipes.addAll(recipes.filter { r ->
            val resultMonster = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
            val qOk = if (q.isEmpty()) true else if (direction == 0) {
                textMatches(r.resultName, q, exact) ||
                    (if (exact) r.resultNo?.toString() == q else r.resultNo?.toString()?.contains(q) == true)
            } else {
                r.parents.any { textMatches(it, q, exact) }
            }
            qOk &&
            (type == "配合:すべて" || r.type == type) &&
            (rank == "ランク:すべて" || resultMonster?.rank == rank || r.resultRank == rank) &&
            (family == "系統:すべて" || resultMonster?.family == family || r.resultFamily == family) &&
            (size == "サイズ:すべて" || resultMonster?.size == size || r.resultSize == size)
        })
        val sortMode = breedSort.selectedItemPosition
        val desc = breedSortOrder.selectedItemPosition == 1
        val comparator = when(sortMode) {
            1 -> compareBy<BreedingRecipe> { it.resultName.lowercase() }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            2 -> compareBy<BreedingRecipe> { firstParentNo(it) }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            3 -> compareBy<BreedingRecipe> { firstParentName(it).lowercase() }.thenBy { it.resultName.lowercase() }
            4 -> compareBy<BreedingRecipe> { it.type }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            else -> compareBy<BreedingRecipe> { it.resultNo ?: Int.MAX_VALUE }.thenBy { it.resultName.lowercase() }
        }
        filteredRecipes.sortWith(if (desc) comparator.reversed() else comparator)

        breedingAdapter.notifyDataSetChanged()
        breedStats.text = "配合レシピ ${recipes.size}件 / 表示 ${filteredRecipes.size}件"
    }

    private inner class BreedingAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredRecipes.size
        override fun getItem(position: Int) = filteredRecipes[position]
        override fun getItemId(position: Int) = getItem(position).id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val outer = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(4), dp(4), dp(4))

                val recipeCard = LinearLayout(this@MainActivity).apply {
                    tag = "recipeCard"
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(11), dp(9), dp(11), dp(9))
                    background = roundedBg(Color.WHITE, 12)
                    elevation = dp(1).toFloat()
                }

                recipeCard.addView(TextView(this@MainActivity).apply {
                    tag = "parentLine"
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    background = roundedBg(breedingColor, 9)
                })

                recipeCard.addView(LinearLayout(this@MainActivity).apply {
                    tag = "childrenBox"
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(7), 0, 0)
                })

                addView(recipeCard)
            }

            val r = getItem(position)
            val parentLine = outer.findViewWithTag<TextView>("parentLine")
            val childrenBox = outer.findViewWithTag<LinearLayout>("childrenBox")

            val resultNoText = r.resultNo?.let { String.format("No.%03d", it) } ?: "No.---"
            parentLine.text = "親  $resultNoText  ${r.resultName}   [${r.type}]"

            childrenBox.removeAllViews()
            r.parents.take(4).forEachIndexed { index, name ->
                val childNo = monsterByName[name]?.no
                val childNoText = childNo?.let { String.format("No.%03d", it) } ?: "条件"
                val tv = TextView(this@MainActivity).apply {
                    text = "子${index + 1}  $childNoText  $name"
                    textSize = 14f
                    setTextColor(textMain)
                    setPadding(dp(9), dp(6), dp(9), dp(6))
                    background = roundedBg(
                        if (index % 2 == 0) primarySoft else breedingSoft,
                        8
                    )
                }
                childrenBox.addView(tv, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(4) })
            }

            outer.setOnClickListener { showRecipeDetail(r) }
            return outer
        }
    }

    private fun showRecipeDetail(r: BreedingRecipe) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8)) }
        val m = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
        box.addView(TextView(this).apply {
            text = buildString {
                append(if (m != null) "No.${m.no} ${m.name}" else r.resultName)
                if (m != null) append("\n${m.rank} / ${m.family} / ${m.size}")
                append("\n\n【このモンスターを作る親】\n")
                append(r.parents.joinToString(" × "))
                append("\n\n配合種別: ${r.type}")
                if (r.note.isNotBlank()) append("\n備考: ${r.note}")
            }
            textSize=16f; setTextColor(textSub)
        })

        box.addView(TextView(this).apply {
            text="\n親から子を調べる"; textSize=15f; setTextColor(textMain)
        })
        r.parents.distinct().forEach { parent ->
            val pm = monsterByName[parent]
            if (pm != null) {
                box.addView(Button(this).apply {
                    text = "${pm.name} を親にした子を検索"
                    setOnClickListener { showBreedingPage(pm.name,1) }
                })
            } else {
                box.addView(Button(this).apply {
                    text = "$parent で子を検索"
                    setOnClickListener { showBreedingPage(parent,1) }
                })
            }
        }

        val children = recipes.filter { rr -> rr.parents.any { it == r.resultName } }.map { it.resultName }.distinct()
        if (children.isNotEmpty()) {
            box.addView(TextView(this).apply {
                text="\n【${r.resultName}を親に使う子】\n${children.joinToString(" / ")}"
                textSize=15f; setTextColor(textSub)
            })
        }
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("配合詳細")
            .setView(scroll)
            .setNegativeButton("閉じる",null)
            .setPositiveButton("この子で検索") { _,_ -> showBreedingPage(r.resultName,0) }
            .show()
    }

    // ---------------- Memo / backup ----------------

    private fun editMemo(m: Monster) {
        val input = EditText(this).apply {
            setSingleLine(false); minLines=2; maxLines=5; setText(notes[m.no].orEmpty()); setSelection(text.length)
        }
        val container = FrameLayout(this).apply {
            setPadding(dp(16),0,dp(16),0)
            addView(input, FrameLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this).setTitle("No.${m.no} ${m.name} のメモ").setView(container)
            .setNegativeButton("キャンセル",null)
            .setPositiveButton("保存") { _,_ ->
                notes[m.no]=input.text.toString()
                pref.edit().putString("note${m.no}",notes[m.no].orEmpty()).apply()
            }.show()
    }

    private fun backup() {
        val arr=JSONArray()
        monsters.forEach { m ->
            arr.put(JSONObject().apply {
                put("no",m.no); put("male",male(m.no)); put("female",female(m.no))
                put("favorite",favorites[m.no] ?: false); put("note",notes[m.no].orEmpty())
            })
        }
        backupPayload=arr.toString()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type="application/json"; putExtra(Intent.EXTRA_TITLE,"terrysp_backup.json")
        },1001)
    }

    private fun restore() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="application/json"; addCategory(Intent.CATEGORY_OPENABLE)
        },1002)
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(res!=RESULT_OK || data?.data==null) {
            if (req == 1003) pendingImageMonsterNo = null
            return
        }
        try {
            if(req==1003) {
                val no = pendingImageMonsterNo
                pendingImageMonsterNo = null
                if (no != null) saveSelectedMonsterImage(data.data!!, no)
            } else if(req==1001) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPayload.toByteArray(StandardCharsets.UTF_8)) }
                Toast.makeText(this,"バックアップを保存しました",Toast.LENGTH_SHORT).show()
            } else if(req==1002) {
                val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText() ?: return
                val arr=JSONArray(text); val e=pref.edit()
                for(i in 0 until arr.length()) {
                    val o=arr.getJSONObject(i); val no=o.getInt("no")
                    val mv=o.optInt("male",0).coerceAtLeast(0); val fv=o.optInt("female",0).coerceAtLeast(0)
                    val n=o.optString("note",""); val fav=o.optBoolean("favorite",false)
                    maleCounts[no]=mv; femaleCounts[no]=fv; notes[no]=n; favorites[no]=fav
                    e.putInt("m$no",mv).putInt("f$no",fv).putString("note$no",n).putBoolean("fav$no",fav)
                }
                e.apply()
                if (::monsterAdapter.isInitialized) applyManagementFilter()
                Toast.makeText(this,"復元しました",Toast.LENGTH_SHORT).show()
            }
        } catch (_:Exception) {
            Toast.makeText(this,"ファイルを読み込めませんでした",Toast.LENGTH_LONG).show()
        }
    }
}
