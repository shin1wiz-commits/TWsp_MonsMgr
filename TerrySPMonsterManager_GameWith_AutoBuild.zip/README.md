# テリワンSP 管理帳 — PCなしAPKビルド版

このプロジェクトは、AndroidスマホからGitHubへアップロードし、GitHub ActionsだけでAPKを作るためのものです。

## データ
ビルド時に `tools/scrape_gamewith.py` がGameWithのテリワンSP完全図鑑から659体の個別ページを取得し、図鑑No.・名前・ランク・系統・サイズを `app/src/main/assets/monsters.csv` に生成します。
GameWithの完全図鑑はNo.別にモンスターを掲載し、個別ページには基本情報としてNo.・ランク・サイズ・系統が掲載されています。

## APK作成
1. GitHubで新しいリポジトリを作る
2. このZIPの中身をアップロード
3. GitHubの **Actions** → **Build Android APK** → **Run workflow**
4. 緑のチェックが出たら実行結果を開く
5. **Artifacts** の `TerrySP-MonsterManager-APK` をダウンロード
6. ZIPを展開して `app-debug.apk` をインストール

## アプリ機能
- 659体
- 図鑑No.
- モンスター名
- ランク
- 系統
- S/M/Gサイズ
- ♂/♀所有数
- 合計所持数の統計
- 名前/No.検索
- ランク/系統/サイズ絞り込み
- 未所持のみ
- メモ
- バックアップ/復元

## 注意
GameWithのページ構成変更などで自動取得が失敗した場合、Actionsは途中で停止し、部分的なデータでAPKを作らない設計です。
