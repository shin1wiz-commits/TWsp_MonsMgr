plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    kotlinOptions {
        jvmTarget = "17"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    namespace = "com.example.terrysp"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.terrysp"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
