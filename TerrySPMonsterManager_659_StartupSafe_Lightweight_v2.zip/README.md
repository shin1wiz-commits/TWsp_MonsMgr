# テリワンSP 管理帳 - 659体 軽量・起動安全版

Androidプロジェクト本体です。

- monsters.csv: 659体（No.1～659）
- CSV: no,name,rank,family,size
- Java/Kotlin JVM target: 17
- ListViewベースの軽量表示
- 起動時エラーを画面に表示する安全起動処理

GitHub ActionsでZIPからビルドする場合は、リポジトリ側の `build-apk.yml` を今回の修正版に置き換えてください。
