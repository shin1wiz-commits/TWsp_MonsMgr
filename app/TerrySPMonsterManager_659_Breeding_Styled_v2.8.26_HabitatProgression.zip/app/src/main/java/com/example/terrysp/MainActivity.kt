package com.example.terrysp

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjectionManager
import android.media.projection.MediaProjectionConfig
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.os.Build
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions

private data class Monster(
    val no: Int,
    val name: String,
    val rank: String,
    val family: String,
    val size: String
)

private data class TrialRecognition(
    var no: Int,
    val sex: Int,
    var confidence: Double,
    var secondNo: Int = -1,
    var margin: Double = 0.0,
    var accepted: Boolean = false,
    val cropPath: String = "",
    val corePath: String = ""
)

private data class BreedingRecipe(
    val id: Int,
    val resultNo: Int?,
    val resultName: String,
    val resultRank: String,
    val resultFamily: String,
    val resultSize: String,
    val type: String,
    val parents: List<String>,
    val parentTypes: List<String>,
    val note: String
)

private data class RouteNode(
    val name: String,
    val recipe: BreedingRecipe? = null,
    val children: List<RouteNode> = emptyList(),
    val isOwned: Boolean = false,
    val isRule: Boolean = false,
    val terminalNote: String = ""
)

private data class RoutePlan(
    val root: RouteNode,
    val ownedLeaves: Int,
    val missingLeaves: Int,
    val steps: Int
)

class MainActivity : Activity() {
    private val monsters = mutableListOf<Monster>()
    private val baseMonsterByNo = HashMap<Int, Monster>()
    private val monsterByName = HashMap<String, Monster>()
    private val recipes = mutableListOf<BreedingRecipe>()

    private val maleCounts = HashMap<Int, Int>()
    private val femaleCounts = HashMap<Int, Int>()
    private val bothCounts = HashMap<Int, Int>()
    private val notes = HashMap<Int, String>()
    private val favorites = HashMap<Int, Boolean>()
    private val wantedCounts = HashMap<Int, Int>()
    private val pref by lazy { getSharedPreferences("monster_state", MODE_PRIVATE) }
    private var backupPayload = ""
    private var pendingImageMonsterNo: Int? = null
    private val imageDownloadCancel = AtomicBoolean(false)
    private val altemaZukanUrl = "https://altema.jp/terrysp/zukan"

    // Management page
    private lateinit var manageSearch: EditText
    private lateinit var manageMatchMode: Spinner
    private lateinit var manageRank: Spinner
    private lateinit var manageFamily: Spinner
    private lateinit var manageSize: Spinner
    private lateinit var manageHabitat: Spinner
    private lateinit var manageDetailToggle: Button
    private var manageDetailExpanded = false
    private var managementFocusNo: Int? = null
    private var managementReturnMode = 0
    private lateinit var onlyOwned: CheckBox
    private lateinit var onlyUnowned: CheckBox
    private lateinit var onlyWanted: CheckBox
    private lateinit var manageList: ListView
    private lateinit var manageStats: TextView
    private lateinit var monsterAdapter: MonsterAdapter
    private val filteredMonsters = mutableListOf<Monster>()
    // v2.8.22: game-library OCR can apply verified values directly to the database.
    // v2.8.21: Altema baseline parser fix + failed monster report.
    // v2.8.19: management cards use the same inline expansion pattern as breeding cards.
    private var expandedManagementNo: Int? = null

    // Breeding page
    private lateinit var breedSearch: EditText
    private lateinit var breedDirection: Spinner
    private lateinit var breedMatchMode: Spinner
    private lateinit var breedSort: Spinner
    private lateinit var breedSortOrder: Spinner
    private lateinit var breedType: Spinner
    private lateinit var breedRank: Spinner
    private lateinit var breedFamily: Spinner
    private lateinit var breedSize: Spinner
    private lateinit var breedCanMake: CheckBox
    private lateinit var breedCannotMake: CheckBox
    private lateinit var breedWantedChild: CheckBox
    private lateinit var breedList: ListView
    private lateinit var breedStats: TextView
    private lateinit var breedingAdapter: BreedingAdapter
    private val filteredRecipes = mutableListOf<BreedingRecipe>()
    private val expandedRecipeIds = HashSet<Int>()

    private data class BreedingReturnState(
        val query: String,
        val direction: Int,
        val matchMode: Int,
        val sortMode: Int,
        val sortOrder: Int,
        val typeText: String,
        val rankText: String,
        val familyText: String,
        val sizeText: String,
        val canMake: Boolean,
        val cannotMake: Boolean,
        val wantedChild: Boolean,
        val firstVisible: Int,
        val topOffset: Int
    )
    private var breedingReturnState: BreedingReturnState? = null
    private val expandedHabitats = HashSet<String>()
    private var habitatPlannerSortMode = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val bg = Color.rgb(244, 247, 250)
    private val card = Color.WHITE
    private val primary = Color.rgb(41, 98, 255)
    private val primarySoft = Color.rgb(232, 240, 255)
    // v2.8.3: slightly stronger tint for owned cards so ownership is visible at a glance.
    private val ownedCardBg = Color.rgb(216, 232, 255)
    private val breedingColor = Color.rgb(0, 137, 123)
    private val breedingSoft = Color.rgb(229, 245, 242)
    private val accentOrange = Color.rgb(251, 140, 0)
    private val dangerSoft = Color.rgb(255, 235, 238)
    private val textMain = Color.rgb(35, 42, 52)
    private val textSub = Color.rgb(90, 100, 115)
    private val divider = Color.rgb(225, 230, 236)

    private fun roundedBg(color: Int, radiusDp: Int = 10): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }
    }

    private fun styleButton(button: Button, color: Int, textColor: Int = Color.WHITE) {
        button.background = roundedBg(color, 9)
        button.setTextColor(textColor)
        button.isAllCaps = false
        button.minHeight = 0
        button.minWidth = 0
        button.setPadding(dp(8), 0, dp(8), 0)
    }

    private fun styleCountButton(button: Button, textColor: Int) {
        button.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(9).toFloat()
            setStroke(dp(1), Color.rgb(215, 222, 230))
        }
        button.setTextColor(textColor)
        button.isAllCaps = false
        button.minHeight = 0
        button.minWidth = 0
        button.setPadding(0, 0, 0, 0)
    }

    private fun addTag(container: LinearLayout, text: String, color: Int) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundedBg(color, 12)
            setPadding(dp(9), dp(3), dp(9), dp(3))
        }
        container.addView(tv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(5) })
    }

    private fun rankColor(rank: String): Int = when(rank) {
        "SS" -> Color.rgb(198, 146, 20)
        "S" -> Color.rgb(123, 31, 162)
        "A" -> Color.rgb(211, 47, 47)
        "B" -> Color.rgb(239, 108, 0)
        "C" -> Color.rgb(30, 136, 229)
        "D" -> Color.rgb(67, 160, 71)
        "E" -> Color.rgb(96, 125, 139)
        else -> Color.rgb(120, 120, 120)
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        showLoading()
        try {
            loadMonsters()
            loadBreeding()
            loadState()
            showManagementPage()
            window.decorView.post { handleOverlayIntentV280(intent) }
        } catch (t: Throwable) {
            showStartupError(t)
        }
    }

    override fun onNewIntent(newIntent: Intent?) {
        super.onNewIntent(newIntent)
        if (newIntent != null) {
            setIntent(newIntent)
            window.decorView.post { handleOverlayIntentV280(newIntent) }
        }
    }

    private fun handleOverlayIntentV280(src: Intent?) {
        if (src?.getBooleanExtra(RecordingOverlayService.EXTRA_REQUEST_RECORD_PERMISSION, false) == true) {
            src.removeExtra(RecordingOverlayService.EXTRA_REQUEST_RECORD_PERMISSION)
            requestScreenCaptureFromOverlayV280()
        }
    }

    private fun showLoading() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        root.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(TextView(this).apply {
            text = "テリワンSP 管理帳を起動しています…"
            textSize = 16f
            setTextColor(textSub)
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(root)
    }

    private fun showStartupError(t: Throwable) {
        val root = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        box.addView(TextView(this).apply {
            text = "テリワンSP 管理帳\n\n起動中にエラーが発生しました。\n\n${t::class.java.simpleName}: ${t.message ?: "メッセージなし"}"
            textSize = 16f
            setTextColor(Color.rgb(150, 0, 0))
            setTextIsSelectable(true)
        })
        box.addView(Button(this).apply {
            text = "再試行"
            setOnClickListener {
                try {
                    loadMonsters()
                    loadBreeding()
                    loadState()
                    showManagementPage()
                } catch (e: Throwable) { showStartupError(e) }
            }
        })
        root.addView(box)
        setContentView(root)
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cur.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out.add(cur.toString()); cur.setLength(0) }
                else -> cur.append(c)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun loadMonsters() {
        monsters.clear()
        baseMonsterByNo.clear()
        monsterByName.clear()
        BufferedReader(InputStreamReader(assets.open("monsters.csv"), StandardCharsets.UTF_8)).use { br ->
            br.readLine()
            br.forEachLine { raw ->
                val p = parseCsvLine(raw.removePrefix("\uFEFF").removeSuffix("\r"))
                if (p.size < 5) return@forEachLine
                val no = p[0].trim().toIntOrNull() ?: return@forEachLine
                val base = Monster(no, p[1].trim(), p[2].trim(), p[3].trim(), p[4].trim())
                baseMonsterByNo[no] = base
                val m = Monster(
                    no,
                    pref.getString("data_name_$no", null) ?: base.name,
                    pref.getString("data_rank_$no", null) ?: base.rank,
                    pref.getString("data_family_$no", null) ?: base.family,
                    pref.getString("data_size_$no", null) ?: base.size
                )
                monsters += m
                // Keep both the original CSV name and the corrected display name as aliases so
                // existing breeding.csv references continue to resolve after a user correction.
                monsterByName[base.name] = m
                monsterByName[m.name] = m
            }
        }
        monsters.sortBy { it.no }
    }

    private fun loadBreeding() {
        recipes.clear()
        BufferedReader(InputStreamReader(assets.open("breeding.csv"), StandardCharsets.UTF_8)).use { br ->
            val header = parseCsvLine(br.readLine().removePrefix("\uFEFF"))
            val ix = header.withIndex().associate { it.value.trim() to it.index }
            fun get(p: List<String>, name: String): String {
                val n = ix[name] ?: return ""
                return if (n < p.size) p[n].trim() else ""
            }
            br.forEachLine { raw ->
                if (raw.isBlank()) return@forEachLine
                val p = parseCsvLine(raw.removeSuffix("\r"))
                val name = get(p, "result_name")
                if (name.isBlank()) return@forEachLine
                val parents = (1..4).map { get(p, "parent$it") }.filter { it.isNotBlank() }
                val parentTypes = (1..4).map { get(p, "parent${it}_type") }.take(parents.size)
                recipes += BreedingRecipe(
                    get(p, "recipe_id").toIntOrNull() ?: recipes.size + 1,
                    get(p, "result_no").toIntOrNull(),
                    name,
                    get(p, "result_rank"),
                    get(p, "result_family"),
                    get(p, "result_size"),
                    get(p, "recipe_type"),
                    parents,
                    parentTypes,
                    get(p, "note")
                )
            }
        }
    }

    private fun loadState() {
        maleCounts.clear(); femaleCounts.clear(); bothCounts.clear(); notes.clear(); favorites.clear(); wantedCounts.clear()
        val all = pref.all
        monsters.forEach { m ->
            maleCounts[m.no] = (all["m${m.no}"] as? Int) ?: 0
            femaleCounts[m.no] = (all["f${m.no}"] as? Int) ?: 0
            bothCounts[m.no] = (all["b${m.no}"] as? Int) ?: 0
            notes[m.no] = (all["note${m.no}"] as? String).orEmpty()
            favorites[m.no] = (all["fav${m.no}"] as? Boolean) ?: false
            wantedCounts[m.no] = (all["want${m.no}"] as? Int) ?: 0
        }
    }

    private fun topMenu(active: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(7))

            fun tab(text: String, index: Int, color: Int, action: () -> Unit) = Button(this@MainActivity).apply {
                this.text = text
                textSize = 13f
                setOnClickListener { action() }
                styleButton(
                    this,
                    if (active == index) color else Color.rgb(225,230,236),
                    if (active == index) Color.WHITE else textMain
                )
            }

            addView(tab("管理表", 0, primary) { showManagementPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(3) })
            addView(tab("配合表", 1, breedingColor) { showBreedingPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
            addView(tab("設定", 2, Color.rgb(69, 90, 100)) { showSettingsPage() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(3) })
        }
    }

    private fun makeSpinner(items: Array<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun makeFamilySpinner(items: Array<String>) = Spinner(this).apply {
        adapter = FamilySpinnerAdapter(items)
    }

    private inner class FamilySpinnerAdapter(private val items: Array<String>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): String = items[position]
        override fun getItemId(position: Int) = position.toLong()

        private fun row(position: Int, compact: Boolean): View {
            val value = items[position]
            return LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(if (compact) 4 else 10), dp(3), dp(8), dp(3))
                val family = value.removePrefix("系統:")
                if (family != "すべて") {
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(familyIconRes(family))
                        // v2.8.5 dropdown fix: CENTER_INSIDE never enlarges a smaller drawable.
                        // FIT_CENTER allows the 36x36 nodpi family icon to scale up to the
                        // requested 48dp dropdown box while keeping its aspect ratio.
                        scaleType = if (compact) ImageView.ScaleType.CENTER_INSIDE else ImageView.ScaleType.FIT_CENTER
                        adjustViewBounds = false
                    }, LinearLayout.LayoutParams(dp(if (compact) 29 else 48), dp(if (compact) 29 else 48)).apply { marginEnd = dp(if (compact) 7 else 10) })
                }
                addView(TextView(this@MainActivity).apply {
                    text = value
                    textSize = if (compact) 16f else 17f
                    setTextColor(textMain)
                    gravity = Gravity.CENTER_VERTICAL
                    maxLines = 1
                }, LinearLayout.LayoutParams(0, if (compact) dp(36) else dp(56), 1f))
            }
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = row(position, true)
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View = row(position, false)
    }

    private fun familyIconRes(family: String): Int = when (family) {
        "スライム" -> R.drawable.family_slime
        "ドラゴン" -> R.drawable.family_dragon
        "自然" -> R.drawable.family_nature
        "魔獣" -> R.drawable.family_beast
        "物質" -> R.drawable.family_material
        "悪魔" -> R.drawable.family_demon
        "ゾンビ" -> R.drawable.family_zombie
        "？？？", "???" -> R.drawable.family_unknown
        else -> R.drawable.family_unknown
    }

    private fun filterListener(action: () -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action()
    }

    private fun watcher(action: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = action()
        override fun afterTextChanged(s: Editable?) = Unit
    }

    private fun textMatches(value: String, query: String, exact: Boolean): Boolean {
        if (query.isEmpty()) return true
        return if (exact) value.equals(query, ignoreCase = true)
        else value.contains(query, ignoreCase = true)
    }

    private fun firstParentName(r: BreedingRecipe): String =
        r.parents.firstOrNull().orEmpty()

    private fun firstParentNo(r: BreedingRecipe): Int =
        r.parents.mapNotNull { monsterByName[it]?.no }.minOrNull() ?: Int.MAX_VALUE


    private fun monsterIconDir(): File =
        File(filesDir, "monster_icons").apply { mkdirs() }

    private fun monsterIconFile(no: Int): File =
        File(monsterIconDir(), String.format("monster_%03d.img", no))

    private fun applyMonsterIcon(image: ImageView, fallback: TextView, m: Monster) {
        val file = monsterIconFile(m.no)
        if (file.isFile) {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap != null) {
                image.setImageBitmap(bitmap)
                image.visibility = View.VISIBLE
                fallback.visibility = View.GONE
                return
            }
        }
        image.setImageDrawable(null)
        image.visibility = View.GONE
        fallback.visibility = View.VISIBLE
        fallback.text = m.rank
        fallback.background = roundedBg(rankColor(m.rank), 22)
    }

    private fun openImageMenu(m: Monster) {
        val hasImage = monsterIconFile(m.no).isFile
        val items = if (hasImage) {
            arrayOf("画像を変更", "画像を削除", "キャンセル")
        } else {
            arrayOf("画像を登録", "キャンセル")
        }

        AlertDialog.Builder(this)
            .setTitle("No.${m.no} ${m.name}\nモンスターアイコン")
            .setItems(items) { dialog, which ->
                if (hasImage) {
                    when (which) {
                        0 -> selectMonsterImage(m)
                        1 -> {
                            monsterIconFile(m.no).delete()
                            if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                            Toast.makeText(this, "画像を削除しました", Toast.LENGTH_SHORT).show()
                        }
                        else -> dialog.dismiss()
                    }
                } else {
                    if (which == 0) selectMonsterImage(m) else dialog.dismiss()
                }
            }
            .show()
    }

    private fun selectMonsterImage(m: Monster) {
        pendingImageMonsterNo = m.no
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            },
            1003
        )
    }

    private fun saveSelectedMonsterImage(uri: android.net.Uri, no: Int) {
        val target = monsterIconFile(no)
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("画像ファイルを開けませんでした")

        if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
        Toast.makeText(this, "モンスター画像を登録しました", Toast.LENGTH_SHORT).show()
    }

    private fun decodeHtml(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun stripHtml(value: String): String =
        decodeHtml(value.replace(Regex("(?is)<[^>]+>"), " "))
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun tagAttribute(tag: String, name: String): String? {
        val pattern = Regex("(?is)\\b" + Regex.escape(name) + "\\s*=\\s*[\"']([^\"']*)[\"']")
        return pattern.find(tag)?.groupValues?.getOrNull(1)?.let(::decodeHtml)?.takeIf { it.isNotBlank() }
    }

    private fun imageUrlFromTag(tag: String): String? {
        val attrs = listOf("data-src", "data-original", "data-lazy-src", "src")
        return attrs.asSequence().mapNotNull { tagAttribute(tag, it) }
            .map { raw ->
                when {
                    raw.startsWith("//") -> "https:$raw"
                    raw.startsWith("/") -> "https://altema.jp$raw"
                    raw.startsWith("http://") || raw.startsWith("https://") -> raw
                    else -> null
                }
            }
            .filterNotNull()
            .firstOrNull()
    }

    private fun fetchText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return conn.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseAltemaImageUrls(html: String): Map<Int, String> {
        val result = HashMap<Int, String>()
        val byName = monsters.associateBy { it.name }

        // Most entries on the zukan page are links that contain both the icon and monster name.
        Regex("(?is)<a\\b[^>]*>(.*?)</a>").findAll(html).forEach { match ->
            val body = match.groupValues[1]
            val text = stripHtml(body)
            val monster = byName[text] ?: return@forEach
            val imgTag = Regex("(?is)<img\\b[^>]*>").find(body)?.value ?: return@forEach
            val url = imageUrlFromTag(imgTag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }

        // Fallback for layouts where the image itself carries the monster name in alt/title.
        Regex("(?is)<img\\b[^>]*>").findAll(html).forEach { match ->
            val tag = match.value
            val label = tagAttribute(tag, "alt") ?: tagAttribute(tag, "title") ?: return@forEach
            val monster = byName[label] ?: return@forEach
            val url = imageUrlFromTag(tag) ?: return@forEach
            result.putIfAbsent(monster.no, url)
        }
        return result
    }

    private fun parseMonsterDetailImageUrl(html: String, monsterName: String): String? {
        // Individual monster pages are used as a fallback when an icon on the index page
        // cannot be associated correctly (currently needed for No.080 ミストウイング).
        Regex("(?is)<img\\b[^>]*>").findAll(html).forEach { match ->
            val tag = match.value
            val alt = tagAttribute(tag, "alt") ?: ""
            val title = tagAttribute(tag, "title") ?: ""
            if (alt.contains(monsterName) || title.contains(monsterName)) {
                imageUrlFromTag(tag)?.let { return it }
            }
        }
        return null
    }

    private fun fallbackAltemaImageUrl(m: Monster): String? {
        // Altema's No.080 entry is exceptional on the zukan page.
        // Its individual monster page is stable and supplies the same game icon.
        if (m.no == 80 && m.name == "ミストウイング") {
            val detailHtml = fetchText("https://altema.jp/terrysp/monster/430")
            return parseMonsterDetailImageUrl(detailHtml, m.name)
        }
        return null
    }

    private fun downloadIcon(url: String, no: Int) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) TerrySPMonsterManager/2.4")
            setRequestProperty("Referer", altemaZukanUrl)
        }
        val tmp = File(monsterIconDir(), String.format("monster_%03d.tmp", no))
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            conn.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
            if (BitmapFactory.decodeFile(tmp.absolutePath) == null) {
                throw IllegalStateException("画像として読み込めません")
            }
            val target = monsterIconFile(no)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
        } finally {
            conn.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun confirmAltemaImageDownload() {
        AlertDialog.Builder(this)
            .setTitle("アルテマ画像を一括取得")
            .setMessage("アルテマのモンスター図鑑ページから、No.に対応するアイコンをこの端末内へ保存します。\n\n通信環境によって数分かかる場合があります。既に登録済みの画像は上書きします。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("取得開始") { _, _ -> startAltemaImageDownload() }
            .show()
    }

    private fun startAltemaImageDownload() {
        imageDownloadCancel.set(false)
        val status = TextView(this).apply {
            text = "図鑑ページを確認しています…"
            textSize = 14f
            setTextColor(textMain)
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = monsters.size
            progress = 0
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(status, LinearLayout.LayoutParams(-1, -2))
            addView(progress, LinearLayout.LayoutParams(-1, dp(18)).apply {
                marginStart = dp(16); marginEnd = dp(16); bottomMargin = dp(10)
            })
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("画像を取得中")
            .setView(box)
            .setNegativeButton("中止") { _, _ -> imageDownloadCancel.set(true) }
            .setCancelable(false)
            .create()
        dialog.show()

        Thread {
            var saved = 0
            var failed = 0
            var matched = 0
            try {
                val html = fetchText(altemaZukanUrl)
                val urls = parseAltemaImageUrls(html).toMutableMap()
                // Fill exceptional/missing entries from their individual monster pages.
                monsters.filter { !urls.containsKey(it.no) }.forEach { m ->
                    try { fallbackAltemaImageUrl(m)?.let { urls[m.no] = it } } catch (_: Throwable) { }
                }
                matched = urls.size
                if (urls.isEmpty()) throw IllegalStateException("図鑑ページからモンスター画像を検出できませんでした")

                monsters.forEachIndexed { index, m ->
                    if (imageDownloadCancel.get()) return@forEachIndexed
                    val url = urls[m.no]
                    if (url != null) {
                        try {
                            downloadIcon(url, m.no)
                            saved++
                        } catch (_: Throwable) {
                            failed++
                        }
                    }
                    if (index % 4 == 0 || index == monsters.lastIndex) {
                        val p = index + 1
                        runOnUiThread {
                            progress.progress = p
                            status.text = "確認 $p / ${monsters.size}　保存 $saved　失敗 $failed"
                        }
                    }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    if (dialog.isShowing) dialog.dismiss()
                    AlertDialog.Builder(this)
                        .setTitle("画像取得に失敗しました")
                        .setMessage("${t.message ?: t::class.java.simpleName}\n\nページ構成や通信状態が変わっている可能性があります。個別の画像登録機能は引き続き使用できます。")
                        .setPositiveButton("閉じる", null)
                        .show()
                }
                return@Thread
            }

            runOnUiThread {
                if (dialog.isShowing) dialog.dismiss()
                if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                val stopped = imageDownloadCancel.get()
                AlertDialog.Builder(this)
                    .setTitle(if (stopped) "画像取得を中止しました" else "画像取得が完了しました")
                    .setMessage("ページ内で対応を確認: ${matched}体\n端末へ保存: ${saved}体\n取得失敗: ${failed}体")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }


    private fun exportMonsterImagesZip() {
        val imageCount = monsters.count { monsterIconFile(it.no).isFile }
        if (imageCount == 0) {
            Toast.makeText(this, "書き出せる取得済み画像がありません", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("取得済み画像をZIP書き出し")
            .setMessage("端末内に保存されている取得済みモンスター画像 ${imageCount}体分を、図鑑No.とモンスター名付きのPNG画像としてZIPにまとめます。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("保存先を選ぶ") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/zip"
                    putExtra(Intent.EXTRA_TITLE, "TerrySP_monster_icons.zip")
                }, 1004)
            }
            .show()
    }

    private fun safeZipName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "monster" }

    private fun writeMonsterImagesZip(uri: android.net.Uri) {
        Toast.makeText(this, "画像ZIPを書き出しています…", Toast.LENGTH_SHORT).show()
        Thread {
            var saved = 0
            var failed = 0
            try {
                contentResolver.openOutputStream(uri)?.use { raw ->
                    ZipOutputStream(raw.buffered()).use { zip ->
                        monsters.forEach { m ->
                            val source = monsterIconFile(m.no)
                            if (!source.isFile) return@forEach
                            val bitmap = BitmapFactory.decodeFile(source.absolutePath)
                            if (bitmap == null) {
                                failed++
                                return@forEach
                            }
                            try {
                                val entryName = String.format("%03d_%s.png", m.no, safeZipName(m.name))
                                zip.putNextEntry(ZipEntry(entryName))
                                if (bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, zip)) saved++ else failed++
                                zip.closeEntry()
                            } catch (_: Throwable) {
                                failed++
                                try { zip.closeEntry() } catch (_: Throwable) { }
                            } finally {
                                bitmap.recycle()
                            }
                        }
                    }
                } ?: throw IllegalStateException("保存先を開けませんでした")
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPを書き出しました")
                        .setMessage("保存: ${saved}体\n失敗: ${failed}体\n\nファイル名: TerrySP_monster_icons.zip")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("ZIP書き出しに失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName)
                        .setPositiveButton("閉じる", null)
                        .show()
                }
            }
        }.start()
    }

    // ---------------- Management page ----------------

    private fun showManagementPage(focusNo: Int? = null, returnMode: Int = 0) {
        managementFocusNo = focusNo
        managementReturnMode = returnMode

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(6))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(0))
        root.addView(TextView(this).apply {
            text = "モンスター管理表"
            textSize = 20f
            setTextColor(textMain)
            setPadding(0, dp(5), 0, 0)
        })
        manageStats = TextView(this).apply {
            textSize = 13f
            setTextColor(textSub)
            setPadding(0, dp(2), 0, dp(4))
        }
        root.addView(manageStats)

        if (focusNo != null) {
            val m = monsters.firstOrNull { it.no == focusNo }
            val jumpBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7), dp(4), dp(7), dp(4))
                background = roundedBg(Color.rgb(233, 241, 252), 9)
            }
            jumpBar.addView(TextView(this).apply {
                text = "表示中：${m?.let { String.format("No.%03d %s", it.no, it.name) } ?: "No.$focusNo"}"
                textSize = 12.5f
                setTextColor(Color.rgb(45, 85, 125))
            }, LinearLayout.LayoutParams(0, dp(36), 1f))
            if (returnMode != 0) {
                jumpBar.addView(Button(this).apply {
                    text = if (returnMode == 1) "← 配合表へ戻る" else "← 生息地攻略へ戻る"
                    textSize = 11.5f
                    styleButton(this, Color.rgb(69, 90, 100))
                    setOnClickListener {
                        if (returnMode == 1) restoreBreedingAfterManagementJump()
                        else showHabitatPlannerPage()
                    }
                }, LinearLayout.LayoutParams(dp(145), dp(36)))
            }
            root.addView(jumpBar, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(3) })
        } else {
            root.addView(TextView(this).apply {
                text = "アイコンをタップして個別登録 / バックアップ・画像操作は設定タブ"
                textSize = 11f
                setTextColor(textSub)
                setPadding(0, 0, 0, dp(3))
            })
        }

        manageSearch = EditText(this).apply {
            hint = "名前・図鑑No.で検索"
            setSingleLine(true)
            textSize = 16f
        }
        root.addView(manageSearch, LinearLayout.LayoutParams(-1, dp(46)))

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        manageDetailToggle = Button(this).apply {
            text = "詳細フィルタ ▼"
            textSize = 12.5f
            styleButton(this, Color.rgb(96, 110, 125))
        }
        actionRow.addView(manageDetailToggle, LinearLayout.LayoutParams(0, dp(41), 0.5f).apply { marginEnd = dp(3) })
        actionRow.addView(Button(this).apply {
            text = "生息地攻略"
            textSize = 12.5f
            styleButton(this, Color.rgb(0, 137, 123))
            setOnClickListener { showHabitatPlannerPage() }
        }, LinearLayout.LayoutParams(0, dp(41), 0.5f).apply { marginStart = dp(3) })
        root.addView(actionRow, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(2) })

        val quickFilters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, dp(2), 0)
        }
        onlyOwned = CheckBox(this).apply { text = "所持"; textSize = 12f; setPadding(0,0,0,0) }
        onlyUnowned = CheckBox(this).apply { text = "未所持"; textSize = 12f; setPadding(0,0,0,0) }
        onlyWanted = CheckBox(this).apply { text = "★ほしい"; textSize = 11.5f; setPadding(0,0,0,0) }
        quickFilters.addView(onlyOwned, LinearLayout.LayoutParams(0, dp(40), 1f))
        quickFilters.addView(onlyUnowned, LinearLayout.LayoutParams(0, dp(40), 1f))
        quickFilters.addView(onlyWanted, LinearLayout.LayoutParams(0, dp(40), 1.25f))
        root.addView(quickFilters, LinearLayout.LayoutParams(-1, dp(41)))

        val filterPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (manageDetailExpanded) View.VISIBLE else View.GONE
            setPadding(dp(5), dp(4), dp(5), dp(5))
            background = roundedBg(Color.rgb(238, 242, 247), 10)
        }

        manageMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        filterPanel.addView(manageMatchMode, LinearLayout.LayoutParams(-1, dp(39)))

        val f1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manageRank = makeSpinner(rankItems())
        manageFamily = makeFamilySpinner(familyItems())
        f1.addView(manageRank, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f1.addView(manageFamily, LinearLayout.LayoutParams(0, dp(47), 1f).apply { marginStart = dp(3) })
        filterPanel.addView(f1)

        val f2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        manageSize = makeSpinner(sizeItems())
        manageHabitat = makeSpinner(habitatItems())
        f2.addView(manageSize, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        f2.addView(manageHabitat, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(3) })
        filterPanel.addView(f2)
        root.addView(filterPanel)

        fun refreshManageDetailLabel() {
            var n = 0
            if (manageMatchMode.selectedItemPosition == 1) n++
            if (manageRank.selectedItemPosition > 0) n++
            if (manageFamily.selectedItemPosition > 0) n++
            if (manageSize.selectedItemPosition > 0) n++
            if (manageHabitat.selectedItemPosition > 0) n++
            val suffix = if (n > 0) " ($n)" else ""
            manageDetailToggle.text = "詳細フィルタ$suffix " + if (manageDetailExpanded) "▲" else "▼"
        }

        refreshManageDetailLabel()
        manageDetailToggle.setOnClickListener {
            manageDetailExpanded = !manageDetailExpanded
            filterPanel.visibility = if (manageDetailExpanded) View.VISIBLE else View.GONE
            refreshManageDetailLabel()
        }

        manageList = ListView(this).apply {
            divider = null
            dividerHeight = 0
            isVerticalScrollBarEnabled = true
        }
        monsterAdapter = MonsterAdapter(this)
        manageList.adapter = monsterAdapter
        root.addView(manageList, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        manageSearch.addTextChangedListener(watcher { applyManagementFilter() })
        manageMatchMode.onItemSelectedListener = filterListener { refreshManageDetailLabel(); applyManagementFilter() }
        manageRank.onItemSelectedListener = filterListener { refreshManageDetailLabel(); applyManagementFilter() }
        manageFamily.onItemSelectedListener = filterListener { refreshManageDetailLabel(); applyManagementFilter() }
        manageSize.onItemSelectedListener = filterListener { refreshManageDetailLabel(); applyManagementFilter() }
        manageHabitat.onItemSelectedListener = filterListener { refreshManageDetailLabel(); applyManagementFilter() }
        onlyOwned.setOnCheckedChangeListener { _, _ -> applyManagementFilter() }
        onlyUnowned.setOnCheckedChangeListener { _, _ -> applyManagementFilter() }
        onlyWanted.setOnCheckedChangeListener { _, _ -> applyManagementFilter() }

        if (focusNo != null) expandedManagementNo = focusNo
        applyManagementFilter()
        if (focusNo != null) manageList.post { manageList.setSelection(0) }
    }

    private fun rankItems() = arrayOf("ランク:すべて") +
        listOf("SS","S","A","B","C","D","E","F").filter { r -> monsters.any { it.rank == r } }.toTypedArray()
    private fun familyItems(): Array<String> {
        val preferred = listOf("スライム", "ドラゴン", "自然", "魔獣", "物質", "悪魔", "ゾンビ", "？？？")
        val existing = monsters.map { it.family }.distinct()
        val ordered = preferred.filter { it in existing } + existing.filter { it !in preferred }.sorted()
        return arrayOf("系統:すべて") + ordered.toTypedArray()
    }
    private fun sizeItems() = arrayOf("サイズ:すべて") + monsters.map { it.size }.distinct().sorted().toTypedArray()

    private fun splitHabitatSourceV2826(raw: String): List<String> {
        val out = ArrayList<String>()
        val buf = StringBuilder()
        var depth = 0
        fun flush() {
            val v = buf.toString().trim()
            if (v.isNotBlank()) out += v
            buf.setLength(0)
        }
        raw.forEach { ch ->
            when (ch) {
                '（', '(' -> { depth++; buf.append(ch) }
                '）', ')' -> { if (depth > 0) depth--; buf.append(ch) }
                '、', ',', '／', '/', '\n', '\r' -> if (depth == 0) flush() else buf.append(ch)
                else -> buf.append(ch)
            }
        }
        flush()
        return out
    }

    private fun normalizeHabitatTokenV2826(token: String): List<String> {
        val t = token.trim().replace(Regex("\\s+"), "")
        if (t.isBlank() || t == "-" || t == "など" || t == "未登録") return emptyList()

        // Egg entries are acquisition methods rather than places, but they are useful in the same planner.
        // Keep the source DB unchanged and expand only the planner/search categories.
        // Example: たまご（金・虹） -> たまご金 + たまご虹
        val egg = Regex("^たまご[（(]([^）)]+)[）)]$").matchEntire(t)
        if (egg != null) {
            return egg.groupValues[1]
                .split(Regex("[・、,／/]+"))
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .map { "たまご$it" }
                .distinct()
        }
        return listOf(t)
    }

    private fun monsterHabitats(no: Int): List<String> {
        val raw = monsterExtendedDataV2818(no).habitat
        if (raw.isBlank()) return emptyList()
        return splitHabitatSourceV2826(raw)
            .flatMap { normalizeHabitatTokenV2826(it) }
            .distinct()
    }

    private val habitatProgressionGroupsV2826 = linkedMapOf(
        "旅の扉の間 B1F" to listOf(
            "たびだちの扉", "まちびとの扉", "まもりの扉", "おもいでの扉",
            "ゆうきの扉", "やすらぎの扉", "とまどいの扉", "いかりの扉"
        ),
        "旅の扉の間 B2F" to listOf(
            "ちからの扉", "よろこびの扉", "おおぞらの扉", "ほろびの扉",
            "しあわせの扉", "さそいの扉", "さばきの扉", "かがみの扉"
        ),
        "星空の闘技場" to listOf(
            "れっぷうの扉", "らいうんの扉", "だいちの扉", "ぜっかいの扉",
            "ほむらの扉", "とこやみの扉"
        ),
        "寄り道（クリア前）" to listOf(
            "まよいの扉", "まぼろしの扉", "きょじんの扉", "しんじつの扉",
            "しれんの扉", "さいはての扉", "ねむりの扉", "めぐりあいの扉"
        ),
        "寄り道（クリア後）" to listOf(
            "うらみの扉", "たくらみの扉", "ふういんの扉"
        )
    )

    private fun habitatGroupV2826(name: String): String {
        habitatProgressionGroupsV2826.forEach { (group, names) -> if (name in names) return group }
        if (name.contains("黄金郷")) return "黄金郷"
        if (name.startsWith("たまご")) return "たまご"
        return "その他入手先"
    }

    private fun baseDoorProgressIndexV2826(name: String): Int {
        val normalized = name.replace("黄金郷", "").replace("・", "").replace("（", "").replace("）", "")
        var index = 0
        habitatProgressionGroupsV2826.values.forEach { names ->
            names.forEach { door ->
                if (normalized.contains(door)) return index
                index++
            }
        }
        return Int.MAX_VALUE / 4
    }

    private fun habitatProgressKeyV2826(name: String): Pair<Int, Int> {
        val groupOrder = listOf(
            "旅の扉の間 B1F", "旅の扉の間 B2F", "星空の闘技場",
            "寄り道（クリア前）", "寄り道（クリア後）", "黄金郷", "たまご", "その他入手先"
        )
        val group = habitatGroupV2826(name)
        val gi = groupOrder.indexOf(group).let { if (it < 0) groupOrder.size else it }
        val inner = when (group) {
            "黄金郷" -> baseDoorProgressIndexV2826(name)
            "たまご" -> listOf("たまご白", "たまご金", "たまご虹").indexOf(name).let { if (it < 0) 1000 else it }
            else -> habitatProgressionGroupsV2826[group]?.indexOf(name)?.let { if (it < 0) 1000 else it } ?: 1000
        }
        return gi to inner
    }

    private fun habitatItems(): Array<String> {
        val values = LinkedHashSet<String>()
        monsters.sortedBy { it.no }.forEach { m -> monsterHabitats(m.no).forEach { values += it } }
        val ordered = values.sortedWith(
            compareBy<String> { habitatProgressKeyV2826(it).first }
                .thenBy { habitatProgressKeyV2826(it).second }
                .thenBy { it }
        )
        return arrayOf("生息地:すべて") + ordered.toTypedArray()
    }

    private fun male(no: Int) = maleCounts[no] ?: 0
    private fun female(no: Int) = femaleCounts[no] ?: 0
    private fun both(no: Int) = bothCounts[no] ?: 0
    private fun wanted(no: Int) = wantedCounts[no] ?: 0
    private fun owned(m: Monster) = male(m.no) + female(m.no) + both(m.no)

    private fun setWanted(no: Int, value: Int) {
        val next = value.coerceAtLeast(0)
        wantedCounts[no] = next
        pref.edit().putInt("want$no", next).apply()
    }

    private fun changeWanted(m: Monster, delta: Int, showToast: Boolean = false) {
        setWanted(m.no, wanted(m.no) + delta)
        if (::monsterAdapter.isInitialized) {
            monsterAdapter.notifyDataSetChanged()
            applyManagementFilter()
        }
        if (showToast) Toast.makeText(this, "★ ${m.name} をほしい ${wanted(m.no)} にしました", Toast.LENGTH_SHORT).show()
    }

    private fun setCount(no: Int, mv: Int? = null, fv: Int? = null, bv: Int? = null) {
        if (mv != null) maleCounts[no] = mv.coerceAtLeast(0)
        if (fv != null) femaleCounts[no] = fv.coerceAtLeast(0)
        if (bv != null) bothCounts[no] = bv.coerceAtLeast(0)
        pref.edit().apply {
            if (mv != null) putInt("m$no", male(no))
            if (fv != null) putInt("f$no", female(no))
            if (bv != null) putInt("b$no", both(no))
        }.apply()
    }

    private fun applyManagementFilter() {
        if (!::monsterAdapter.isInitialized) return
        val q = manageSearch.text?.toString()?.trim().orEmpty()
        val exact = manageMatchMode.selectedItemPosition == 1
        val r = manageRank.selectedItem?.toString() ?: "ランク:すべて"
        val f = manageFamily.selectedItem?.toString() ?: "系統:すべて"
        val s = manageSize.selectedItem?.toString() ?: "サイズ:すべて"
        val h = manageHabitat.selectedItem?.toString() ?: "生息地:すべて"

        filteredMonsters.clear()
        filteredMonsters.addAll(monsters.filter { m ->
            if (managementFocusNo != null && m.no != managementFocusNo) return@filter false

            val ownershipMatch = when {
                onlyOwned.isChecked && !onlyUnowned.isChecked -> owned(m) > 0
                !onlyOwned.isChecked && onlyUnowned.isChecked -> owned(m) == 0
                else -> true
            }
            val wantedMatch = !onlyWanted.isChecked || wanted(m.no) > 0
            val habitatMatch = h == "生息地:すべて" || monsterHabitats(m.no).contains(h)

            (q.isEmpty() || textMatches(m.name, q, exact) ||
                (if (exact) m.no.toString() == q else m.no.toString().contains(q))) &&
            (r == "ランク:すべて" || m.rank == r) &&
            (f == "系統:すべて" || m.family == f) &&
            (s == "サイズ:すべて" || m.size == s) &&
            habitatMatch && ownershipMatch && wantedMatch
        })

        monsterAdapter.notifyDataSetChanged()
        val kinds = monsters.count { owned(it) > 0 }
        val wantedKinds = monsters.count { wanted(it.no) > 0 }
        manageStats.text = "図鑑 ${monsters.size}体 / 所持種類 $kinds / 総所持数 ${monsters.sumOf { owned(it) }} / ほしい ${wantedKinds}種 / 表示 ${filteredMonsters.size}"
    }

    private fun changeCount(m: Monster, sex: Int, delta: Int) {
        val current = when (sex) { 0 -> male(m.no); 1 -> female(m.no); else -> both(m.no) }
        val next = (current + delta).coerceAtLeast(0)
        when (sex) {
            0 -> setCount(m.no, mv = next)
            1 -> setCount(m.no, fv = next)
            else -> setCount(m.no, bv = next)
        }
        monsterAdapter.notifyDataSetChanged()
        applyManagementFilter()
    }

    private inner class MonsterAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredMonsters.size
        override fun getItem(position: Int) = filteredMonsters[position]
        override fun getItemId(position: Int) = getItem(position).no.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView as? LinearLayout ?: createRow()
            bind(row, getItem(position))
            return row
        }

        private fun createRow(): LinearLayout {
            val outer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(4), dp(3), dp(4))
            }

            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = roundedBg(card, 12)
                elevation = dp(2).toFloat()
                tag = "card"
            }

            val header = LinearLayout(this@MainActivity).apply {
                tag = "headerRow"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            header.addView(FrameLayout(this@MainActivity).apply {
                tag = "iconFrame"

                addView(ImageView(this@MainActivity).apply {
                    tag = "iconImage"
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    visibility = View.GONE
                    background = roundedBg(Color.rgb(235,238,242), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))

                addView(TextView(this@MainActivity).apply {
                    tag = "iconFallback"
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = roundedBg(Color.rgb(96,125,139), 22)
                }, FrameLayout.LayoutParams(dp(44), dp(44)))
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(8) })

            header.addView(TextView(this@MainActivity).apply {
                tag = "title"
                textSize = 17.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 2
                setTextColor(textMain)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            header.addView(TextView(this@MainActivity).apply {
                tag = "wantedBadge"
                text = "★ほしい"
                textSize = 10f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = roundedBg(Color.rgb(245, 158, 11), 10)
                setPadding(dp(6), dp(3), dp(6), dp(3))
                visibility = View.GONE
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(26)).apply { marginEnd = dp(4) })

            header.addView(Button(this@MainActivity).apply {
                tag = "breed"
                text = "配合"
                textSize = 12f
                styleButton(this, breedingColor)
            }, LinearLayout.LayoutParams(dp(62), dp(38)).apply { marginEnd = dp(4) })

            header.addView(Button(this@MainActivity).apply {
                tag = "memo"
                text = "メモ"
                textSize = 12f
                styleButton(this, accentOrange)
            }, LinearLayout.LayoutParams(dp(54), dp(38)))

            header.addView(TextView(this@MainActivity).apply {
                tag = "expandIndicator"
                text = "▼"
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(textSub)
                setPadding(dp(2), 0, 0, 0)
            }, LinearLayout.LayoutParams(dp(32), dp(38)).apply { marginStart = dp(2) })

            box.addView(header)

            val tags = LinearLayout(this@MainActivity).apply {
                tag = "tags"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(52), dp(5), 0, dp(7))
            }
            box.addView(tags)

            box.addView(View(this@MainActivity).apply { setBackgroundColor(divider) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(1); bottomMargin = dp(5) })

            val counts = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            counts.addView(TextView(this@MainActivity).apply {
                text = "所有"
                textSize = 12.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(primary)
                gravity = Gravity.CENTER
                background = roundedBg(Color.rgb(232, 240, 255), 8)
            }, LinearLayout.LayoutParams(dp(48), dp(32)).apply { marginEnd = dp(4) })

            fun countGroup(labelTag: String, minusTag: String, plusTag: String): LinearLayout =
                LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    // Keep the count and its +/- buttons visually together.
                    // The previous weighted label expanded into the spare width and made
                    // the count look detached from the buttons, especially with 3 sexes.
                    addView(label(labelTag), LinearLayout.LayoutParams(dp(46), dp(34)))
                    addView(btn(minusTag), LinearLayout.LayoutParams(dp(27), dp(34)).apply {
                        marginStart = dp(1); marginEnd = dp(1)
                    })
                    addView(btn(plusTag), LinearLayout.LayoutParams(dp(27), dp(34)).apply {
                        marginStart = dp(1)
                    })
                }

            val maleGroup = countGroup("male", "mminus", "mplus")
            val femaleGroup = countGroup("female", "fminus", "fplus")
            val bothGroup = countGroup("both", "bminus", "bplus")

            counts.addView(maleGroup, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginEnd = dp(1) })
            counts.addView(femaleGroup, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginStart = dp(1); marginEnd = dp(1) })
            counts.addView(bothGroup, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginStart = dp(1) })

            box.addView(counts)

            val wantedRow = LinearLayout(this@MainActivity).apply {
                tag = "wantedRow"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, 0)
            }
            wantedRow.addView(TextView(this@MainActivity).apply {
                text = "ほしい"
                textSize = 12.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(Color.rgb(166, 104, 0))
                gravity = Gravity.CENTER
                background = roundedBg(Color.rgb(255, 247, 214), 8)
            }, LinearLayout.LayoutParams(dp(48), dp(31)).apply { marginEnd = dp(4) })
            wantedRow.addView(TextView(this@MainActivity).apply {
                tag = "wanted"
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(62), dp(31)))
            wantedRow.addView(btn("wminus"), LinearLayout.LayoutParams(dp(30), dp(31)).apply { marginStart = dp(3) })
            wantedRow.addView(btn("wplus"), LinearLayout.LayoutParams(dp(30), dp(31)).apply { marginStart = dp(2) })
            box.addView(wantedRow)

            // Inline monster detail area. Rebuilt on bind because ListView rows are recycled.
            box.addView(LinearLayout(this@MainActivity).apply {
                tag = "extendedSection"
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
            })
            outer.addView(box)
            return outer
        }

        private fun label(t: String) = TextView(this@MainActivity).apply {
            tag=t
            textSize=if (t == "both") 14.5f else 16f
            gravity=Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = roundedBg(when (t) {
                "male" -> Color.rgb(38, 105, 220)
                "female" -> Color.rgb(215, 62, 78)
                else -> Color.rgb(25, 145, 85)
            }, 9)
        }
        private fun btn(t: String) = Button(this@MainActivity).apply {
            tag=t
            textSize=20f
            when(t) {
                "mplus", "fplus", "bplus", "wplus" -> styleCountButton(this, primary)
                "mminus", "fminus", "bminus", "wminus" -> styleCountButton(this, Color.rgb(220, 70, 80))
                else -> { textSize = 15f; styleButton(this, accentOrange) }
            }
        }

        private fun bind(row: LinearLayout, m: Monster) {
            fun toggleManagementDetail() {
                expandedManagementNo = if (expandedManagementNo == m.no) null else m.no
                notifyDataSetChanged()
            }
            row.findViewWithTag<TextView>("title").apply {
                text = String.format("No.%03d  %s", m.no, m.name)
                setOnClickListener { toggleManagementDetail() }
                setOnLongClickListener { toggleManagementDetail(); true }
            }
            row.findViewWithTag<LinearLayout>("headerRow").setOnClickListener { toggleManagementDetail() }
            row.findViewWithTag<TextView>("expandIndicator").apply {
                text = if (expandedManagementNo == m.no) "▲" else "▼"
                setOnClickListener { toggleManagementDetail() }
            }

            val iconImage = row.findViewWithTag<ImageView>("iconImage")
            val iconFallback = row.findViewWithTag<TextView>("iconFallback")
            val iconFrame = row.findViewWithTag<FrameLayout>("iconFrame")

            applyMonsterIcon(iconImage, iconFallback, m)
            iconFrame.setOnClickListener { openImageMenu(m) }
            iconFrame.setOnLongClickListener {
                openImageMenu(m)
                true
            }

            val tags = row.findViewWithTag<LinearLayout>("tags")
            tags.removeAllViews()
            addMetaTagV283(tags, "ランク", m.rank, rankColor(m.rank))
            addMetaSeparatorV283(tags)
            addFamilyMetaTagV284(tags, m.family)
            addMetaSeparatorV283(tags)
            addMetaTagV283(tags, "サイズ", m.size, Color.rgb(96,125,139))

            val extendedSection = row.findViewWithTag<LinearLayout>("extendedSection")
            val isExpanded = expandedManagementNo == m.no
            extendedSection.visibility = if (isExpanded) View.VISIBLE else View.GONE
            extendedSection.removeAllViews()
            if (isExpanded) populateManagementExtendedSectionV2819(extendedSection, m)

            val cardView = row.findViewWithTag<LinearLayout>("card")
            cardView.background = roundedBg(
                if (owned(m) > 0) ownedCardBg else card,
                12
            )

            row.findViewWithTag<TextView>("male").apply {
                text = "♂ ${male(m.no)}"
                styleCountBadgeV284(this, "male", male(m.no))
            }
            row.findViewWithTag<TextView>("female").apply {
                text = "♀ ${female(m.no)}"
                styleCountBadgeV284(this, "female", female(m.no))
            }
            row.findViewWithTag<TextView>("both").apply {
                text = "♂♀ ${both(m.no)}"
                styleCountBadgeV284(this, "both", both(m.no))
            }
            row.findViewWithTag<TextView>("wanted").apply {
                val w = wanted(m.no)
                text = "★ $w"
                background = roundedBg(if (w > 0) Color.rgb(245, 158, 11) else Color.rgb(255, 244, 204), 9)
                setTextColor(if (w > 0) Color.WHITE else Color.rgb(166, 104, 0))
            }
            row.findViewWithTag<TextView>("wantedBadge").apply {
                visibility = if (wanted(m.no) > 0) View.VISIBLE else View.GONE
                text = "★ほしい${wanted(m.no)}"
            }
            row.findViewWithTag<Button>("breed").setOnClickListener { showBreedingForMonster(m) }
            row.findViewWithTag<Button>("mminus").apply { text="−"; setOnClickListener { changeCount(m,0,-1) } }
            row.findViewWithTag<Button>("mplus").apply { text="+"; setOnClickListener { changeCount(m,0,1) } }
            row.findViewWithTag<Button>("fminus").apply { text="−"; setOnClickListener { changeCount(m,1,-1) } }
            row.findViewWithTag<Button>("fplus").apply { text="+"; setOnClickListener { changeCount(m,1,1) } }
            row.findViewWithTag<Button>("bminus").apply { text="−"; setOnClickListener { changeCount(m,2,-1) } }
            row.findViewWithTag<Button>("bplus").apply { text="+"; setOnClickListener { changeCount(m,2,1) } }
            row.findViewWithTag<Button>("wminus").apply { text="−"; setOnClickListener { changeWanted(m,-1) } }
            row.findViewWithTag<Button>("wplus").apply { text="+"; setOnClickListener { changeWanted(m,1) } }
            row.findViewWithTag<Button>("memo").apply { text="メモ"; setOnClickListener { editMemo(m) } }
        }

        private fun populateManagementExtendedSectionV2819(section: LinearLayout, m: Monster) {
            val no = m.no
            val d = monsterExtendedDataV2818(no)
            section.addView(View(this@MainActivity).apply { setBackgroundColor(divider) }, LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(8); bottomMargin = dp(7)
            })

            val titleRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            titleRow.addView(TextView(this@MainActivity).apply {
                text = "詳細データ"
                textSize = 13.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(textMain)
            }, LinearLayout.LayoutParams(0, dp(30), 1f))
            titleRow.addView(TextView(this@MainActivity).apply {
                val verifiedCount = listOf("habitat","skill","traits","weapons","parents").count { fieldVerifiedV2818(no, it) }
                text = if (verifiedCount > 0) "✓確認済 $verifiedCount/5" else "未確認"
                textSize = 10.5f
                gravity = Gravity.CENTER
                setTextColor(if (verifiedCount > 0) Color.rgb(0,121,107) else textSub)
                background = roundedBg(if (verifiedCount > 0) Color.rgb(224,247,239) else Color.rgb(245,247,250), 9)
                setPadding(dp(7), dp(2), dp(7), dp(2))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(27)))
            section.addView(titleRow)

            fun statusSymbol(key: String, hasValue: Boolean): String = when {
                fieldVerifiedV2818(no, key) -> "✓"
                hasValue -> "○"
                else -> "—"
            }
            fun fieldRow(label: String, key: String, value: String, hasValue: Boolean = value.isNotBlank()) {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.TOP
                    setPadding(0, dp(3), 0, dp(3))
                }
                row.addView(TextView(this@MainActivity).apply {
                    text = statusSymbol(key, hasValue)
                    textSize = 13f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(when {
                        fieldVerifiedV2818(no,key) -> Color.rgb(0,121,107)
                        hasValue -> Color.rgb(90,100,115)
                        else -> Color.rgb(170,178,188)
                    })
                }, LinearLayout.LayoutParams(dp(24), dp(28)))
                row.addView(TextView(this@MainActivity).apply {
                    text = label
                    textSize = 12f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(textSub)
                }, LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT))
                row.addView(TextView(this@MainActivity).apply {
                    text = value.ifBlank { "未登録 / 未確認" }
                    textSize = 12.5f
                    setTextColor(if (hasValue) textMain else Color.rgb(145,152,162))
                    maxLines = if (key == "traits") 9 else 3
                    if (key == "traits") {
                        includeFontPadding = true
                        setLineSpacing(dp(2).toFloat(), 1.0f)
                        setPadding(0, 0, 0, dp(5))
                        minimumHeight = dp((d.traits.size.coerceAtLeast(1) * 21) + 6)
                    }
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                section.addView(row)
            }

            fieldRow("生息地", "habitat", d.habitat)
            fieldRow("スキル", "skill", d.skill)
            val traitsText = if (d.traits.isEmpty()) "" else d.traits.mapIndexed { i, v -> "${i+1}. $v" }.joinToString("\n")
            fieldRow("特性", "traits", traitsText, d.traits.isNotEmpty())
            fieldRow("武器", "weapons", d.weapons.joinToString(" / "), d.weapons.isNotEmpty())
            val parentsText = when {
                d.parentPattern.isNotBlank() -> d.parentPattern
                d.parent1.isNotBlank() || d.parent2.isNotBlank() -> "${d.parent1.ifBlank { "未判明" }} × ${d.parent2.ifBlank { "未判明" }}"
                else -> ""
            }
            fieldRow("親の組合せ", "parents", parentsText)

            section.addView(TextView(this@MainActivity).apply {
                text = "✓ ゲーム内確認済み　○ データあり・未確認　— データなし"
                textSize = 10f
                setTextColor(textSub)
                setPadding(dp(2), dp(4), 0, dp(5))
            })

            val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            actions.addView(Button(this@MainActivity).apply {
                text = "基本情報編集"
                textSize = 11.5f
                styleButton(this, Color.rgb(69,90,100))
                setOnClickListener { editMonsterDataDialog(no, returnToManagement = true) }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(2) })
            actions.addView(Button(this@MainActivity).apply {
                text = "詳細データ編集"
                textSize = 11.5f
                styleButton(this, primary)
                setOnClickListener { editMonsterExtendedDataDialogV2818(no) }
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(2) })
            section.addView(actions)
        }
    }

    // v2.8.3 management-card metadata: explicit labels + existing colored marks.
    private fun addMetaTagV283(container: LinearLayout, labelText: String, value: String, color: Int) {
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        group.addView(TextView(this).apply {
            text = labelText
            textSize = 13f
            setTextColor(textSub)
            setPadding(0, 0, dp(3), 0)
        })
        group.addView(TextView(this).apply {
            text = value
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundedBg(color, 11)
            setPadding(dp(7), dp(2), dp(7), dp(2))
        })
        container.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun addFamilyMetaTagV284(container: LinearLayout, family: String) {
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        group.addView(TextView(this).apply {
            text = "種族"
            textSize = 13f
            setTextColor(textSub)
            setPadding(0, 0, dp(3), 0)
        })
        group.addView(ImageView(this).apply {
            setImageResource(familyIconRes(family))
            // v2.8.6: enlarge only the family/species icon inside management cards.
            // The monster portrait and family-filter spinner sizes are intentionally unchanged.
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(5) })
        group.addView(TextView(this).apply {
            text = family
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = roundedBg(breedingColor, 11)
            setPadding(dp(7), dp(2), dp(7), dp(2))
        })
        container.addView(group, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun styleCountBadgeV284(view: TextView, sex: String, count: Int) {
        val vivid = when (sex) {
            "male" -> Color.rgb(38, 105, 220)
            "female" -> Color.rgb(215, 62, 78)
            else -> Color.rgb(25, 145, 85)
        }
        val pale = when (sex) {
            "male" -> Color.rgb(218, 232, 255)
            "female" -> Color.rgb(255, 222, 226)
            else -> Color.rgb(218, 244, 230)
        }
        val zeroText = when (sex) {
            "male" -> Color.rgb(32, 91, 190)
            "female" -> Color.rgb(184, 52, 66)
            else -> Color.rgb(20, 122, 72)
        }
        view.background = roundedBg(if (count > 0) vivid else pale, 9)
        view.setTextColor(if (count > 0) Color.WHITE else zeroText)
    }

    private fun addMetaSeparatorV283(container: LinearLayout) {
        container.addView(TextView(this).apply {
            text = "│"
            textSize = 13f
            setTextColor(Color.rgb(180, 188, 198))
            gravity = Gravity.CENTER
            setPadding(dp(3), 0, dp(3), 0)
        })
    }


    // ---------------- v2.8.18 extended monster database foundation ----------------

    private data class MonsterExtendedDataV2818(
        val habitat: String,
        val skill: String,
        val traits: List<String>,
        val weapons: List<String>,
        val parent1: String,
        val parent2: String,
        val parentPattern: String
    )

    private fun prefStringV2818(key:String):String = pref.getString(key, "")?.trim().orEmpty()
    private fun mergedDataStringV2820(no:Int, field:String):String {
        val user=prefStringV2818("data_${field}_$no")
        return if(user.isNotBlank()) user else prefStringV2818("base_${field}_$no")
    }
    private fun jsonListV2820(raw:String):List<String> = try { if(raw.isBlank()) emptyList() else { val a=JSONArray(raw); (0 until a.length()).mapNotNull { a.optString(it).trim().takeIf(String::isNotBlank) } } } catch(_:Throwable){ emptyList() }
    private fun mergedListV2820(no:Int, field:String):List<String> {
        val user=prefStringV2818("data_${field}_$no")
        return jsonListV2820(if(user.isNotBlank()) user else prefStringV2818("base_${field}_$no"))
    }
    private fun fieldVerifiedV2818(no:Int, field:String):Boolean = pref.getBoolean("data_verified_${field}_$no", false)
    private fun setFieldVerifiedV2818(no:Int, field:String, value:Boolean) {
        val e=pref.edit(); if(value)e.putBoolean("data_verified_${field}_$no",true) else e.remove("data_verified_${field}_$no"); e.apply()
    }

    private fun monsterExtendedDataV2818(no:Int):MonsterExtendedDataV2818 {
        return MonsterExtendedDataV2818(
            mergedDataStringV2820(no,"habitat"), mergedDataStringV2820(no,"skill"),
            mergedListV2820(no,"traits"), mergedListV2820(no,"weapons"),
            mergedDataStringV2820(no,"parent1"), mergedDataStringV2820(no,"parent2"), mergedDataStringV2820(no,"parent_pattern")
        )
    }

    private fun hasExtendedMonsterDataV2818(no:Int):Boolean {
        val d=monsterExtendedDataV2818(no)
        return d.habitat.isNotBlank() || d.skill.isNotBlank() || d.traits.isNotEmpty() || d.weapons.isNotEmpty() || d.parent1.isNotBlank() || d.parent2.isNotBlank() || d.parentPattern.isNotBlank()
    }

    private fun saveExtendedMonsterDataV2818(no:Int, habitat:String, skill:String, traitsText:String, weaponsText:String, parent1:String, parent2:String, parentPattern:String) {
        val traits=traitsText.lines().map{it.trim()}.filter{it.isNotBlank()}.take(7)
        val weapons=weaponsText.split(',', '、', '\n').map{it.trim()}.filter{it.isNotBlank()}
        val e=pref.edit()
        fun putOrRemove(key:String,value:String){ if(value.trim().isBlank())e.remove(key) else e.putString(key,value.trim()) }
        putOrRemove("data_habitat_$no",habitat); putOrRemove("data_skill_$no",skill)
        if(traits.isEmpty())e.remove("data_traits_$no") else e.putString("data_traits_$no",JSONArray(traits).toString())
        if(weapons.isEmpty())e.remove("data_weapons_$no") else e.putString("data_weapons_$no",JSONArray(weapons).toString())
        putOrRemove("data_parent1_$no",parent1); putOrRemove("data_parent2_$no",parent2); putOrRemove("data_parent_pattern_$no",parentPattern)
        e.apply()
    }

    private fun extendedSummaryV2818(no:Int):String {
        val d=monsterExtendedDataV2818(no)
        val traits=if(d.traits.isEmpty())"未登録" else d.traits.joinToString(" / ")
        val weapons=if(d.weapons.isEmpty())"未登録" else d.weapons.joinToString("・")
        val parents=when {
            d.parentPattern.isNotBlank() -> d.parentPattern
            d.parent1.isNotBlank() || d.parent2.isNotBlank() -> "${d.parent1.ifBlank{"未登録"}} × ${d.parent2.ifBlank{"未登録"}}"
            else -> "未登録"
        }
        return "生息地: ${d.habitat.ifBlank{"未登録"}}\nスキル: ${d.skill.ifBlank{"未登録"}}\n特性: $traits\n装備可能武器: $weapons\n親の組み合わせ: $parents"
    }

    private fun showMonsterDetailV2818(no:Int) {
        // v2.8.19: detail popup was retired. Keep this compatibility entry point so
        // existing callers simply expand the management card instead.
        expandedManagementNo = no
        if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
    }

    private fun editMonsterExtendedDataDialogV2818(no:Int) {
        val m=monsters.firstOrNull{it.no==no} ?: return
        val d=monsterExtendedDataV2818(no)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(4))}
        box.addView(TextView(this).apply{text="No.${no.toString().padStart(3,'0')} ${m.name}\n空欄は未登録として保存します。特性は1行1件・最大7行。";textSize=12f;setTextColor(textSub)})
        fun edit(label:String,value:String,hint:String,lines:Int=1):EditText{box.addView(TextView(this).apply{text=label;textSize=12f;setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(0,dp(8),0,0)});return EditText(this).apply{setText(value);this.hint=hint;setSingleLine(lines==1);if(lines>1){minLines=lines;gravity=Gravity.TOP};box.addView(this)}}
        fun verified(field:String)=CheckBox(this).apply{text="この項目をゲーム内確認済みにする";textSize=11f;isChecked=fieldVerifiedV2818(no,field);box.addView(this)}
        val habitat=edit("生息地",d.habitat,"例: たびだちの扉"); val vh=verified("habitat")
        val skill=edit("スキル",d.skill,"例: スラフォース"); val vs=verified("skill")
        val traits=edit("特性",d.traits.joinToString("\n"),"1行1特性",5); val vt=verified("traits")
        val weapons=edit("装備できる武器",d.weapons.joinToString("、"),"例: 剣、槍、杖"); val vw=verified("weapons")
        val p1=edit("親1",d.parent1,"未判明なら 未判明")
        val p2=edit("親2",d.parent2,"未判明なら 未判明")
        val pp=edit("親組み合わせ表示",d.parentPattern,"例: スライム × ズッキーニャ / なし"); val vp=verified("parents")
        AlertDialog.Builder(this).setTitle("詳細データ編集").setView(ScrollView(this).apply{addView(box)}).setNegativeButton("キャンセル",null).setNeutralButton("拡張項目を消去"){_,_->saveExtendedMonsterDataV2818(no,"","","","","","","");listOf("habitat","skill","traits","weapons","parents").forEach{setFieldVerifiedV2818(no,it,false)};Toast.makeText(this,"拡張項目を消去しました",Toast.LENGTH_SHORT).show();expandedManagementNo=no;if(::monsterAdapter.isInitialized)monsterAdapter.notifyDataSetChanged()}.setPositiveButton("保存"){_,_->saveExtendedMonsterDataV2818(no,habitat.text.toString(),skill.text.toString(),traits.text.toString(),weapons.text.toString(),p1.text.toString(),p2.text.toString(),pp.text.toString());setFieldVerifiedV2818(no,"habitat",vh.isChecked);setFieldVerifiedV2818(no,"skill",vs.isChecked);setFieldVerifiedV2818(no,"traits",vt.isChecked);setFieldVerifiedV2818(no,"weapons",vw.isChecked);setFieldVerifiedV2818(no,"parents",vp.isChecked);Toast.makeText(this,"詳細データを保存しました",Toast.LENGTH_SHORT).show();expandedManagementNo=no;if(::monsterAdapter.isInitialized)monsterAdapter.notifyDataSetChanged()}.show()
    }

    // ---------------- Breeding page ----------------



    // ---------------- Monster data correction / dex screenshot ----------------

    private fun isMonsterDataModified(no: Int): Boolean =
        pref.contains("data_name_$no") || pref.contains("data_rank_$no") ||
            pref.contains("data_family_$no") || pref.contains("data_size_$no") ||
            pref.getBoolean("data_verified_$no", false) || hasExtendedMonsterDataV2818(no) || listOf("habitat","skill","traits","weapons","parents").any { fieldVerifiedV2818(no,it) }

    private fun saveMonsterDataOverride(no: Int, name: String, rank: String, family: String, size: String, verified: Boolean) {
        val base = baseMonsterByNo[no] ?: return
        val e = pref.edit()
        if (name.trim() == base.name) e.remove("data_name_$no") else e.putString("data_name_$no", name.trim())
        if (rank == base.rank) e.remove("data_rank_$no") else e.putString("data_rank_$no", rank)
        if (family == base.family) e.remove("data_family_$no") else e.putString("data_family_$no", family)
        if (size == base.size) e.remove("data_size_$no") else e.putString("data_size_$no", size)
        if (verified) e.putBoolean("data_verified_$no", true) else e.remove("data_verified_$no")
        e.apply()
        loadMonsters()
        if (::monsterAdapter.isInitialized) applyManagementFilter()
        if (::breedingAdapter.isInitialized) applyBreedingFilter()
    }

    private fun resetMonsterDataOverride(no: Int) {
        pref.edit().remove("data_name_$no").remove("data_rank_$no").remove("data_family_$no")
            .remove("data_size_$no").remove("data_verified_$no").remove("data_habitat_$no").remove("data_skill_$no").remove("data_traits_$no").remove("data_weapons_$no").remove("data_parent1_$no").remove("data_parent2_$no").remove("data_parent_pattern_$no")
            .remove("data_verified_habitat_$no").remove("data_verified_skill_$no").remove("data_verified_traits_$no").remove("data_verified_weapons_$no").remove("data_verified_parents_$no").apply()
        loadMonsters()
    }

    private fun showMonsterDataEditor() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)); setBackgroundColor(bg) }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply { text="モンスターデータ一覧・編集"; textSize=20f; setTextColor(textMain); setTypeface(typeface, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0,dp(44),1f))
        titleRow.addView(Button(this).apply { text="設定へ戻る"; styleButton(this, Color.rgb(69,90,100)); setOnClickListener { showSettingsPage() } }, LinearLayout.LayoutParams(dp(110),dp(40)))
        root.addView(titleRow)
        root.addView(TextView(this).apply { text="基本CSVを直接変更せず、修正値だけを優先表示します。✓はゲーム内確認済みです。"; textSize=11.5f; setTextColor(textSub) })
        val search = EditText(this).apply { hint="名前・図鑑No.で検索"; setSingleLine(true); setPadding(dp(8),0,dp(8),0) }
        root.addView(search, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(6) })
        val list = ListView(this).apply { dividerHeight=dp(1); setBackgroundColor(bg) }
        val shown = mutableListOf<Monster>().apply { addAll(monsters) }
        val adapter = object: BaseAdapter() {
            override fun getCount()=shown.size
            override fun getItem(position:Int)=shown[position]
            override fun getItemId(position:Int)=shown[position].no.toLong()
            override fun getView(position:Int, convertView:View?, parent:ViewGroup):View {
                val m=shown[position]
                return LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(8),dp(7),dp(8),dp(7)); background=roundedBg(Color.WHITE,8)
                    val frame=FrameLayout(this@MainActivity); val iv=ImageView(this@MainActivity).apply{scaleType=ImageView.ScaleType.CENTER_CROP;visibility=View.GONE}; val fb=TextView(this@MainActivity).apply{gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=roundedBg(Color.rgb(96,125,139),7)}
                    frame.addView(iv,FrameLayout.LayoutParams(dp(42),dp(42))); frame.addView(fb,FrameLayout.LayoutParams(dp(42),dp(42))); applyMonsterIcon(iv,fb,m)
                    addView(frame,LinearLayout.LayoutParams(dp(42),dp(42)).apply{marginEnd=dp(8)})
                    addView(TextView(this@MainActivity).apply {
                        val mark = when { pref.getBoolean("data_verified_${m.no}",false) -> " ✓ゲーム内確認済"; isMonsterDataModified(m.no) -> " ●修正あり"; else -> "" }
                        text="No.${m.no.toString().padStart(3,'0')}  ${m.name}$mark\n${m.rank} / ${m.family} / ${m.size}${if(hasExtendedMonsterDataV2818(m.no))" / 詳細データあり" else ""}"; textSize=13f; setTextColor(textMain)
                    },LinearLayout.LayoutParams(0,-2,1f))
                    addView(TextView(this@MainActivity).apply{text="編集 ＞";textSize=12f;setTextColor(primary);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(58),dp(40)))
                    setOnClickListener { editMonsterDataDialog(m.no) }
                }
            }
        }
        list.adapter=adapter
        search.addTextChangedListener(watcher {
            val q=search.text.toString().trim().lowercase(); shown.clear(); shown.addAll(monsters.filter { q.isBlank() || it.name.lowercase().contains(q) || it.no.toString().contains(q) }); adapter.notifyDataSetChanged()
        })
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=dp(6)})
        setContentView(root)
    }

    private fun editMonsterDataDialog(no: Int, suggestedFamily: String? = null, markVerified: Boolean = false, returnToManagement: Boolean = false) {
        val m = monsters.firstOrNull { it.no==no } ?: return
        val base = baseMonsterByNo[no] ?: m
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),0)}
        box.addView(TextView(this).apply{text="図鑑No. ${no.toString().padStart(3,'0')}（No.は固定）";textSize=12f;setTextColor(textSub)})
        val name=EditText(this).apply{hint="モンスター名";setText(m.name);setSingleLine(true)}; box.addView(name)
        fun labeled(label:String, sp:Spinner):LinearLayout = LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=label;textSize=13f},LinearLayout.LayoutParams(dp(62),dp(44)));addView(sp,LinearLayout.LayoutParams(0,dp(44),1f))}
        val ranks=arrayOf("SS","S","A","B","C","D","E","F")
        val rank=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,ranks);setSelection(ranks.indexOf(m.rank).coerceAtLeast(0))}; box.addView(labeled("ランク",rank))
        val families=arrayOf("スライム","ドラゴン","自然","魔獣","物質","悪魔","ゾンビ","？？？")
        val targetFamily=suggestedFamily ?: m.family
        val fam=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,families);setSelection(families.indexOf(targetFamily).coerceAtLeast(0))}; box.addView(labeled("系統",fam))
        val sizes=arrayOf("S","M","G")
        val size=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,sizes);setSelection(sizes.indexOf(m.size).coerceAtLeast(0))}; box.addView(labeled("サイズ",size))
        val verified=CheckBox(this).apply{text="ゲーム内図鑑で確認済み";isChecked=markVerified || pref.getBoolean("data_verified_$no",false)}; box.addView(verified)
        box.addView(TextView(this).apply{text="初期値: ${base.name} / ${base.rank} / ${base.family} / ${base.size}";textSize=11f;setTextColor(textSub);setPadding(0,dp(4),0,0)})
        box.addView(Button(this).apply{text="生息地・スキル・特性など詳細データを編集";textSize=11f;styleButton(this,Color.rgb(69,90,100));setOnClickListener{editMonsterExtendedDataDialogV2818(no)}},LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(8)})
        AlertDialog.Builder(this).setTitle("モンスターデータ編集").setView(box)
            .setNeutralButton("初期値に戻す") { _,_->
                resetMonsterDataOverride(no)
                if (returnToManagement) {
                    expandedManagementNo = no
                    if (::monsterAdapter.isInitialized) { applyManagementFilter(); monsterAdapter.notifyDataSetChanged() }
                } else showMonsterDataEditor()
            }
            .setNegativeButton("キャンセル",null)
            .setPositiveButton("保存") { _,_->
                saveMonsterDataOverride(no,name.text.toString(),rank.selectedItem.toString(),fam.selectedItem.toString(),size.selectedItem.toString(),verified.isChecked)
                Toast.makeText(this,"No.$no のデータを保存しました",Toast.LENGTH_SHORT).show()
                if (returnToManagement) {
                    expandedManagementNo = no
                    if (::monsterAdapter.isInitialized) { applyManagementFilter(); monsterAdapter.notifyDataSetChanged() }
                } else showMonsterDataEditor()
            }.show()
    }

    private fun confirmResetAllMonsterData() {
        val count=monsters.count{isMonsterDataModified(it.no)}
        AlertDialog.Builder(this).setTitle("修正データをすべてリセット").setMessage("ユーザー修正・ゲーム内確認済み情報 ${count}件を削除し、基本CSV表示へ戻します。\n所有数・ほしい数・画像には影響しません。")
            .setNegativeButton("キャンセル",null).setPositiveButton("リセット") { _,_->
                val e=pref.edit(); for(no in 1..659){e.remove("data_name_$no").remove("data_rank_$no").remove("data_family_$no").remove("data_size_$no").remove("data_verified_$no").remove("data_habitat_$no").remove("data_skill_$no").remove("data_traits_$no").remove("data_weapons_$no").remove("data_parent1_$no").remove("data_parent2_$no").remove("data_parent_pattern_$no").remove("data_verified_habitat_$no").remove("data_verified_skill_$no").remove("data_verified_traits_$no").remove("data_verified_weapons_$no").remove("data_verified_parents_$no")}; e.apply(); loadMonsters(); Toast.makeText(this,"修正データをリセットしました",Toast.LENGTH_LONG).show(); showSettingsPage()
            }.show()
    }

    private fun buildMonsterDataJson(): String {
        val arr=JSONArray()
        monsters.forEach { m -> if(isMonsterDataModified(m.no)) {
            val d=monsterExtendedDataV2818(m.no)
            arr.put(JSONObject().apply {
                put("no",m.no);put("name",m.name);put("rank",m.rank);put("family",m.family);put("size",m.size);put("verified",pref.getBoolean("data_verified_${m.no}",false))
                put("habitat",d.habitat);put("skill",d.skill);put("traits",JSONArray(d.traits));put("weapons",JSONArray(d.weapons));put("parent1",d.parent1);put("parent2",d.parent2);put("parentPattern",d.parentPattern)
                put("verifiedHabitat",fieldVerifiedV2818(m.no,"habitat"));put("verifiedSkill",fieldVerifiedV2818(m.no,"skill"));put("verifiedTraits",fieldVerifiedV2818(m.no,"traits"));put("verifiedWeapons",fieldVerifiedV2818(m.no,"weapons"));put("verifiedParents",fieldVerifiedV2818(m.no,"parents"))
            })
        } }
        return arr.toString()
    }

    private fun applyMonsterDataJson(text:String) {
        val arr=JSONArray(text); val e=pref.edit()
        for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); val no=o.optInt("no",-1); val base=baseMonsterByNo[no]?:continue
            val name=o.optString("name",base.name); val rank=o.optString("rank",base.rank); val family=o.optString("family",base.family); val size=o.optString("size",base.size)
            if(name==base.name)e.remove("data_name_$no") else e.putString("data_name_$no",name); if(rank==base.rank)e.remove("data_rank_$no") else e.putString("data_rank_$no",rank); if(family==base.family)e.remove("data_family_$no") else e.putString("data_family_$no",family); if(size==base.size)e.remove("data_size_$no") else e.putString("data_size_$no",size)
            if(o.optBoolean("verified",false)) e.putBoolean("data_verified_$no",true) else e.remove("data_verified_$no")
            fun restoreText(key:String,jsonKey:String){ val v=o.optString(jsonKey,"").trim(); if(v.isBlank())e.remove("${key}_$no") else e.putString("${key}_$no",v) }
            restoreText("data_habitat","habitat"); restoreText("data_skill","skill"); restoreText("data_parent1","parent1"); restoreText("data_parent2","parent2"); restoreText("data_parent_pattern","parentPattern")
            val ta=o.optJSONArray("traits"); if(ta==null || ta.length()==0)e.remove("data_traits_$no") else e.putString("data_traits_$no",ta.toString())
            val wa=o.optJSONArray("weapons"); if(wa==null || wa.length()==0)e.remove("data_weapons_$no") else e.putString("data_weapons_$no",wa.toString())
            listOf("Habitat" to "habitat","Skill" to "skill","Traits" to "traits","Weapons" to "weapons","Parents" to "parents").forEach { pair -> val k="data_verified_${pair.second}_$no"; if(o.optBoolean("verified${pair.first}",false))e.putBoolean(k,true) else e.remove(k) }
        }
        e.apply(); loadMonsters()
    }

    private fun startMonsterDataBackup() = startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="application/json";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_TITLE,"TerrySP_monster_database_v2.8.23.json") },1018)
    private fun startMonsterDataRestore() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/json";addCategory(Intent.CATEGORY_OPENABLE) },1019)
    private fun writeMonsterDataBackup(uri:Uri) { contentResolver.openOutputStream(uri)?.use{it.write(buildMonsterDataJson().toByteArray(StandardCharsets.UTF_8))};Toast.makeText(this,"修正データを保存しました",Toast.LENGTH_SHORT).show() }
    private fun restoreMonsterDataBackup(uri:Uri) { val text=contentResolver.openInputStream(uri)?.bufferedReader()?.readText()?:return; applyMonsterDataJson(text);Toast.makeText(this,"修正データをリストアしました",Toast.LENGTH_LONG).show();showSettingsPage() }

    private fun startMonsterDexScreenshotImport() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*";addCategory(Intent.CATEGORY_OPENABLE) },1017)
    }


    private fun startMonsterDexOcrValidation() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*";addCategory(Intent.CATEGORY_OPENABLE) },1020)
    }

    private fun startMonsterDexOcrUpdateV2822() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*";addCategory(Intent.CATEGORY_OPENABLE) },1021)
    }

    private data class DexUpdateDataV2822(
        val candidates:List<DisplayCandidateV280>,
        val family:Pair<String,Double>?,
        val habitat:String,
        val skill:String,
        val traits:List<String>,
        val parentPattern:String
    )

    private data class DexOcrPassV2816(
        val raw:String,
        val normalized:String
    )

    private data class DexOcrFieldV2816(
        val title:String,
        val crop:Bitmap,
        val normal:DexOcrPassV2816,
        val enhanced:DexOcrPassV2816,
        val finalText:String,
        val status:String = ""
    )

    private data class DexTraitLineV2816(
        val index:Int,
        val crop:Bitmap,
        val normal:DexOcrPassV2816,
        val enhanced:DexOcrPassV2816,
        val dictionaryCandidate:String,
        val finalText:String,
        val unknown:Boolean
    )

    private fun cleanDexOcrTextV2816(text:String):String {
        return text.replace("\r", "")
            .lines()
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotBlank() }
            .joinToString("\n")
    }

    private fun recognizeDexCropV2816(recognizer:com.google.mlkit.vision.text.TextRecognizer, crop:Bitmap):DexOcrPassV2816 {
        val result=Tasks.await(recognizer.process(InputImage.fromBitmap(crop,0)))
        val raw=result.text ?: ""
        return DexOcrPassV2816(raw,cleanDexOcrTextV2816(raw))
    }

    private fun enhanceDexTextBitmapV2816(src:Bitmap, scale:Int=3):Bitmap {
        val w=src.width; val h=src.height
        val pixels=IntArray(w*h); src.getPixels(pixels,0,w,0,0,w,h)
        var minL=255; var maxL=0
        val lum=IntArray(pixels.size)
        for(i in pixels.indices) {
            val c=pixels[i]
            val y=(Color.red(c)*30 + Color.green(c)*59 + Color.blue(c)*11)/100
            lum[i]=y; if(y<minL)minL=y; if(y>maxL)maxL=y
        }
        val span=(maxL-minL).coerceAtLeast(24)
        val out=IntArray(pixels.size)
        for(i in out.indices) {
            // Stretch the local luminance range. Gray disabled text is deliberately lifted away from brown UI backgrounds.
            var v=((lum[i]-minL)*255/span)
            v=((v-96)*1.35+112).toInt().coerceIn(0,255)
            out[i]=Color.rgb(v,v,v)
        }
        val base=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        base.setPixels(out,0,w,0,0,w,h)
        val scaled=Bitmap.createScaledBitmap(base,(w*scale).coerceAtLeast(2),(h*scale).coerceAtLeast(2),true)
        if(scaled !== base) base.recycle()
        return scaled
    }

    private fun visibleBrightTextRatioV2816(src:Bitmap):Double {
        if(src.width<=0 || src.height<=0)return 0.0
        var hit=0; var total=0
        val step=2
        for(y in 0 until src.height step step) for(x in 0 until src.width step step) {
            val c=src.getPixel(x,y); val r=Color.red(c); val g=Color.green(c); val b=Color.blue(c)
            val mx=maxOf(r,g,b); val mn=minOf(r,g,b)
            // UI text/question marks are bright and close to neutral; this avoids most of the brown background.
            if(mx>=145 && mx-mn<=52) hit++
            total++
        }
        return if(total==0)0.0 else hit.toDouble()/total
    }

    private fun looksUnknownQuestionRowV2817(src:Bitmap, normal:String, enhanced:String):Boolean {
        val joined=(normal+" "+enhanced).replace(" ","").replace("\n","").trim()
        if(joined.count{it=='?'}>=3 || joined.count{it=='？'}>=3)return true
        // Repeated ???????? is frequently OCR'd as a run of the same kana (for example とととととととと).
        if(joined.length>=5) {
            val counts=joined.groupingBy{it}.eachCount()
            val maxRepeat=counts.values.maxOrNull() ?: 0
            if(maxRepeat.toDouble()/joined.length >= 0.70) return true
        }
        // ML Kit may also return no text at all for the repeated question-mark glyphs.
        return joined.isBlank() && visibleBrightTextRatioV2816(src)>=0.018
    }

    private fun chooseOcrTextV2816(a:String,b:String):String {
        if(a.isBlank())return b
        if(b.isBlank())return a
        fun quality(t:String):Int {
            val compact=t.replace(" ","").replace("\n","")
            val jp=compact.count { it.code in 0x3040..0x30ff || it.code in 0x4e00..0x9fff }
            val bad=compact.count { it=='�' || it=='|' || it=='_' }
            return compact.length*2+jp*2-bad*3
        }
        return if(quality(b)>quality(a))b else a
    }

    private fun levenshteinV2816(a:String,b:String):Int {
        if(a.isEmpty())return b.length; if(b.isEmpty())return a.length
        var prev=IntArray(b.length+1){it}; var cur=IntArray(b.length+1)
        for(i in 1..a.length){ cur[0]=i; for(j in 1..b.length){ val cost=if(a[i-1]==b[j-1])0 else 1; cur[j]=minOf(cur[j-1]+1,prev[j]+1,prev[j-1]+cost) }; val t=prev;prev=cur;cur=t }
        return prev[b.length]
    }

    private val dexTraitDictionarySeedV2817=listOf(
        "スタンダードボディ","スモールボディ","メガボディ","AI 1〜2回行動","AI 1～2回行動",
        "みかわしアップ","れんぞく","ひん死で 呪文会心","マホキテボディ","ラブリー","バギブレイク",
        "タメキテボディ","封じブレイク","パラメータブレイク","ヒャドブレイク","テンションアップ",
        "自動HP回復","メラ系のコツ","ねがえり","マヒブレイク","吹雪ブレスブレイク","ギガキラー",
        "炎ブレスブレイク","デイン系のコツ","会心 出やすい","一族のほこり"
    )

    private val dexSkillDictionarySeedV2817=listOf(
        "スラフォース","ドラゴンスピリッツ","死神","さいみん","いしあたま","けもの道","アンデッド"
    )

    private val dexHabitatDictionarySeedV2817=listOf(
        "たびだちの扉","まもりの扉","ゆうきの扉"
    )

    private fun masterListV2820(key:String):List<String> = jsonListV2820(prefStringV2818("master_$key"))
    private fun dexTraitDictionaryV2820():List<String> = (dexTraitDictionarySeedV2817 + masterListV2820("traits")).distinct()
    private fun dexSkillDictionaryV2820():List<String> = (dexSkillDictionarySeedV2817 + masterListV2820("skills")).distinct()
    private fun dexHabitatDictionaryV2820():List<String> = (dexHabitatDictionarySeedV2817 + masterListV2820("locations")).distinct()

    private fun normalizeForDictionaryV2817(s:String)=s.replace(" ","").replace("　","").replace("～","〜").replace("\n","")

    private fun weightedEditDistanceV2817(a:String,b:String):Double {
        val x=normalizeForDictionaryV2817(a); val y=normalizeForDictionaryV2817(b)
        if(x.isEmpty())return y.length.toDouble(); if(y.isEmpty())return x.length.toDouble()
        val confusable=setOf(
            "バパ","パバ","ビピ","ピビ","ヒビ","ビヒ","ヒピ","ピヒ",
            "ギキ","キギ","レラ","ラレ","ブプ","プブ","ダタ","タダ"
        )
        var prev=DoubleArray(y.length+1){it.toDouble()}; var cur=DoubleArray(y.length+1)
        for(i in 1..x.length) {
            cur[0]=i.toDouble()
            for(j in 1..y.length) {
                val pair="${x[i-1]}${y[j-1]}"
                val sub=when { x[i-1]==y[j-1] -> 0.0; pair in confusable -> 0.35; else -> 1.0 }
                cur[j]=minOf(cur[j-1]+1.0,prev[j]+1.0,prev[j-1]+sub)
            }
            val t=prev; prev=cur; cur=t
        }
        return prev[y.length]
    }

    private data class DexDictionaryMatchV2817(val text:String,val similarity:Double)

    private fun dictionaryCorrectionV2817(text:String,dictionary:List<String>):DexDictionaryMatchV2817 {
        if(text.isBlank())return DexDictionaryMatchV2817("",0.0)
        val src=normalizeForDictionaryV2817(text)
        var best=""; var bestRatio=0.0
        for(item in dictionary) {
            val dst=normalizeForDictionaryV2817(item); val maxLen=maxOf(src.length,dst.length).coerceAtLeast(1)
            val ratio=(1.0-weightedEditDistanceV2817(src,dst)/maxLen).coerceIn(0.0,1.0)
            if(ratio>bestRatio){bestRatio=ratio;best=item}
        }
        return DexDictionaryMatchV2817(best,bestRatio)
    }

    private fun correctedFieldTextV2817(base:String,dictionary:List<String>):Pair<String,String> {
        if(base.isBlank())return "" to ""
        val m=dictionaryCorrectionV2817(base,dictionary)
        val final=if(m.similarity>=0.70)m.text else base
        val status=if(m.text.isBlank())"" else "辞書候補: ${m.text} / 類似度 ${(m.similarity*100).toInt()}%${if(m.similarity>=0.70)" → 採用" else ""}"
        return final to status
    }

    private fun subCropByFractionV2816(src:Bitmap, top:Double,bottom:Double,left:Double=0.0,right:Double=1.0):Bitmap {
        val x=(src.width*left).toInt().coerceIn(0,src.width-1); val y=(src.height*top).toInt().coerceIn(0,src.height-1)
        val rr=(src.width*right).toInt().coerceIn(x+1,src.width); val bb=(src.height*bottom).toInt().coerceIn(y+1,src.height)
        return Bitmap.createBitmap(src,x,y,rr-x,bb-y)
    }

    private fun readDualPassV2816(recognizer:com.google.mlkit.vision.text.TextRecognizer,crop:Bitmap):Triple<DexOcrPassV2816,DexOcrPassV2816,Bitmap> {
        val normal=recognizeDexCropV2816(recognizer,crop)
        val enhancedBmp=enhanceDexTextBitmapV2816(crop)
        val enhanced=recognizeDexCropV2816(recognizer,enhancedBmp)
        return Triple(normal,enhanced,enhancedBmp)
    }

    private fun analyzeParentCombinationV2816(recognizer:com.google.mlkit.vision.text.TextRecognizer, crop:Bitmap):Pair<String,List<DexOcrFieldV2816>> {
        val wholeTriple=readDualPassV2816(recognizer,crop); val wholeFinal=chooseOcrTextV2816(wholeTriple.first.normalized,wholeTriple.second.normalized)
        wholeTriple.third.recycle()
        if(wholeFinal.replace(" ","").contains("なし")) {
            val f=DexOcrFieldV2816("親の組み合わせ（全体）",crop,wholeTriple.first,wholeTriple.second,"なし","なし")
            return "なし" to listOf(f)
        }
        // The game lays the two parent values above and below the multiplication sign. Read them independently.
        val top=subCropByFractionV2816(crop,0.00,0.43,0.00,0.86)
        val bottom=subCropByFractionV2816(crop,0.55,1.00,0.00,0.86)
        fun readParent(label:String,bmp:Bitmap):Pair<String,DexOcrFieldV2816> {
            val t=readDualPassV2816(recognizer,bmp); val unknown=looksUnknownQuestionRowV2817(bmp,t.first.normalized,t.second.normalized)
            val chosen=if(unknown)"未判明" else chooseOcrTextV2816(t.first.normalized,t.second.normalized).ifBlank{"（読み取りなし）"}
            t.third.recycle()
            return chosen to DexOcrFieldV2816(label,bmp,t.first,t.second,chosen,if(unknown)"??????? → 未判明" else "")
        }
        val p1=readParent("親1",top); val p2=readParent("親2",bottom)
        val pattern="${p1.first} × ${p2.first}"
        return pattern to listOf(p1.second,p2.second)
    }

    private fun analyzeTraitLinesV2816(recognizer:com.google.mlkit.vision.text.TextRecognizer, traits:Bitmap):List<DexTraitLineV2816> {
        val out=ArrayList<DexTraitLineV2816>()
        for(i in 0 until 7) {
            // Seven fixed slots; a small inset avoids the top/bottom edges of the rounded brown row.
            val a=i/7.0; val b=(i+1)/7.0
            val line=subCropByFractionV2816(traits,a+0.008,b-0.008,0.00,1.00)
            val t=readDualPassV2816(recognizer,line)
            val unknown=looksUnknownQuestionRowV2817(line,t.first.normalized,t.second.normalized)
            val base=if(unknown)"未判明" else chooseOcrTextV2816(t.first.normalized,t.second.normalized)
            val match=if(unknown)DexDictionaryMatchV2817("",0.0) else dictionaryCorrectionV2817(base,dexTraitDictionaryV2820())
            val dictLabel=if(match.text.isBlank())"" else "${match.text} (${(match.similarity*100).toInt()}%)"
            val final=when { unknown->"未判明"; match.similarity>=0.70->match.text; base.isNotBlank()->base; else->"（空欄）" }
            t.third.recycle()
            out.add(DexTraitLineV2816(i+1,line,t.first,t.second,dictLabel,final,unknown))
        }
        return out
    }

    private fun showDexOcrValidationResultV2816(
        monsterNo:Int?,
        monsterLabel:String,
        habitat:DexOcrFieldV2816,
        parentPattern:String,
        parentFields:List<DexOcrFieldV2816>,
        skill:DexOcrFieldV2816,
        traitsCrop:Bitmap,
        traitLines:List<DexTraitLineV2816>,
        weaponCrop:Bitmap,
        weaponState:String
    ) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(6),dp(12),dp(8)) }
        box.addView(TextView(this).apply { text="認識モンスター候補: $monsterLabel"; textSize=15f; setTextColor(textMain); setPadding(0,0,0,dp(8)) })
        box.addView(TextView(this).apply { text="※検証専用です。DBへ自動保存しません。\n通常OCR・強調OCRに加え、辞書補正と ???????? 専用判定を比較します。"; textSize=11f; setTextColor(textSub); setPadding(0,0,0,dp(8)) })
        monsterNo?.let { no ->
            val current=monsterExtendedDataV2818(no)
            val traitsNow=if(current.traits.isEmpty())"未登録" else current.traits.joinToString(" / ")
            box.addView(TextView(this).apply {
                text="【現在DB】\n生息地: ${current.habitat.ifBlank{"未登録"}}\nスキル: ${current.skill.ifBlank{"未登録"}}\n特性: $traitsNow\n親: ${current.parentPattern.ifBlank{if(current.parent1.isBlank()&&current.parent2.isBlank())"未登録" else "${current.parent1} × ${current.parent2}"}}"
                textSize=11.5f;setTextColor(textMain);background=roundedBg(Color.rgb(238,244,255),8);setPadding(dp(8),dp(7),dp(8),dp(7))
            })
        }
        fun addImage(title:String,bmp:Bitmap,height:Int=64) {
            box.addView(TextView(this).apply { text=title; textSize=14f; setTextColor(textMain); setPadding(0,dp(8),0,dp(3)) })
            box.addView(ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.rgb(244,244,244)) }, LinearLayout.LayoutParams(-1,dp(height)))
        }
        fun addField(f:DexOcrFieldV2816) {
            addImage("【${f.title}】切り出し",f.crop)
            box.addView(TextView(this).apply {
                text="通常OCR: ${f.normal.normalized.ifBlank{"（検出なし）"}}\n強調OCR: ${f.enhanced.normalized.ifBlank{"（検出なし）"}}\n最終: ${f.finalText.ifBlank{"（なし）"}}${if(f.status.isBlank())"" else "\n判定: ${f.status}"}"
                textSize=12f; setTextColor(textMain); setPadding(dp(4),dp(4),dp(4),dp(4))
            })
        }
        addField(habitat)
        box.addView(TextView(this).apply { text="【親の組み合わせ】最終判定: $parentPattern"; textSize=14f; setTextColor(textMain); setPadding(0,dp(10),0,dp(3)) })
        parentFields.forEach { addField(it) }
        addField(skill)
        monsterNo?.let { no ->
            val cur=monsterExtendedDataV2818(no)
            fun cmp(label:String, old:String, read:String)=if(old.isBlank())"$label: DB未登録 → 読取 [$read]" else if(normalizeForDictionaryV2817(old)==normalizeForDictionaryV2817(read))"$label: ✓一致" else "$label: 相違  DB[$old] / 読取[$read]"
            box.addView(TextView(this).apply { text="【DB比較】\n${cmp("生息地",cur.habitat,habitat.finalText)}\n${cmp("スキル",cur.skill,skill.finalText)}\n親: ${if(cur.parentPattern.isBlank())"DB未登録 → 読取 [$parentPattern]" else if(normalizeForDictionaryV2817(cur.parentPattern)==normalizeForDictionaryV2817(parentPattern))"✓一致" else "相違  DB[${cur.parentPattern}] / 読取[$parentPattern]"}";textSize=11.5f;setTextColor(textMain);setPadding(dp(5),dp(8),dp(5),dp(4)) })
        }
        addImage("【特性】全体切り出し",traitsCrop,100)
        box.addView(TextView(this).apply { text="特性は最大7行を固定スロットで個別検証します。グレー文字も強調OCRを併用します。"; textSize=11f; setTextColor(textSub); setPadding(dp(4),dp(4),dp(4),dp(4)) })
        traitLines.forEach { line ->
            addImage("特性 ${line.index}",line.crop,38)
            box.addView(TextView(this).apply {
                text="通常: ${line.normal.normalized.ifBlank{"（検出なし）"}}\n強調: ${line.enhanced.normalized.ifBlank{"（検出なし）"}}\n辞書候補: ${line.dictionaryCandidate.ifBlank{"（なし）"}}\n最終: ${line.finalText}"
                textSize=11.5f; setTextColor(textMain); setPadding(dp(4),dp(2),dp(4),dp(5))
            })
        }
        addImage("【装備できる武器】切り出し",weaponCrop,64)
        box.addView(TextView(this).apply { text="状態判定: $weaponState\n※武器アイコン自体の種類判定は次段階で参照辞書と画像照合します。"; textSize=12f; setTextColor(textSub); setPadding(dp(4),dp(4),dp(4),dp(8)) })
        val scroll=ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle("図鑑OCR検証 v2.8.23").setView(scroll).setNegativeButton("閉じる",null).setPositiveButton("同じ画像を通常読取") { _,_-> Toast.makeText(this,"図鑑スクリーンショット読取から同じ画像を選択してください",Toast.LENGTH_LONG).show() }.show()
    }

    private fun handleMonsterDexOcrValidationV2816(uri:Uri) {
        Toast.makeText(this,"図鑑OCR v2.8.23を検証しています…",Toast.LENGTH_SHORT).show()
        Thread {
            var source:Bitmap?=null
            val created=ArrayList<Bitmap>()
            try {
                source=contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it)} ?: throw IllegalArgumentException("画像を開けません")
                if(source!!.height < source!!.width) throw IllegalArgumentException("縦向きの図鑑スクリーンショットを選択してください")
                val family=detectDexFamilyV2814(source!!)
                val candidates=suggestDexCandidatesV2814(source!!,family,1)
                val monsterNo=candidates.firstOrNull()?.monster?.no
                val monsterLabel=candidates.firstOrNull()?.let { "No.${it.monster.no.toString().padStart(3,'0')} ${it.monster.name} / 画像一致 ${(it.score*100).toInt()}%" } ?: "候補なし"
                val habitat=normalizedCrop(source!!,0.390,0.389,0.842,0.421); created.add(habitat)
                val parents=normalizedCrop(source!!,0.389,0.421,0.842,0.488); created.add(parents)
                val weapons=normalizedCrop(source!!,0.395,0.493,0.842,0.520); created.add(weapons)
                val skill=normalizedCrop(source!!,0.392,0.521,0.842,0.550); created.add(skill)
                // Extend slightly downward so all seven possible trait rows are included.
                val traits=normalizedCrop(source!!,0.390,0.551,0.842,0.711); created.add(traits)
                val recognizer=TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())

                fun field(title:String,crop:Bitmap,unknownAllowed:Boolean=false,dictionary:List<String>?=null):DexOcrFieldV2816 {
                    val t=readDualPassV2816(recognizer,crop)
                    val unknown=unknownAllowed && looksUnknownQuestionRowV2817(crop,t.first.normalized,t.second.normalized)
                    val base=if(unknown)"未判明" else chooseOcrTextV2816(t.first.normalized,t.second.normalized)
                    val corrected=if(!unknown && dictionary!=null)correctedFieldTextV2817(base,dictionary) else base to ""
                    val final=corrected.first
                    val status=if(unknown)"??????? → 未判明" else corrected.second
                    t.third.recycle()
                    return DexOcrFieldV2816(title,crop,t.first,t.second,final,status)
                }
                val habitatResult=field("生息地",habitat,true,dexHabitatDictionaryV2820())
                val parentResult=analyzeParentCombinationV2816(recognizer,parents)
                val skillResult=field("スキル",skill,true,dexSkillDictionaryV2820())
                val traitLines=analyzeTraitLinesV2816(recognizer,traits)

                val wt=readDualPassV2816(recognizer,weapons)
                val weaponUnknown=looksUnknownQuestionRowV2817(weapons,wt.first.normalized,wt.second.normalized)
                val weaponState=if(weaponUnknown)"未判明（???????? を検出）" else "武器アイコン表示候補（参照辞書照合は未実装）"
                wt.third.recycle()
                recognizer.close()
                runOnUiThread { showDexOcrValidationResultV2816(monsterNo,monsterLabel,habitatResult,parentResult.first,parentResult.second,skillResult,traits,traitLines,weapons,weaponState) }
            } catch(t:Throwable) {
                runOnUiThread { AlertDialog.Builder(this).setTitle("図鑑OCR検証に失敗しました").setMessage(t.message?:t::class.java.simpleName).setPositiveButton("OK",null).show() }
                created.forEach { try{ if(!it.isRecycled) it.recycle() }catch(_:Throwable){} }
            } finally {
                try { source?.recycle() } catch(_:Throwable){}
            }
        }.start()
    }

    // ---------------- v2.8.22 OCR database updater ----------------
    private fun handleMonsterDexOcrUpdateV2822(uri:Uri) {
        Toast.makeText(this,"図鑑スクリーンショットから更新候補を作成しています…",Toast.LENGTH_SHORT).show()
        Thread {
            var source:Bitmap?=null
            val created=ArrayList<Bitmap>()
            try {
                source=contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it)} ?: throw IllegalArgumentException("画像を開けません")
                if(source!!.height < source!!.width) throw IllegalArgumentException("縦向きの図鑑スクリーンショットを選択してください")
                val family=detectDexFamilyV2814(source!!)
                val candidates=suggestDexCandidatesV2814(source!!,family,3)
                if(candidates.isEmpty()) throw IllegalArgumentException("モンスター候補を特定できませんでした")

                val habitat=normalizedCrop(source!!,0.390,0.389,0.842,0.421); created.add(habitat)
                val parents=normalizedCrop(source!!,0.389,0.421,0.842,0.488); created.add(parents)
                val skill=normalizedCrop(source!!,0.392,0.521,0.842,0.550); created.add(skill)
                val traits=normalizedCrop(source!!,0.390,0.551,0.842,0.711); created.add(traits)
                val recognizer=TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())

                fun field(crop:Bitmap, dictionary:List<String>):String {
                    val t=readDualPassV2816(recognizer,crop)
                    val unknown=looksUnknownQuestionRowV2817(crop,t.first.normalized,t.second.normalized)
                    val base=if(unknown)"未判明" else chooseOcrTextV2816(t.first.normalized,t.second.normalized)
                    val corrected=if(!unknown)correctedFieldTextV2817(base,dictionary).first else base
                    t.third.recycle(); return corrected
                }
                val habitatText=field(habitat,dexHabitatDictionaryV2820())
                val skillText=field(skill,dexSkillDictionaryV2820())
                val parentResult=analyzeParentCombinationV2816(recognizer,parents)
                val traitLines=analyzeTraitLinesV2816(recognizer,traits)
                val traitText=traitLines.map{it.finalText}.filter{it.isNotBlank() && it!="（空欄）"}.take(7)
                recognizer.close()
                val result=DexUpdateDataV2822(candidates,family,habitatText,skillText,traitText,parentResult.first)
                runOnUiThread { showDexOcrUpdateCandidateV2822(result) }
            } catch(t:Throwable) {
                runOnUiThread { AlertDialog.Builder(this).setTitle("図鑑OCR更新に失敗しました").setMessage(t.message?:t::class.java.simpleName).setPositiveButton("OK",null).show() }
            } finally {
                created.forEach { try{if(!it.isRecycled)it.recycle()}catch(_:Throwable){} }
                try{source?.recycle()}catch(_:Throwable){}
            }
        }.start()
    }

    private fun showDexOcrUpdateCandidateV2822(result:DexUpdateDataV2822) {
        var selected=0
        val fam=result.family?.let{" / 系統候補 ${it.first} ${(it.second*100).toInt()}%"}.orEmpty()
        val labels=result.candidates.map { c ->
            val mark=result.family?.let{if(c.monster.family==it.first)" / 系統一致" else " / 系統DB:${c.monster.family}"}.orEmpty()
            "No.${c.monster.no.toString().padStart(3,'0')} ${c.monster.name}　画像一致 ${(c.score*100).toInt()}%$mark"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("更新対象を確認$fam")
            .setMessage("誤ったモンスターへ書き込まないため、対象を確認してください。")
            .setSingleChoiceItems(labels,0){_,which->selected=which}
            .setNegativeButton("キャンセル",null)
            .setPositiveButton("読取結果を確認"){_,_->showDexOcrApplyDialogV2822(result.candidates[selected].monster,result)}.show()
    }

    private fun showDexOcrApplyDialogV2822(monster:Monster, result:DexUpdateDataV2822) {
        val no=monster.no; val cur=monsterExtendedDataV2818(no)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(6),dp(14),dp(4))}
        box.addView(TextView(this).apply{
            text="No.${no.toString().padStart(3,'0')} ${monster.name}\n読み取った項目だけを選択してゲーム内確認値として保存します。\n※装備武器はアイコン辞書未実装のため今回は自動更新しません。"
            textSize=12f;setTextColor(textSub);setPadding(0,0,0,dp(8))
        })
        data class Choice(val key:String,val check:CheckBox,val value:String)
        val choices=ArrayList<Choice>()
        fun row(key:String,label:String,old:String,read:String,enabled:Boolean=true){
            val cb=CheckBox(this).apply{isChecked=enabled && read.isNotBlank();isEnabled=enabled && read.isNotBlank()}
            val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedBg(Color.rgb(246,248,251),8);setPadding(dp(6),dp(4),dp(6),dp(4))}
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(cb,LinearLayout.LayoutParams(dp(42),dp(40)))
            top.addView(TextView(this).apply{text=label;textSize=13f;setTypeface(typeface,android.graphics.Typeface.BOLD);setTextColor(textMain)},LinearLayout.LayoutParams(0,dp(40),1f))
            wrap.addView(top)
            wrap.addView(TextView(this).apply{text="現在: ${old.ifBlank{"未登録"}}\n読取: ${read.ifBlank{"（読み取りなし）"}}";textSize=11.5f;setTextColor(textSub);setPadding(dp(42),0,0,dp(4))})
            box.addView(wrap,LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(5)})
            choices.add(Choice(key,cb,read))
        }
        row("habitat","生息地",cur.habitat,result.habitat)
        row("skill","スキル",cur.skill,result.skill)
        row("traits","特性",if(cur.traits.isEmpty())"" else cur.traits.joinToString(" / "),result.traits.joinToString(" / "))
        row("parents","親の組み合わせ",cur.parentPattern.ifBlank{if(cur.parent1.isBlank()&&cur.parent2.isBlank())"" else "${cur.parent1} × ${cur.parent2}"},result.parentPattern)
        row("weapons","装備できる武器",cur.weapons.joinToString(" / "),"アイコン辞書準備中",false)
        val scroll=ScrollView(this).apply{addView(box)}
        AlertDialog.Builder(this).setTitle("図鑑OCR → DB更新")
            .setView(scroll).setNegativeButton("キャンセル",null)
            .setPositiveButton("選択項目を更新"){_,_->
                val e=pref.edit(); var updated=0
                choices.forEach { c -> if(c.check.isChecked) {
                    when(c.key) {
                        "habitat" -> { if(c.value.isBlank())e.remove("data_habitat_$no") else e.putString("data_habitat_$no",c.value); e.putBoolean("data_verified_habitat_$no",true) }
                        "skill" -> { if(c.value.isBlank())e.remove("data_skill_$no") else e.putString("data_skill_$no",c.value); e.putBoolean("data_verified_skill_$no",true) }
                        "traits" -> { val a=JSONArray(result.traits); if(a.length()==0)e.remove("data_traits_$no") else e.putString("data_traits_$no",a.toString()); e.putBoolean("data_verified_traits_$no",true) }
                        "parents" -> {
                            val pat=result.parentPattern.trim(); var p1=""; var p2=""
                            if(pat!="なし") { val parts=pat.split(" × ",limit=2); p1=parts.getOrNull(0).orEmpty(); p2=parts.getOrNull(1).orEmpty() }
                            if(p1.isBlank())e.remove("data_parent1_$no") else e.putString("data_parent1_$no",p1)
                            if(p2.isBlank())e.remove("data_parent2_$no") else e.putString("data_parent2_$no",p2)
                            if(pat.isBlank())e.remove("data_parent_pattern_$no") else e.putString("data_parent_pattern_$no",pat)
                            e.putBoolean("data_verified_parents_$no",true)
                        }
                    }; updated++
                }}
                e.apply(); expandedManagementNo=no; if(::monsterAdapter.isInitialized)monsterAdapter.notifyDataSetChanged()
                Toast.makeText(this,"${monster.name}：$updated 項目をゲーム内確認値として更新しました",Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun normalizedCrop(source:Bitmap, l:Double,t:Double,r:Double,b:Double):Bitmap {
        val x=(source.width*l).toInt().coerceIn(0,source.width-2); val y=(source.height*t).toInt().coerceIn(0,source.height-2)
        val w=(source.width*(r-l)).toInt().coerceAtLeast(2).coerceAtMost(source.width-x); val h=(source.height*(b-t)).toInt().coerceAtLeast(2).coerceAtMost(source.height-y)
        return Bitmap.createBitmap(source,x,y,w,h)
    }

    private fun normalizeDexBitmapV2814(source: Bitmap, size: Int = 64): Bitmap {
        // Dedicated library-screen normalization. Unlike breeding recognition, the library portrait
        // has no rank/sex/party overlays, so do not mask its corners.
        return Bitmap.createScaledBitmap(source, size, size, true).copy(Bitmap.Config.ARGB_8888, false)
    }

    private fun compareDexBitmapV2814(aBmp: Bitmap, bBmp: Bitmap): Double {
        val size=64
        val a=if(aBmp.width==size && aBmp.height==size)aBmp else Bitmap.createScaledBitmap(aBmp,size,size,true)
        val b=if(bBmp.width==size && bBmp.height==size)bBmp else Bitmap.createScaledBitmap(bBmp,size,size,true)
        val ap=IntArray(size*size); val bp=IntArray(size*size)
        a.getPixels(ap,0,size,0,0,size,size); b.getPixels(bp,0,size,0,0,size,size)
        fun lum(c:Int)=Color.red(c)*0.299+Color.green(c)*0.587+Color.blue(c)*0.114
        var colorDiff=0.0; var edgeDiff=0.0; var n=0; var en=0
        // Ignore only a very thin outer edge; the blue/gold frame is useful identity/alignment information.
        for(y in 2 until size-2) for(x in 2 until size-2){
            val i=y*size+x; val ca=ap[i]; val cb=bp[i]
            colorDiff += (kotlin.math.abs(Color.red(ca)-Color.red(cb)) + kotlin.math.abs(Color.green(ca)-Color.green(cb)) + kotlin.math.abs(Color.blue(ca)-Color.blue(cb))) / (255.0*3.0)
            n++
            if(x in 3 until size-3 && y in 3 until size-3){
                val ae=kotlin.math.abs(lum(ap[i+1])-lum(ap[i-1])) + kotlin.math.abs(lum(ap[i+size])-lum(ap[i-size]))
                val be=kotlin.math.abs(lum(bp[i+1])-lum(bp[i-1])) + kotlin.math.abs(lum(bp[i+size])-lum(bp[i-size]))
                edgeDiff += kotlin.math.abs(ae-be)/(255.0*2.0); en++
            }
        }
        val colorScore=(1.0-colorDiff/maxOf(1,n)).coerceIn(0.0,1.0)
        val edgeScore=(1.0-edgeDiff/maxOf(1,en)).coerceIn(0.0,1.0)
        if(a!==aBmp)a.recycle(); if(b!==bBmp)b.recycle()
        return (colorScore*0.72 + edgeScore*0.28).coerceIn(0.0,1.0)
    }

    private fun detectDexFamilyV2814(source:Bitmap):Pair<String,Double>? {
        // 658x1536 reference: emblem is roughly x=292..327, y=474..511.
        // Keep a little margin to tolerate device scaling, but exclude the monster-name text.
        val crop=normalizedCrop(source,0.438,0.304,0.505,0.338)
        val norm=normalizeDexBitmapV2814(crop,48); crop.recycle()
        val fams=listOf("スライム","ドラゴン","自然","魔獣","物質","悪魔","ゾンビ","？？？")
        var best:String?=null; var bestScore=-1.0
        fams.forEach { f ->
            val ref=BitmapFactory.decodeResource(resources,familyIconRes(f)) ?: return@forEach
            val rn=normalizeDexBitmapV2814(ref,48); val sc=compareDexBitmapV2814(norm,rn); rn.recycle(); ref.recycle()
            if(sc>bestScore){bestScore=sc;best=f}
        }
        norm.recycle(); return best?.let{Pair(it,bestScore)}
    }

    private fun suggestDexCandidatesV2814(source:Bitmap, family:Pair<String,Double>?, limit:Int=3):List<DisplayCandidateV280>{
        // Inner portrait square only. This excludes the large ornamental frame/background around the icon.
        val portrait=normalizedCrop(source,0.184,0.292,0.352,0.366)
        val core=normalizeDexBitmapV2814(portrait,64); portrait.recycle()
        val scored=ArrayList<DisplayCandidateV280>()
        monsters.forEach { m ->
            val f=monsterIconFile(m.no); if(!f.isFile)return@forEach
            val display=BitmapFactory.decodeFile(f.absolutePath)?:return@forEach
            val dn=normalizeDexBitmapV2814(display,64)
            var score=compareDexBitmapV2814(core,dn)
            // Family is supporting evidence only, never a hard filter: the purpose of this screen is also
            // to discover incorrect family data in the database.
            if(family!=null && family.second>=0.70 && m.family==family.first) score=(score+0.035).coerceAtMost(1.0)
            scored.add(DisplayCandidateV280(m,score)); dn.recycle(); display.recycle()
        }
        core.recycle(); return scored.sortedByDescending{it.score}.take(limit)
    }

    private fun handleMonsterDexScreenshot(uri:Uri) {
        Toast.makeText(this,"図鑑スクリーンショットを解析しています…",Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val bmp=contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it)} ?: throw IllegalArgumentException("画像を開けません")
                if(bmp.height < bmp.width) throw IllegalArgumentException("縦向きの図鑑スクリーンショットを選択してください")
                val family=detectDexFamilyV2814(bmp)
                val candidates=suggestDexCandidatesV2814(bmp,family,3)
                bmp.recycle()
                runOnUiThread {
                    if(candidates.isEmpty()) {
                        AlertDialog.Builder(this).setTitle("候補を特定できませんでした").setMessage("表示用モンスターアイコンが不足している可能性があります。\n一覧・編集から手動で修正できます。").setPositiveButton("一覧・編集"){_,_->showMonsterDataEditor()}.setNegativeButton("閉じる",null).show()
                    } else {
                        val famName=family?.first
                        val labels=candidates.map{c->
                            val famMark=if(famName!=null && c.monster.family==famName)" / 系統一致" else if(famName!=null)" / 系統DB:${c.monster.family}" else ""
                            "No.${c.monster.no.toString().padStart(3,'0')} ${c.monster.name}　画像一致 ${(c.score*100).toInt()}%$famMark"
                        }.toTypedArray()
                        var selected=0
                        val famTitle=family?.let{" / 系統候補 ${it.first} ${(it.second*100).toInt()}%"} ?: ""
                        AlertDialog.Builder(this).setTitle("図鑑読み取り候補$famTitle")
                            .setSingleChoiceItems(labels,0){_,which->selected=which}
                            .setNegativeButton("キャンセル",null)
                            .setPositiveButton("確認・編集"){_,_->
                                Toast.makeText(this,"図鑑専用ROIで認識しました。ランク・サイズはゲーム画面と照合して確認してください",Toast.LENGTH_LONG).show()
                                editMonsterDataDialog(candidates[selected].monster.no,family?.first,true)
                            }.show()
                    }
                }
            } catch(t:Throwable) { runOnUiThread { AlertDialog.Builder(this).setTitle("図鑑読み取りに失敗しました").setMessage(t.message?:t::class.java.simpleName).setPositiveButton("OK",null).show() } }
        }.start()
    }

    // ---------------- v2.8.26 habitat planner ----------------

    private data class HabitatSummaryV2826(
        val name: String,
        val group: String,
        val monsters: List<Monster>,
        val ownedKinds: Int,
        val unownedKinds: Int,
        val wantedKinds: Int,
        val wantedTotal: Int,
        val unownedWantedKinds: Int
    )

    private fun habitatSummariesV2826(): List<HabitatSummaryV2826> {
        val byHabitat = LinkedHashMap<String, MutableList<Monster>>()
        monsters.sortedBy { it.no }.forEach { m ->
            monsterHabitats(m.no).forEach { h ->
                byHabitat.getOrPut(h) { mutableListOf() }.add(m)
            }
        }
        return byHabitat.map { (name, list) ->
            val unique = list.distinctBy { it.no }
            HabitatSummaryV2826(
                name = name,
                group = habitatGroupV2826(name),
                monsters = unique,
                ownedKinds = unique.count { owned(it) > 0 },
                unownedKinds = unique.count { owned(it) == 0 },
                wantedKinds = unique.count { wanted(it.no) > 0 },
                wantedTotal = unique.sumOf { wanted(it.no) },
                unownedWantedKinds = unique.count { owned(it) == 0 && wanted(it.no) > 0 }
            )
        }
    }

    private fun showHabitatPlannerPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(5))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(0))

        root.addView(TextView(this).apply {
            text = "生息地攻略"
            textSize = 20f
            setTextColor(textMain)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "進行順で場所を確認するか、現在の所持・★ほしい状況から次に狙う入手先を決められます。たまごは色ごとに集計します。"
            textSize = 11.5f
            setTextColor(textSub)
            setPadding(0, dp(2), 0, dp(5))
        })

        val sort = makeSpinner(arrayOf(
            "表示: 進行順",
            "おすすめ: 未所持かつ★ほしい",
            "おすすめ: ★ほしい総数",
            "おすすめ: 未所持種類"
        ))
        sort.setSelection(habitatPlannerSortMode.coerceIn(0, 3))
        root.addView(sort, LinearLayout.LayoutParams(-1, dp(42)))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        lateinit var render: () -> Unit

        fun addGroupHeader(label: String) {
            content.addView(TextView(this).apply {
                text = label
                textSize = 13.5f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(10), dp(7), dp(10), dp(7))
                background = roundedBg(Color.rgb(69, 76, 84), 8)
            }, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(7)
                bottomMargin = dp(2)
            })
        }

        fun addHabitatCard(indexLabel: String?, h: HabitatSummaryV2826, showGroupPath: Boolean) {
            val expanded = expandedHabitats.contains(h.name)
            val outer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(2), dp(4), dp(2), dp(4))
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    val priority = h.unownedWantedKinds > 0
                    setColor(if (priority) Color.rgb(255, 249, 225) else Color.WHITE)
                    cornerRadius = dp(12).toFloat()
                    if (priority) setStroke(dp(2), Color.rgb(235, 177, 45))
                }
                elevation = dp(1).toFloat()
            }

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            titleBox.addView(TextView(this).apply {
                text = (indexLabel?.let { "$it " } ?: "") + h.name
                textSize = 15.5f
                setTextColor(textMain)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            if (showGroupPath) {
                titleBox.addView(TextView(this).apply {
                    text = h.group
                    textSize = 10.5f
                    setTextColor(textSub)
                })
            }
            header.addView(titleBox, LinearLayout.LayoutParams(0, dp(if (showGroupPath) 45 else 35), 1f))
            if (h.unownedWantedKinds > 0) {
                header.addView(TextView(this).apply {
                    text = "優先 ${h.unownedWantedKinds}"
                    textSize = 10.5f
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(166, 104, 0))
                    background = roundedBg(Color.rgb(255, 236, 170), 8)
                }, LinearLayout.LayoutParams(dp(66), dp(28)).apply { marginEnd = dp(4) })
            }
            header.addView(TextView(this).apply {
                text = if (expanded) "▲" else "▼"
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(textSub)
            }, LinearLayout.LayoutParams(dp(32), dp(34)))
            card.addView(header)

            card.addView(TextView(this).apply {
                text = "対象 ${h.monsters.size}種　所持 ${h.ownedKinds}/${h.monsters.size}　未所持 ${h.unownedKinds}"
                textSize = 11.5f
                setTextColor(textSub)
                setPadding(dp(2), 0, dp(2), dp(2))
            })
            card.addView(TextView(this).apply {
                text = "★ほしい ${h.wantedKinds}種 / ${h.wantedTotal}体　　未所持かつ★ほしい ${h.unownedWantedKinds}種"
                textSize = 11.5f
                setTextColor(if (h.unownedWantedKinds > 0) Color.rgb(166, 104, 0) else textSub)
                setPadding(dp(2), 0, dp(2), dp(3))
            })

            if (expanded) {
                card.addView(View(this).apply { setBackgroundColor(divider) },
                    LinearLayout.LayoutParams(-1, dp(1)).apply {
                        topMargin = dp(4)
                        bottomMargin = dp(4)
                    })
                h.monsters.sortedWith(
                    compareByDescending<Monster> { owned(it) == 0 && wanted(it.no) > 0 }
                        .thenByDescending { wanted(it.no) }
                        .thenBy { it.no }
                ).forEach { m ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(3), dp(2), dp(3), dp(2))
                        isClickable = true
                        background = roundedBg(
                            if (owned(m) > 0) ownedCardBg
                            else if (wanted(m.no) > 0) Color.rgb(255, 249, 225)
                            else Color.rgb(248, 249, 251), 7
                        )
                        setOnClickListener { showManagementPage(m.no, 2) }
                    }
                    row.addView(TextView(this).apply {
                        text = String.format("No.%03d  %s", m.no, m.name)
                        textSize = 12f
                        setTextColor(textMain)
                    }, LinearLayout.LayoutParams(0, dp(35), 1f))
                    row.addView(TextView(this).apply {
                        text = "所持${owned(m)}"
                        textSize = 11f
                        gravity = Gravity.CENTER
                        setTextColor(if (owned(m) > 0) Color.rgb(35, 105, 210) else textSub)
                    }, LinearLayout.LayoutParams(dp(54), dp(32)))
                    row.addView(TextView(this).apply {
                        text = "★${wanted(m.no)}"
                        textSize = 11f
                        gravity = Gravity.CENTER
                        setTextColor(Color.rgb(166, 104, 0))
                    }, LinearLayout.LayoutParams(dp(42), dp(32)))
                    card.addView(row, LinearLayout.LayoutParams(-1, dp(39)).apply { topMargin = dp(2) })
                }
            }

            card.setOnClickListener {
                if (expandedHabitats.contains(h.name)) expandedHabitats.remove(h.name)
                else expandedHabitats.add(h.name)
                render()
            }
            outer.addView(card)
            content.addView(outer)
        }

        render = {
            content.removeAllViews()
            val base = habitatSummariesV2826()
            val useful = base.count { it.unownedWantedKinds > 0 }
            content.addView(TextView(this).apply {
                text = "入手先 ${base.size}件 / ★ほしい未所持がいる入手先 ${useful}件"
                textSize = 12f
                setTextColor(textSub)
                setPadding(dp(3), dp(2), dp(3), dp(5))
            })

            if (habitatPlannerSortMode == 0) {
                val groupOrder = listOf(
                    "旅の扉の間 B1F", "旅の扉の間 B2F", "星空の闘技場",
                    "寄り道（クリア前）", "寄り道（クリア後）", "黄金郷", "たまご", "その他入手先"
                )
                groupOrder.forEach { group ->
                    val items = base.filter { it.group == group }.sortedWith(
                        compareBy<HabitatSummaryV2826> { habitatProgressKeyV2826(it.name).second }.thenBy { it.name }
                    )
                    if (items.isNotEmpty()) {
                        addGroupHeader(group)
                        items.forEach { h -> addHabitatCard(null, h, false) }
                    }
                }
            } else {
                val ordered = when (habitatPlannerSortMode) {
                    2 -> base.sortedWith(compareByDescending<HabitatSummaryV2826> { it.wantedTotal }
                        .thenByDescending { it.unownedWantedKinds }.thenBy { habitatProgressKeyV2826(it.name).first }
                        .thenBy { habitatProgressKeyV2826(it.name).second }.thenBy { it.name })
                    3 -> base.sortedWith(compareByDescending<HabitatSummaryV2826> { it.unownedKinds }
                        .thenByDescending { it.unownedWantedKinds }.thenBy { habitatProgressKeyV2826(it.name).first }
                        .thenBy { habitatProgressKeyV2826(it.name).second }.thenBy { it.name })
                    else -> base.sortedWith(compareByDescending<HabitatSummaryV2826> { it.unownedWantedKinds }
                        .thenByDescending { it.wantedTotal }.thenByDescending { it.unownedKinds }
                        .thenBy { habitatProgressKeyV2826(it.name).first }
                        .thenBy { habitatProgressKeyV2826(it.name).second }.thenBy { it.name })
                }
                ordered.forEachIndexed { index, h -> addHabitatCard("${index + 1}.", h, true) }
            }
        }

        sort.onItemSelectedListener = filterListener {
            habitatPlannerSortMode = sort.selectedItemPosition
            render()
        }
        render()
    }

    // ---------------- Settings / trial import ----------------

    // ---------------- v2.8.21 Altema baseline data import (parser corrected) ----------------
    private data class AltemaBaselineV2820(val habitat:String,val skill:String,val traits:List<String>,val weapons:List<String>)

    private fun parseAltemaMonsterLinksV2820(html:String):Map<Int,String> {
        val result=HashMap<Int,String>(); val byName=monsters.associateBy{it.name}
        Regex("(?is)<a\\b([^>]*)>(.*?)</a>").findAll(html).forEach { m ->
            val attrs=m.groupValues[1]; val body=m.groupValues[2]; val href=tagAttribute("<a $attrs>","href") ?: return@forEach
            if(!href.contains("/terrysp/monster/")) return@forEach
            val text=stripHtml(body); val mon=byName[text] ?: return@forEach
            val url=when { href.startsWith("http")->href; href.startsWith("/")->"https://altema.jp$href"; else->"https://altema.jp/terrysp/$href" }
            result.putIfAbsent(mon.no,url)
        }
        return result
    }

    private fun tableRowsV2820(html:String):List<List<String>> = Regex("(?is)<tr\\b[^>]*>(.*?)</tr>").findAll(html).mapNotNull { tr ->
        val cells=Regex("(?is)<t[dh]\\b[^>]*>(.*?)</t[dh]>").findAll(tr.groupValues[1]).map{stripHtml(it.groupValues[1])}.filter{it.isNotBlank()}.toList()
        cells.takeIf{it.isNotEmpty()}
    }.toList()

    // v2.8.21: Locate sections by actual H2/H3 headings instead of plain text.
    // Plain-text search could match the table of contents and accidentally include unrelated tables.
    private data class HtmlHeadingV2821(val level:Int,val label:String,val start:Int,val end:Int)

    private fun headingsV2821(html:String):List<HtmlHeadingV2821> =
        Regex("(?is)<h([23])\\b[^>]*>(.*?)</h\\1>").findAll(html).mapNotNull { m ->
            val level=m.groupValues[1].toIntOrNull() ?: return@mapNotNull null
            val label=stripHtml(m.groupValues[2]).replace(Regex("\\s+")," ").trim()
            HtmlHeadingV2821(level,label,m.range.first,m.range.last+1)
        }.toList()

    private fun headingSectionV2821(html:String,level:Int,label:String):String {
        val hs=headingsV2821(html)
        val idx=hs.indexOfFirst { it.level==level && it.label==label }
        if(idx<0)return ""
        val h=hs[idx]
        val next=hs.drop(idx+1).firstOrNull { it.level<=level }
        return html.substring(h.end,next?.start ?: html.length)
    }

    private fun cleanTraitV2820(v:String):String = v.replace(Regex("\\s*\\(\\+?\\d+\\)\\s*"),"").replace("~","〜").replace("～","〜").replace(Regex("\\s+")," ").trim()

    private fun parseAltemaBaselineV2820(html:String):AltemaBaselineV2820 {
        val all=tableRowsV2820(html)
        fun valueAfter(label:String):String = all.firstNotNullOfOrNull { row ->
            val i=row.indexOfFirst{it==label}; if(i>=0 && i+1<row.size) row[i+1] else null
        }.orEmpty()
        val weapons=valueAfter("装備可能武器").split('・','、',',').map{it.trim()}.filter{it.isNotBlank()}
        val habitat=valueAfter("出現場所").replace("出現場所","").trim()

        // Only the table directly below H3「固有スキル」.
        // Do not include H3「固有スキルで習得する特技」.
        val skillSec=headingSectionV2821(html,3,"固有スキル")
        val skillRows=tableRowsV2820(skillSec)
        val skill=skillRows.firstOrNull { row ->
            row.size>=2 && row[0] != "スキル" && !row[0].contains("主な取得")
        }?.getOrNull(0).orEmpty().trim()

        // Only the 名称 column of the H3「特性」 table.
        val traitSec=headingSectionV2821(html,3,"特性")
        val traitRows=tableRowsV2820(traitSec)
        val traits=traitRows.mapNotNull { row ->
            if(row.size<2)return@mapNotNull null
            val name=cleanTraitV2820(row[0])
            if(name in listOf("名称","特性") || name.length>30)return@mapNotNull null
            name.takeIf{it.isNotBlank()}
        }.distinct().take(7)
        return AltemaBaselineV2820(habitat,skill,traits,weapons)
    }

    private fun confirmAltemaBaselineImportV2820() {
        AlertDialog.Builder(this).setTitle("基礎データ取得（アルテマ）")
            .setMessage("659体の個別ページを順番に確認し、生息地・固有スキル・特性・装備可能武器を『基礎データ（未確認）』として保存します。\\n\\n手動修正データは上書きしません。通信量と時間がかかるため、安定した通信環境で実行してください。途中で中止できます。")
            .setNegativeButton("キャンセル",null).setPositiveButton("取得開始"){_,_->startAltemaBaselineImportV2820()}.show()
    }

    private fun startAltemaBaselineImportV2820() {
        val cancelled=java.util.concurrent.atomic.AtomicBoolean(false)
        val status=TextView(this).apply{text="図鑑ページを確認しています…";textSize=13f;setTextColor(textMain);setPadding(dp(18),dp(10),dp(18),dp(8))}
        val progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=monsters.size;progress=0}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(status);addView(progress,LinearLayout.LayoutParams(-1,dp(20)).apply{marginStart=dp(18);marginEnd=dp(18);bottomMargin=dp(10)})}
        val dialog=AlertDialog.Builder(this).setTitle("基礎データ取得中").setView(box).setNegativeButton("中止"){_,_->cancelled.set(true)}.setCancelable(false).create();dialog.show()
        Thread {
            var success=0;var failed=0;var skipped=0
            val failedItems=mutableListOf<String>()
            val skills=masterListV2820("skills").toMutableSet(); val traits=masterListV2820("traits").toMutableSet(); val locations=masterListV2820("locations").toMutableSet(); val weapons=masterListV2820("weapons").toMutableSet()
            try {
                val indexHtml=fetchText(altemaZukanUrl); val links=parseAltemaMonsterLinksV2820(indexHtml)
                monsters.forEachIndexed { i,m ->
                    if(cancelled.get())return@forEachIndexed
                    val url=links[m.no] ?: if(m.no==80) "https://altema.jp/terrysp/monster/430" else null
                    if(url==null){
                        failed++
                        failedItems.add("No.${m.no.toString().padStart(3,'0')} ${m.name}：個別ページURLを取得できませんでした")
                    } else try {
                        val d=parseAltemaBaselineV2820(fetchText(url)); val e=pref.edit()
                        // Replace the v2.8.20 baseline values after a successful page fetch.
                        e.remove("base_habitat_${m.no}").remove("base_skill_${m.no}").remove("base_traits_${m.no}").remove("base_weapons_${m.no}")
                        fun put(key:String,v:String){if(v.isNotBlank())e.putString("base_${key}_${m.no}",v)}
                        put("habitat",d.habitat);put("skill",d.skill)
                        if(d.traits.isNotEmpty())e.putString("base_traits_${m.no}",JSONArray(d.traits).toString())
                        if(d.weapons.isNotEmpty())e.putString("base_weapons_${m.no}",JSONArray(d.weapons).toString())
                        e.apply(); if(d.habitat.isBlank()&&d.skill.isBlank()&&d.traits.isEmpty()&&d.weapons.isEmpty())skipped++ else success++
                        if(d.skill.isNotBlank())skills.add(d.skill);traits.addAll(d.traits);weapons.addAll(d.weapons)
                        d.habitat.split('、',',').map{it.trim()}.filter{it.isNotBlank()}.forEach{locations.add(it)}
                    } catch(t:Throwable){
                        failed++
                        val reason=(t.message?:t::class.java.simpleName).replace('\n',' ').take(80)
                        failedItems.add("No.${m.no.toString().padStart(3,'0')} ${m.name}：$reason")
                    }
                    if(i%2==0 || i==monsters.lastIndex)runOnUiThread{progress.progress=i+1;status.text="${i+1} / ${monsters.size}　取得 $success　失敗 $failed"}
                    try{Thread.sleep(120)}catch(_:Throwable){}
                }
                pref.edit().putString("master_skills",JSONArray(skills.sorted()).toString()).putString("master_traits",JSONArray(traits.sorted()).toString()).putString("master_locations",JSONArray(locations.sorted()).toString()).putString("master_weapons",JSONArray(weapons.sorted()).toString()).putLong("base_altema_updated",System.currentTimeMillis()).apply()
                runOnUiThread{
                    if(dialog.isShowing)dialog.dismiss(); if(::monsterAdapter.isInitialized)monsterAdapter.notifyDataSetChanged()
                    val failText=if(failedItems.isEmpty()) "\n失敗したモンスター: なし" else {
                        val shown=failedItems.take(30).joinToString("\n")
                        val more=if(failedItems.size>30) "\n…ほか ${failedItems.size-30}件" else ""
                        "\n\n【失敗したモンスター】\n$shown$more"
                    }
                    AlertDialog.Builder(this).setTitle(if(cancelled.get())"基礎データ取得を中止しました" else "基礎データ取得完了")
                        .setMessage("取得: $success / ${monsters.size}\n失敗: $failed\nデータなし: $skipped$failText\n\n取得値は基礎データ（未確認）です。既存の手動修正値がある項目は手動修正値を優先表示します。\nOCR辞書にもスキル・特性・生息地を反映しました。")
                        .setPositiveButton("OK",null).show()
                }
            } catch(t:Throwable){runOnUiThread{if(dialog.isShowing)dialog.dismiss();AlertDialog.Builder(this).setTitle("基礎データ取得に失敗しました").setMessage(t.message?:t::class.java.simpleName).setPositiveButton("OK",null).show()}}
        }.start()
    }

    private fun showSettingsPage() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(2))
        root.addView(TextView(this).apply {
            text = "設定"
            textSize = 20f
            setTextColor(textMain)
            setPadding(0, dp(5), 0, dp(3))
        })
        root.addView(TextView(this).apply {
            text = "画像・所有状態・バックアップを項目別に管理できます。"
            textSize = 12f
            setTextColor(textSub)
            setPadding(0, 0, 0, dp(9))
        })

        fun sectionTitle(textValue: String) = TextView(this).apply {
            text = textValue
            textSize = 15f
            setTextColor(textMain)
            setPadding(dp(3), dp(11), 0, dp(5))
        }
        fun actionButton(textValue: String, color: Int, action: () -> Unit) = Button(this).apply {
            text = textValue
            textSize = 12f
            styleButton(this, color)
            setOnClickListener { action() }
        }
        fun row(leftText: String, leftColor: Int, leftAction: () -> Unit,
                rightText: String, rightColor: Int, rightAction: () -> Unit): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(actionButton(leftText, leftColor, leftAction), LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(3) })
                addView(actionButton(rightText, rightColor, rightAction), LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(3) })
            }
        fun note(textValue: String) = TextView(this).apply {
            text = textValue
            textSize = 11f
            setTextColor(textSub)
            setPadding(dp(5), dp(3), dp(5), dp(5))
        }

        root.addView(sectionTitle("モンスターアイコン"))
        root.addView(row(
            "画像取得（アルテマ）", breedingColor, { confirmAltemaImageDownload() },
            "リセット", Color.rgb(120,120,120), { confirmResetMonsterIcons() }
        ))
        root.addView(row(
            "バックアップ（zip）", Color.rgb(69,90,100), { exportMonsterImagesZip() },
            "リストア（zip）", Color.rgb(0,105,92), { startMonsterImagesZipImport() }
        ).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(note("表示用のモンスター画像だけを操作します。リセットしても所有状態・メモ・判断用アイコンには影響しません。"))

        root.addView(sectionTitle("モンスターデータ"))
        root.addView(row(
            "一覧・編集", Color.rgb(69,90,100), { showMonsterDataEditor() },
            "図鑑スクリーンショット読取（試験）", Color.rgb(88,86,214), { startMonsterDexScreenshotImport() }
        ))
        root.addView(actionButton("基礎データ取得（アルテマ）", Color.rgb(0,121,107)) { confirmAltemaBaselineImportV2820() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })
        root.addView(actionButton("図鑑OCR更新（実ゲーム → DB）", Color.rgb(0,105,92)) { startMonsterDexOcrUpdateV2822() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })
        root.addView(actionButton("図鑑OCR検証（DB比較）", Color.rgb(94,53,177)) { startMonsterDexOcrValidation() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        root.addView(row(
            "修正データバックアップ（json）", Color.rgb(69,90,100), { startMonsterDataBackup() },
            "修正データリストア（json）", Color.rgb(0,105,92), { startMonsterDataRestore() }
        ).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(actionButton("修正データをすべてリセット", Color.rgb(120,120,120)) { confirmResetAllMonsterData() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        root.addView(note("v2.8.26では生息地攻略を進行順/おすすめ順に対応。旅の扉B1F→B2F→星空の闘技場→寄り道（クリア前/後）→黄金郷→たまごの順に整理し、たまご（金・虹）のような表記は「たまご金」「たまご虹」へ攻略用に展開して色ごとに集計します。"))

        root.addView(sectionTitle("所有状態"))
        root.addView(actionButton("一括取得", Color.rgb(0,121,107)) { startIntegratedScreenRecordingV278() }, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(note("フローティングパネル → テリワンSPへ切替 →［録画開始］→ ページ送り →［録画停止］→ 自動解析の順で取得します。"))
        root.addView(actionButton("所有状態リセット", Color.rgb(120,120,120)) { confirmResetOwnershipState() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        root.addView(row(
            "所有状態バックアップ（zip）", Color.rgb(69,90,100), { startOwnershipBackup() },
            "所有状態リストア（zip）", Color.rgb(0,105,92), { startOwnershipRestore() }
        ).apply { setPadding(0, dp(6), 0, 0) })

        val recognition = recognitionStats()
        root.addView(actionButton("判断用アイコンリセット", Color.rgb(120,120,120)) { confirmDeleteRecognitionIcons() }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(9) })
        root.addView(row(
            "判断用アイコンバックアップ（zip）", Color.rgb(69,90,100), { startRecognitionBackup() },
            "判断用アイコンリストア（zip）", Color.rgb(0,105,92), { startRecognitionRestore() }
        ).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(note("判断用アイコン: ${recognition.first}種類 / ${recognition.second}枚。所有状態バックアップは♂・♀・♂♀の所有数のみを対象にします。"))

        root.addView(sectionTitle("その他"))
        root.addView(actionButton("モンスターアイコン＆判断用アイコン一覧表示", Color.rgb(69,90,100)) { showIconStatusList() }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(note("No.ごとに表示用アイコンと判断用アイコンの登録状態・画像を並べて確認できます。"))

        root.addView(sectionTitle("完全バックアップ"))
        root.addView(row(
            "バックアップ（zip）", primary, { startFullBackup() },
            "リストア（zip）", Color.rgb(96,125,139), { startFullRestore() }
        ))
        root.addView(note("対象: 所有数 / ほしい数 / お気に入り / メモ / モンスターデータ修正 / 表示用モンスター画像 / 判断用アイコン。"))

        root.addView(sectionTitle("アプリ情報"))
        val appVersion = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "不明"
        } catch (_: Throwable) { "不明" }
        root.addView(TextView(this).apply {
            text = "ソフトウェアバージョン  v${appVersion}"
            textSize = 14f
            setTextColor(textMain)
            background = roundedBg(card, 10)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun confirmResetMonsterIcons() {
        val count = monsterIconDir().listFiles()?.count { it.isFile } ?: 0
        AlertDialog.Builder(this)
            .setTitle("モンスターアイコンをリセット")
            .setMessage("取得・登録済みの表示用モンスターアイコン ${count}件を削除します。\n\n所有状態・メモ・判断用アイコンには影響しません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("リセット") { _, _ ->
                try { monsterIconDir().listFiles()?.forEach { it.delete() } } catch (_: Throwable) { }
                if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                Toast.makeText(this, "モンスターアイコンをリセットしました", Toast.LENGTH_SHORT).show()
                showSettingsPage()
            }.show()
    }

    private fun confirmResetOwnershipState() {
        val ownedKinds = monsters.count { owned(it) > 0 }
        AlertDialog.Builder(this)
            .setTitle("所有状態をリセット")
            .setMessage("現在の所有状態（${ownedKinds}種類）について、♂・♀・♂♀の所有数をすべて0にします。\n\nメモ・お気に入り・各種アイコンには影響しません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("リセット") { _, _ ->
                val e = pref.edit()
                monsters.forEach { m ->
                    maleCounts[m.no] = 0; femaleCounts[m.no] = 0; bothCounts[m.no] = 0
                    e.putInt("m${m.no}", 0).putInt("f${m.no}", 0).putInt("b${m.no}", 0)
                }
                e.apply()
                if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                Toast.makeText(this, "所有状態をリセットしました", Toast.LENGTH_SHORT).show()
                showSettingsPage()
            }.show()
    }

    private fun ownershipStateJson(): String {
        val arr = JSONArray()
        monsters.forEach { m -> arr.put(JSONObject().apply {
            put("no", m.no); put("male", male(m.no)); put("female", female(m.no)); put("both", both(m.no))
        }) }
        return JSONObject().apply {
            put("format", "terrysp_ownership_v1")
            put("items", arr)
        }.toString()
    }

    private fun startOwnershipBackup() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/zip"; putExtra(Intent.EXTRA_TITLE, "TerrySP_ownership_state.zip")
        }, 1013)
    }

    private fun writeOwnershipBackup(uri: Uri) {
        contentResolver.openOutputStream(uri, "w")?.use { raw ->
            ZipOutputStream(raw.buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("manifest.txt")); zip.write("TERRYSP_OWNERSHIP_V1\n".toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("ownership.json")); zip.write(ownershipStateJson().toByteArray(StandardCharsets.UTF_8)); zip.closeEntry()
            }
        } ?: throw IllegalStateException("保存先を開けません")
        Toast.makeText(this, "所有状態バックアップを保存しました", Toast.LENGTH_SHORT).show()
    }

    private fun startOwnershipRestore() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/zip"; addCategory(Intent.CATEGORY_OPENABLE) }, 1014)
    }

    private fun restoreOwnershipBackup(uri: Uri) {
        var manifestOk = false; var json: String? = null
        contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw.buffered()).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    if (!e.isDirectory) {
                        val bytes = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192); var total = 0
                        while (true) { val n=zip.read(buf); if(n<=0) break; total += n; if(total>2*1024*1024) throw IllegalArgumentException("ZIPが大きすぎます"); bytes.write(buf,0,n) }
                        when (e.name) {
                            "manifest.txt" -> manifestOk = bytes.toString("UTF-8").contains("TERRYSP_OWNERSHIP_V1")
                            "ownership.json" -> json = bytes.toString("UTF-8")
                        }
                    }
                    zip.closeEntry()
                }
            }
        } ?: throw IllegalStateException("ZIPを開けません")
        if (!manifestOk || json == null) throw IllegalArgumentException("所有状態バックアップZIPではありません")
        val obj = JSONObject(json!!); if (obj.optString("format") != "terrysp_ownership_v1") throw IllegalArgumentException("所有状態バックアップの形式が不正です")
        val arr = obj.getJSONArray("items"); val edit = pref.edit()
        for (i in 0 until arr.length()) { val o=arr.getJSONObject(i); val no=o.optInt("no",-1); if(no !in 1..659) continue
            val m=o.optInt("male",0).coerceAtLeast(0); val f=o.optInt("female",0).coerceAtLeast(0); val b=o.optInt("both",0).coerceAtLeast(0)
            maleCounts[no]=m; femaleCounts[no]=f; bothCounts[no]=b; edit.putInt("m$no",m).putInt("f$no",f).putInt("b$no",b)
        }
        edit.apply(); if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
        Toast.makeText(this, "所有状態をリストアしました", Toast.LENGTH_SHORT).show(); showSettingsPage()
    }

    private fun startRecognitionBackup() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type="application/zip"; putExtra(Intent.EXTRA_TITLE,"TerrySP_recognition_icons.zip") }, 1015)
    }

    private fun writeRecognitionBackup(uri: Uri) {
        contentResolver.openOutputStream(uri, "w")?.use { raw -> ZipOutputStream(raw.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.txt")); zip.write("TERRYSP_RECOGNITION_ICONS_V1\n".toByteArray()); zip.closeEntry()
            recognitionIconDir().listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { d ->
                d.listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach { f -> addFileToZip(zip, f, "recognition_icons/${d.name}/${f.name}") }
            }
        } } ?: throw IllegalStateException("保存先を開けません")
        val st=recognitionStats(); Toast.makeText(this,"判断用アイコンを保存しました（${st.first}種類 / ${st.second}枚）",Toast.LENGTH_LONG).show()
    }

    private fun startRecognitionRestore() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/zip"; addCategory(Intent.CATEGORY_OPENABLE) },1016)
    }

    private fun restoreRecognitionBackup(uri: Uri) {
        val tmp=File(cacheDir,"recognition_restore_v282"); try{tmp.deleteRecursively()}catch(_:Throwable){}; tmp.mkdirs(); var manifestOk=false; var restored=0
        try {
            contentResolver.openInputStream(uri)?.use { raw -> ZipInputStream(raw.buffered()).use { zip ->
                while(true){ val e=zip.nextEntry?:break; val name=e.name
                    if(!e.isDirectory){
                        if(name=="manifest.txt"){
                            val bytes=java.io.ByteArrayOutputStream(); val buf=ByteArray(1024); var total=0
                            while(true){ val n=zip.read(buf); if(n<=0) break; total+=n; if(total>4096) throw IllegalArgumentException("manifestが大きすぎます"); bytes.write(buf,0,n) }
                            manifestOk=bytes.toString("UTF-8").contains("TERRYSP_RECOGNITION_ICONS_V1")
                        }
                        else if(Regex("^recognition_icons/\\d{3}/[A-Za-z0-9_.-]+$").matches(name)){
                            val out=File(tmp,name); out.parentFile?.mkdirs(); out.outputStream().use { dst -> zip.copyTo(dst,8192) }; if(BitmapFactory.decodeFile(out.absolutePath)!=null) restored++ else out.delete()
                        }
                    }; try{zip.closeEntry()}catch(_:Throwable){}
                }
            } } ?: throw IllegalStateException("ZIPを開けません")
            if(!manifestOk) throw IllegalArgumentException("判断用アイコンバックアップZIPではありません")
            val dst=recognitionIconDir(); File(tmp,"recognition_icons").listFiles()?.filter{it.isDirectory}?.forEach { d -> val dd=File(dst,d.name).apply{mkdirs()}; d.listFiles()?.forEach{it.copyTo(File(dd,it.name),overwrite=true)} }
            val st=recognitionStats(); Toast.makeText(this,"判断用アイコンをリストアしました（${st.first}種類 / ${st.second}枚）",Toast.LENGTH_LONG).show(); showSettingsPage()
        } finally { try{tmp.deleteRecursively()}catch(_:Throwable){} }
    }

    private fun showIconStatusList() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(16));setBackgroundColor(bg)}
        root.addView(TextView(this).apply{text="モンスターアイコン＆判断用アイコン";textSize=20f;setTextColor(textMain);setPadding(0,0,0,dp(8))})
        monsters.forEach { m ->
            val recDir=File(recognitionIconDir(),m.no.toString().padStart(3,'0')); val recFiles=recDir.listFiles()?.filter{it.isFile}?.sortedByDescending{it.lastModified()}.orEmpty()
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=roundedBg(card,10);setPadding(dp(8),dp(7),dp(8),dp(7))}
            row.addView(TextView(this).apply{text="No.${m.no.toString().padStart(3,'0')}\n${m.name}";textSize=11f;setTextColor(textMain)},LinearLayout.LayoutParams(0,-2,1f))
            fun iconBox(label:String,bmp:Bitmap?,status:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;addView(TextView(this@MainActivity).apply{text=label;textSize=9f;setTextColor(textSub)});addView(ImageView(this@MainActivity).apply{if(bmp!=null)setImageBitmap(bmp);scaleType=ImageView.ScaleType.CENTER_CROP;background=roundedBg(Color.rgb(235,238,241),6)},LinearLayout.LayoutParams(dp(46),dp(46)));addView(TextView(this@MainActivity).apply{text=status;textSize=9f;setTextColor(textSub)})}
            val disp=monsterIconFile(m.no).takeIf{it.isFile}?.let{BitmapFactory.decodeFile(it.absolutePath)}
            val rec=recFiles.firstOrNull()?.let{BitmapFactory.decodeFile(it.absolutePath)}
            row.addView(iconBox("表示用",disp,if(disp!=null)"登録済" else "未登録"),LinearLayout.LayoutParams(dp(76),-2))
            row.addView(iconBox("判断用",rec,if(recFiles.isNotEmpty())"${recFiles.size}枚" else "未登録"),LinearLayout.LayoutParams(dp(76),-2))
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
        }
        AlertDialog.Builder(this).setView(ScrollView(this).apply{addView(root)}).setNegativeButton("閉じる",null).show()
    }

    private fun confirmDeleteRecognitionIcons() {
        val stats = recognitionStats()
        AlertDialog.Builder(this)
            .setTitle("判断用アイコンを削除")
            .setMessage("登録済みの判断用アイコン ${stats.first}種類 / ${stats.second}枚をすべて削除します。\n\n表示用のモンスター画像や所有数には影響しません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("削除") { _, _ ->
                try { recognitionIconDir().deleteRecursively() } catch (_: Throwable) { }
                recognitionIconDir().mkdirs()
                Toast.makeText(this, "判断用アイコンを削除しました", Toast.LENGTH_SHORT).show()
                showSettingsPage()
            }.show()
    }

    private fun startMonsterImagesZipImport() {
        AlertDialog.Builder(this)
            .setTitle("モンスター画像ZIPを読み込み")
            .setMessage("このアプリで書き出した TerrySP_monster_icons.zip を選択してください。\n\nZIP内の図鑑No.を読み取り、端末内のモンスター画像へ登録します。同じ図鑑No.の既存画像は上書きされます。所有数・メモ・お気に入りには影響しません。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("ZIPを選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/zip"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 1006)
            }
            .show()
    }

    private fun importMonsterImagesZip(uri: Uri) {
        Toast.makeText(this, "画像ZIPを読み込んでいます…", Toast.LENGTH_SHORT).show()
        Thread {
            var imported = 0
            var skipped = 0
            var failed = 0
            val importedNos = HashSet<Int>()
            try {
                val iconDir = File(filesDir, "monster_icons").apply { mkdirs() }
                contentResolver.openInputStream(uri)?.use { raw ->
                    ZipInputStream(raw.buffered()).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            if (!entry.isDirectory) {
                                val fileName = entry.name.substringAfterLast('/')
                                val no = parseMonsterNoFromZipName(fileName)
                                if (no == null || no !in 1..659 || no in importedNos) {
                                    skipped++
                                } else {
                                    try {
                                        // Exported icons are small PNGs. Cap each inflated entry to 4 MiB.
                                        val bytes = java.io.ByteArrayOutputStream()
                                        val buf = ByteArray(8192)
                                        var total = 0
                                        while (true) {
                                            val n = zip.read(buf)
                                            if (n <= 0) break
                                            total += n
                                            if (total > 4 * 1024 * 1024) throw IllegalArgumentException("画像が大きすぎます")
                                            bytes.write(buf, 0, n)
                                        }
                                        val bitmap = BitmapFactory.decodeByteArray(bytes.toByteArray(), 0, bytes.size())
                                        if (bitmap == null || bitmap.width < 8 || bitmap.height < 8) {
                                            failed++
                                        } else {
                                            val outFile = File(iconDir, "monster_${no.toString().padStart(3,'0')}.img")
                                            outFile.outputStream().buffered().use { out ->
                                                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                                                    throw IllegalStateException("画像保存に失敗しました")
                                                }
                                            }
                                            importedNos.add(no)
                                            imported++
                                        }
                                    } catch (_: Throwable) {
                                        failed++
                                    }
                                }
                            }
                            try { zip.closeEntry() } catch (_: Throwable) { }
                        }
                    }
                } ?: throw IllegalStateException("ZIPを開けませんでした")
                runOnUiThread {
                    if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPを読み込みました")
                        .setMessage("登録: ${imported}体\nスキップ: ${skipped}件\n失敗: ${failed}件\n\n同じ図鑑No.の画像は上書きされています。")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("画像ZIPの読み込みに失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }.start()
    }

    private fun parseMonsterNoFromZipName(fileName: String): Int? {
        // Current export format: 001_スライム.png
        Regex("^(\\d{1,3})(?:[_\\-. ]|$)").find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        // Also accept the app's internal-style name if a user has archived it manually.
        Regex("^monster[_-]?(\\d{1,3})", RegexOption.IGNORE_CASE).find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        return null
    }

    private fun recognitionIconDir(): File = File(filesDir, "recognition_icons_v273").apply { mkdirs() }

    private fun recognitionStats(): Pair<Int, Int> {
        val dir = recognitionIconDir()
        var types = 0
        var samples = 0
        monsters.forEach { m ->
            val md = File(dir, m.no.toString().padStart(3, '0'))
            val count = md.listFiles()?.count { it.isFile } ?: 0
            if (count > 0) types++
            samples += count
        }
        return Pair(types, samples)
    }

    private fun startIntegratedScreenRecordingV278() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1011)
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("フローティングパネルの許可")
                .setMessage("録画開始/停止ボタンをテリワンSPの画面上に表示するため、『他のアプリの上に重ねて表示』を1度だけ許可してください。\n\n許可後、この画面へ戻ると一括取得の準備を続けます。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("設定を開く") { _, _ ->
                    try {
                        startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 1012)
                    } catch (t: Throwable) {
                        AlertDialog.Builder(this).setTitle("設定を開けません")
                            .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                    }
                }.show()
            return
        }
        val (types, samples) = recognitionStats()
        AlertDialog.Builder(this)
            .setTitle("動画から所有状態取得 v2.8.0")
            .setMessage("先にフローティングパネルだけを表示します。録画はまだ始まりません。\n\n" +
                "1. ［パネルを表示］を押す\n" +
                "2. 自分でテリワンSPへ切り替える\n" +
                "3. 預かり所1ページ目で、パネルの［録画開始］を押す\n" +
                "4. Androidの録画許可画面で許可する\n" +
                "5. ▶でページを送り、各ページを約1秒表示する\n" +
                "6. 最終ページでパネルの［録画停止］を押す\n\n" +
                "停止後はパネルが消え、管理アプリへ戻って自動解析します。パネルはドラッグで移動できます。\n\n" +
                "判断用アイコン: ${types}種類 / ${samples}枚")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("パネルを表示") { _, _ ->
                try {
                    startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_SHOW })
                    Toast.makeText(this, "フローティングパネルを表示しました。テリワンSPへ切り替えてください", Toast.LENGTH_LONG).show()
                } catch (t: Throwable) {
                    AlertDialog.Builder(this).setTitle("フローティングパネルを表示できません")
                        .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                }
            }.show()
    }

    private fun requestScreenCaptureFromOverlayV280() {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val captureIntent = if (Build.VERSION.SDK_INT >= 34) {
                manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
            } else manager.createScreenCaptureIntent()
            startActivityForResult(captureIntent, 1010)
        } catch (t: Throwable) {
            try { startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_SET_WAITING }) } catch (_: Throwable) { }
            AlertDialog.Builder(this).setTitle("画面録画を開始できません")
                .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
        }
    }

    private fun beginScreenRecordServiceV277(resultCode: Int, resultData: Intent) {
        val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
            action = ScreenRecordService.ACTION_START
            putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenRecordService.EXTRA_RESULT_DATA, resultData)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            try { startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_SET_RECORDING }) } catch (_: Throwable) { }
            Toast.makeText(this, "● 録画開始。フローティングパネルから停止できます", Toast.LENGTH_SHORT).show()
            // Reveal the app that was used immediately before this manager (normally TerrySP).
            // If TerrySP was not behind this app, the user can simply switch to it manually.
            window.decorView.postDelayed({
                try { moveTaskToBack(true) } catch (_: Throwable) { }
            }, 350L)
        } catch (t: Throwable) {
            AlertDialog.Builder(this)
                .setTitle("画面録画を開始できません")
                .setMessage(t.message ?: t::class.java.simpleName)
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun consumeRecordedVideoV277() {
        val key = "pending_recorded_video_v277"
        val path = pref.getString(key, null) ?: return
        pref.edit().remove(key).apply()
        val file = File(path)
        if (!file.isFile || file.length() < 16_384L) {
            Toast.makeText(this, "録画ファイルを確認できませんでした", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "録画した預かり所を自動解析します", Toast.LENGTH_SHORT).show()
        handleTrialVideo(Uri.fromFile(file))
    }

    private fun startTrialOwnershipVideoImport() {
        val (types, samples) = recognitionStats()
        AlertDialog.Builder(this)
            .setTitle("保存済み動画から所有状態取得 v2.7.8")
            .setMessage("テリワンSPの配合画面で『預かり所』を表示し、画面録画しながら ▶ でページを送った動画を選択します。\n\n" +
                "おすすめの録画方法:\n" +
                "・1ページ目を約1秒表示してから録画開始\n" +
                "・▶ を1回押すごとに次ページを約1秒表示\n" +
                "・最終ページも約1秒表示してから録画停止\n\n" +
                "アプリは動画全体を画像認識せず、固定5×3領域の変化を監視して『ページが静止した場面』だけを抽出します。抽出後はv2.7.5で安定した静止画認識をそのまま使用します。\n\n" +
                "判断用アイコン: ${types}種類 / ${samples}枚")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("動画を選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "video/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 1009)
            }
            .show()
    }

    private data class VideoPageCandidateV276(
        val bitmap: Bitmap,
        val fingerprint: FloatArray
    )

    private fun videoFrameFingerprintV276(bitmap: Bitmap): FloatArray {
        // Sample only the stable 5x3 monster-list area.  UI outside this region (buttons, clock,
        // recording overlays) is intentionally ignored.  Each slot contributes a 3x3 RGB sample.
        val xCenters = doubleArrayOf(0.126, 0.312, 0.498, 0.684, 0.870)
        val yCenters = doubleArrayOf(0.209, 0.283, 0.357)
        val offsets = doubleArrayOf(-0.030, 0.0, 0.030)
        val out = FloatArray(5 * 3 * 3 * 3 * 3)
        var i = 0
        for (yn in yCenters) for (xn in xCenters) {
            for (oy in offsets) for (ox in offsets) {
                val x = ((xn + ox) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                val y = ((yn + oy) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                val c = bitmap.getPixel(x, y)
                out[i++] = Color.red(c) / 255f
                out[i++] = Color.green(c) / 255f
                out[i++] = Color.blue(c) / 255f
            }
        }
        return out
    }

    private fun fingerprintDistanceV276(a: FloatArray, b: FloatArray): Double {
        if (a.size != b.size || a.isEmpty()) return 1.0
        var sum = 0.0
        for (i in a.indices) sum += kotlin.math.abs(a[i] - b[i]).toDouble()
        return sum / a.size.toDouble()
    }

    private fun rotateVideoFrameV276(src: Bitmap, rotation: Int): Bitmap {
        if (rotation % 360 == 0) return src
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
        if (rotated !== src) try { src.recycle() } catch (_: Throwable) { }
        return rotated
    }

    private fun isLikelyTerryWarehouseFrameV279(bitmap: Bitmap): Boolean {
        // v2.7.9: determine the warehouse screen from FIXED UI, not from the number of monsters.
        // The v2.7.8 filter looked for structure inside the 5x3 monster grid. That works on full
        // pages but can reject a sparse final page (for example only three monsters).  Here the
        // monster slots are deliberately ignored. We instead verify the brown warehouse board and
        // several fixed controls around it: title/sort area, page controls and parent-panel border.
        if (bitmap.width < 240 || bitmap.height < bitmap.width) return false

        fun rgb(nx: Double, ny: Double): Triple<Int, Int, Int> {
            val x = (nx * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
            val y = (ny * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
            val c = bitmap.getPixel(x, y)
            return Triple(Color.red(c), Color.green(c), Color.blue(c))
        }
        fun lum(nx: Double, ny: Double): Double {
            val (r, g, b) = rgb(nx, ny)
            return (r * 0.299 + g * 0.587 + b * 0.114) / 255.0
        }
        fun localContrast(nx: Double, ny: Double, dx: Double, dy: Double): Double {
            val values = doubleArrayOf(
                lum(nx, ny), lum(nx - dx, ny), lum(nx + dx, ny),
                lum(nx, ny - dy), lum(nx, ny + dy)
            )
            return (values.maxOrNull() ?: 0.0) - (values.minOrNull() ?: 0.0)
        }
        fun warmBrown(nx: Double, ny: Double): Boolean {
            val (r, g, b) = rgb(nx, ny)
            // Gap/background wood on this screen is consistently warm: R > G > B and fairly dark.
            return r in 38..145 && g in 25..105 && b in 12..78 && r > g + 8 && g > b + 6
        }

        // Sample ONLY the gaps between icon columns/rows. These remain wood even when final-page
        // monster slots are empty, so monster count cannot make this test fail.
        val woodXs = doubleArrayOf(0.21, 0.40, 0.59, 0.78)
        val woodYs = doubleArrayOf(0.24, 0.31, 0.38)
        var woodHits = 0
        for (y in woodYs) for (x in woodXs) if (warmBrown(x, y)) woodHits++
        if (woodHits < 7) return false

        // Fixed UI anchor points. We require several strong local edges at positions that do not
        // depend on which monsters are present.
        val anchors = arrayOf(
            doubleArrayOf(0.50, 0.134, 0.060, 0.012), // 預かり所 title plate
            doubleArrayOf(0.13, 0.164, 0.060, 0.020), // 絞り込み button
            doubleArrayOf(0.87, 0.164, 0.060, 0.020), // 入手した順 button
            doubleArrayOf(0.09, 0.425, 0.045, 0.018), // left page arrow
            doubleArrayOf(0.37, 0.425, 0.038, 0.018), // previous-page button
            doubleArrayOf(0.63, 0.425, 0.038, 0.018), // next-page button
            doubleArrayOf(0.89, 0.425, 0.045, 0.018), // right page arrow
            doubleArrayOf(0.50, 0.455, 0.035, 0.012)  // border between list and parent panels
        )
        var anchorHits = 0
        for (a in anchors) {
            if (localContrast(a[0], a[1], a[2], a[3]) >= 0.12) anchorHits++
        }
        return anchorHits >= 4
    }

    private fun updateVideoProgressV278(message: String) {
        runOnUiThread {
            val tv = TextView(this).apply { text = message; setPadding(dp(24), dp(20), dp(24), dp(20)) }
            val dialog = AlertDialog.Builder(this).setTitle("動画解析中").setView(tv).setCancelable(false).create()
            dialog.show()
            window.decorView.postDelayed({ try { dialog.dismiss() } catch (_: Throwable) {} }, 700L)
        }
    }

    private fun handleTrialVideo(uri: Uri) {
        Toast.makeText(this, "動画からページを抽出しています…", Toast.LENGTH_SHORT).show()
        Thread {
            val retriever = MediaMetadataRetriever()
            try {
                if (uri.scheme == "file" && !uri.path.isNullOrBlank()) retriever.setDataSource(uri.path) else retriever.setDataSource(this, uri)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    ?: throw IllegalStateException("動画の長さを取得できませんでした")
                if (durationMs <= 0L) throw IllegalStateException("動画の長さが不正です")
                if (durationMs > 180_000L) throw IllegalArgumentException("試験版では3分以内の動画を使用してください")
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0

                val accepted = mutableListOf<VideoPageCandidateV276>()
                var previousFp: FloatArray? = null
                var stableCount = 0
                var latestStableBitmap: Bitmap? = null
                var latestStableFp: FloatArray? = null

                // 350 ms is enough to observe a one-second page hold several times while keeping the
                // MediaMetadataRetriever workload modest on mid-range Android devices.
                // Integrated recording begins while this app is still visible. Skip the first second so the manager UI is not mistaken for a warehouse page.
                var tMs = 1000L
                while (tMs <= durationMs) {
                    var frame = retriever.getFrameAtTime(tMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (frame != null) {
                        frame = rotateVideoFrameV276(frame, rotation)
                        // The app is portrait-only and the target screen is portrait.  Skip accidental landscape frames.
                        if (frame.height >= frame.width && isLikelyTerryWarehouseFrameV279(frame)) {
                            val fp = videoFrameFingerprintV276(frame)
                            val prev = previousFp
                            val sameAsPrevious = prev != null && fingerprintDistanceV276(prev, fp) < 0.020
                            if (sameAsPrevious) stableCount++ else stableCount = 0
                            previousFp = fp

                            if (stableCount >= 1) {
                                latestStableBitmap?.let { if (it !== frame) try { it.recycle() } catch (_: Throwable) { } }
                                latestStableBitmap = frame
                                latestStableFp = fp
                                frame = null

                                val candidateFp = latestStableFp!!
                                val alreadySeen = accepted.any { fingerprintDistanceV276(it.fingerprint, candidateFp) < 0.032 }
                                if (!alreadySeen) {
                                    accepted.add(VideoPageCandidateV276(latestStableBitmap!!, candidateFp.copyOf()))
                                    runOnUiThread { Toast.makeText(this, "有効ページ ${accepted.size}枚を検出", Toast.LENGTH_SHORT).show() }
                                    latestStableBitmap = null
                                    latestStableFp = null
                                    stableCount = 0
                                }
                            }
                        }
                        frame?.let { try { it.recycle() } catch (_: Throwable) { } }
                    }
                    tMs += 350L
                }
                latestStableBitmap?.let { try { it.recycle() } catch (_: Throwable) { } }

                // v2.7.9 final-page rescue pass.
                // Re-scan only the tail of the movie at a denser interval. This specifically covers
                // a final page that did not get two suitable samples during the normal 350 ms pass.
                // The same fixed-UI filter is still required, so launcher/manager/permission screens
                // cannot be rescued accidentally. Already accepted pages are rejected by fingerprint.
                var rescuedPagesV279 = 0
                var rescuePrevFpV279: FloatArray? = null
                var rescueStableV279 = 0
                var rescueTMsV279 = (durationMs - 5_000L).coerceAtLeast(1_000L)
                while (rescueTMsV279 <= durationMs) {
                    var rescueFrameV279 = retriever.getFrameAtTime(rescueTMsV279 * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (rescueFrameV279 != null) {
                        rescueFrameV279 = rotateVideoFrameV276(rescueFrameV279, rotation)
                        if (rescueFrameV279.height >= rescueFrameV279.width && isLikelyTerryWarehouseFrameV279(rescueFrameV279)) {
                            val rescueFpV279 = videoFrameFingerprintV276(rescueFrameV279)
                            val rescuePrevV279 = rescuePrevFpV279
                            val rescueSameV279 = rescuePrevV279 != null && fingerprintDistanceV276(rescuePrevV279, rescueFpV279) < 0.024
                            if (rescueSameV279) rescueStableV279++ else rescueStableV279 = 0
                            rescuePrevFpV279 = rescueFpV279

                            if (rescueStableV279 >= 1) {
                                val alreadySeenV279 = accepted.any { fingerprintDistanceV276(it.fingerprint, rescueFpV279) < 0.032 }
                                if (!alreadySeenV279) {
                                    accepted.add(VideoPageCandidateV276(rescueFrameV279!!, rescueFpV279.copyOf()))
                                    rescueFrameV279 = null
                                    rescuedPagesV279++
                                    rescueStableV279 = 0
                                    runOnUiThread {
                                        Toast.makeText(this, "最終ページ救済: 有効ページ ${accepted.size}枚", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                        rescueFrameV279?.let { try { it.recycle() } catch (_: Throwable) { } }
                    }
                    rescueTMsV279 += 200L
                }

                if (accepted.isEmpty()) {
                    throw IllegalStateException("静止した預かり所ページを検出できませんでした。各ページを約1秒ずつ表示して録画してください。")
                }

                val tempDir = File(cacheDir, "trial_crops_v276_video")
                try { tempDir.deleteRecursively() } catch (_: Throwable) { }
                tempDir.mkdirs()
                val refs = loadRecognitionReferenceBitmapsV271()
                val results = mutableListOf<TrialRecognition>()
                var cropIndex = 0
                accepted.forEach { page ->
                    results.addAll(analyzeTrialScreenshotV273(page.bitmap, refs, tempDir, cropIndex))
                    cropIndex += 15
                    try { page.bitmap.recycle() } catch (_: Throwable) { }
                }
                refs.values.flatten().forEach { try { it.recycle() } catch (_: Throwable) { } }

                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (rescuedPagesV279 > 0) "${accepted.size}ページを抽出（最終救済 +${rescuedPagesV279}）" else "${accepted.size}ページを動画から抽出しました",
                        Toast.LENGTH_SHORT
                    ).show()
                    // v2.8.2: automatic analysis succeeded, so the finished-recording notification is no longer needed.
                    if (results.isNotEmpty()) {
                        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(2762) } catch (_: Throwable) { }
                    }
                    showTrialResultsV271(results, accepted.size, 0)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("動画解析に失敗しました")
                        .setMessage((t.message ?: t::class.java.simpleName) + "\n\n各ページを約1秒静止させ、▶で1ページずつ送る録画をお試しください。")
                        .setPositiveButton("OK", null)
                        .show()
                }
            } finally {
                try { retriever.release() } catch (_: Throwable) { }
                if (uri.scheme == "file") {
                    val path = uri.path.orEmpty()
                    if (path.startsWith(File(filesDir, "recordings").absolutePath)) {
                        try { File(path).delete() } catch (_: Throwable) { }
                    }
                }
            }
        }.start()
    }

    private fun startTrialOwnershipImport() {
        val (types, samples) = recognitionStats()
        AlertDialog.Builder(this)
            .setTitle("試験機能: 所有状態取得 v2.7.5")
            .setMessage("テリワンSPの配合画面で『預かり所』を表示したスクリーンショットを選択します。\n\n" +
                "・1ページ15枠を解析\n" +
                "・15枠の検出結果から共通5×3グリッドを推定して同一サイズで切り出し\n" +
                "・枠外背景を除去し、ランク / 性別 / パーティ表示を判断画像から除外\n" +
                "・左下の青=♂ / 赤=♀ / 緑=♂♀\n" +
                "・未登録個体は表示用アイコン＋名前の候補から選んで学習\n" +
                "・候補に無い場合は図鑑No. / 名前で検索できます\n\n" +
                "判断用アイコン: ${types}種類 / ${samples}枚\n\n" +
                if (samples == 0) "v2.7.5では預かり所の5×3配置を基準に理論グリッドを固定し、枠検出は数px以内の全体補正だけに使います。暗いアイコンも明度正規化して照合します。最初の解析後に正解を登録してください。" else "登録済みの判断用アイコンを引き継ぎ、v2.7.5の固定グリッド切り出しと明度差を抑えた特徴で照合します。高信頼の個体だけ自動確定します。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("画像を選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 1005)
            }
            .show()
    }

    private fun handleTrialScreenshots(data: Intent) {
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        data.data?.let { if (!uris.contains(it)) uris.add(it) }
        if (uris.isEmpty()) return

        val tempDir = File(cacheDir, "trial_crops_v275")
        try { tempDir.deleteRecursively() } catch (_: Throwable) { }
        tempDir.mkdirs()

        Toast.makeText(this, "${uris.size}枚を解析しています…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val refs = loadRecognitionReferenceBitmapsV271()
                val results = mutableListOf<TrialRecognition>()
                var failedPages = 0
                var cropIndex = 0
                uris.forEach { uri ->
                    val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    if (bmp == null) {
                        failedPages++
                    } else {
                        results.addAll(analyzeTrialScreenshotV273(bmp, refs, tempDir, cropIndex))
                        cropIndex += 15
                        try { bmp.recycle() } catch (_: Throwable) { }
                    }
                }
                refs.values.flatten().forEach { try { it.recycle() } catch (_: Throwable) { } }
                runOnUiThread { showTrialResultsV271(results, uris.size, failedPages) }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("解析に失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun loadRecognitionReferenceBitmapsV271(): Map<Int, List<Bitmap>> {
        val out = HashMap<Int, List<Bitmap>>()
        val root = recognitionIconDir()
        monsters.forEach { m ->
            val dir = File(root, m.no.toString().padStart(3, '0'))
            val list = dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }?.take(5)
                ?.mapNotNull { BitmapFactory.decodeFile(it.absolutePath) } ?: emptyList()
            if (list.isNotEmpty()) out[m.no] = list
        }
        return out
    }

    private data class IconFrameV273(val left: Int, val top: Int, val right: Int, val bottom: Int)
    private data class SlotProbeV273(
        val row: Int, val col: Int, val cx: Int, val cy: Int, val sex: Int,
        val candidate: IconFrameV273?
    )

    private fun medianIntV273(values: List<Int>): Int? {
        if (values.isEmpty()) return null
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }

    private fun analyzeTrialScreenshotV273(
        src: Bitmap,
        refs: Map<Int, List<Bitmap>>,
        tempDir: File,
        startIndex: Int
    ): List<TrialRecognition> {
        // v2.7.5: the game screen itself has a very stable 5 x 3 layout.  v2.7.4 still let
        // noisy per-monster frame observations determine too much of the final geometry, and a bad
        // observation could move the whole page.  In v2.7.5 the calibrated layout is PRIMARY.
        // Edge detection is allowed to contribute only a tiny screenshot-level correction.
        //
        // Calibrated from the actual 預かり所 screen (full-screen screenshot coordinates):
        // - columns are nearly equally spaced horizontally
        // - row spacing is slightly tighter than v2.7.4 assumed
        // - the visible square frame is about 10.8% of screen width
        val xNorm = doubleArrayOf(0.126, 0.312, 0.498, 0.684, 0.870)
        val yNorm = doubleArrayOf(0.209, 0.283, 0.357)
        val expectedSide = (src.width * 0.108).toInt().coerceAtLeast(48)
        val sexProbeSide = (expectedSide * 1.22).toInt().coerceAtLeast(58)
        val probes = mutableListOf<SlotProbeV273>()

        for (row in yNorm.indices) for (col in xNorm.indices) {
            val cx = (src.width * xNorm[col]).toInt()
            val cy = (src.height * yNorm[row]).toInt()

            val probeLeft = (cx - sexProbeSide / 2).coerceIn(0, src.width - 1)
            val probeTop = (cy - sexProbeSide / 2).coerceIn(0, src.height - 1)
            val probeW = sexProbeSide.coerceAtMost(src.width - probeLeft)
            val probeH = sexProbeSide.coerceAtMost(src.height - probeTop)
            var sex = -1
            if (probeW >= 30 && probeH >= 30) {
                val sexProbe = Bitmap.createBitmap(src, probeLeft, probeTop, probeW, probeH)
                sex = detectTrialSexV271(sexProbe)
                sexProbe.recycle()
            }
            val candidate = detectIconFrameCandidateV273(src, cx, cy, expectedSide)
            probes.add(SlotProbeV273(row, col, cx, cy, sex, candidate))
        }

        // Only very plausible frame observations may affect the shared geometry.  Crucially, there is
        // no per-row/per-column/per-monster correction: one X/Y correction is shared by every slot.
        val plausible = probes.mapNotNull { p -> p.candidate?.let { Pair(p, it) } }.filter { (p, f) ->
            val width = f.right - f.left
            val height = f.bottom - f.top
            val widthOk = width in (expectedSide * 0.90).toInt()..(expectedSide * 1.10).toInt()
            val heightOk = height in (expectedSide * 0.72).toInt()..(expectedSide * 1.20).toInt()
            val ro = f.right - (p.cx + expectedSide / 2)
            val bo = f.bottom - (p.cy + expectedSide / 2)
            widthOk && heightOk &&
                kotlin.math.abs(ro) <= (expectedSide * 0.16).toInt() &&
                kotlin.math.abs(bo) <= (expectedSide * 0.16).toInt()
        }

        // Keep crop size essentially fixed.  A reliable page may refine it by only a few percent.
        val observedWidths = plausible.map { (_, f) -> f.right - f.left }
        val sharedSide = (medianIntV273(observedWidths) ?: expectedSide).coerceIn(
            (expectedSide * 0.96).toInt(), (expectedSide * 1.04).toInt()
        )

        val rightResiduals = plausible.map { (p, f) -> f.right - (p.cx + sharedSide / 2) }
        val bottomResiduals = plausible.map { (p, f) -> f.bottom - (p.cy + sharedSide / 2) }
        val correctionLimit = maxOf(2, (sharedSide * 0.045).toInt())
        val globalRightCorrection = (medianIntV273(rightResiduals) ?: 0).coerceIn(-correctionLimit, correctionLimit)
        val globalBottomCorrection = (medianIntV273(bottomResiduals) ?: 0).coerceIn(-correctionLimit, correctionLimit)

        val columnRights = IntArray(xNorm.size) { col ->
            (src.width * xNorm[col]).toInt() + sharedSide / 2 + globalRightCorrection
        }
        val rowBottoms = IntArray(yNorm.size) { row ->
            (src.height * yNorm[row]).toInt() + sharedSide / 2 + globalBottomCorrection
        }

        val results = mutableListOf<TrialRecognition>()
        probes.forEachIndexed { index, p ->
            // Empty slots have no sex badge.  Skipping here also makes a 3-monster final page finish
            // immediately after those 3 monsters instead of producing 12 dummy registration dialogs.
            if (p.sex < 0) return@forEachIndexed

            val right = columnRights[p.col].coerceIn(sharedSide, src.width)
            val bottom = rowBottoms[p.row].coerceIn(sharedSide, src.height)
            val left = (right - sharedSide).coerceAtLeast(0)
            val top = (bottom - sharedSide).coerceAtLeast(0)
            val actualRight = (left + sharedSide).coerceAtMost(src.width)
            val actualBottom = (top + sharedSide).coerceAtMost(src.height)
            val fw = actualRight - left
            val fh = actualBottom - top
            if (fw < 28 || fh < 28) return@forEachIndexed

            val frameCrop = Bitmap.createBitmap(src, left, top, fw, fh)
            val rawFile = File(tempDir, "raw_${(startIndex + index).toString().padStart(3, '0')}.png")
            val coreFile = File(tempDir, "core_${(startIndex + index).toString().padStart(3, '0')}.png")
            try { rawFile.outputStream().buffered().use { frameCrop.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Throwable) { }
            val core = normalizeRecognitionBitmapV272(frameCrop)
            try { coreFile.outputStream().buffered().use { core.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Throwable) { }
            val match = matchRecognitionMonsterV271(core, refs)
            val accepted = match.no > 0 && match.score >= 0.88 && match.margin >= 0.030
            results.add(TrialRecognition(match.no, p.sex, match.score, match.secondNo, match.margin, accepted, rawFile.absolutePath, coreFile.absolutePath))
            core.recycle(); frameCrop.recycle()
        }
        return results
    }

    private fun detectIconFrameCandidateV273(src: Bitmap, cx: Int, cy: Int, expectedSide: Int): IconFrameV273? {
        // Detect an observation of the frame.  Unlike v2.7.2 there is NO per-slot fallback crop here.
        // Failed/odd observations are allowed to disappear; the shared 5x3 grid fills them later.
        val half = expectedSide / 2
        val minX = (cx - (expectedSide * 0.72).toInt()).coerceAtLeast(2)
        val maxX = (cx + (expectedSide * 0.72).toInt()).coerceAtMost(src.width - 3)
        val minY = (cy - (expectedSide * 0.72).toInt()).coerceAtLeast(2)
        val maxY = (cy + (expectedSide * 0.72).toInt()).coerceAtMost(src.height - 3)

        fun lum(x: Int, y: Int): Int {
            val c = src.getPixel(x, y)
            return (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
        }
        fun vScore(x: Int): Double {
            var sum = 0.0; var n = 0
            val y0 = (cy - expectedSide * 0.27).toInt().coerceAtLeast(minY)
            val y1 = (cy + expectedSide * 0.27).toInt().coerceAtMost(maxY)
            for (y in y0..y1 step 2) { sum += kotlin.math.abs(lum(x - 1, y) - lum(x + 1, y)); n++ }
            return if (n == 0) 0.0 else sum / n
        }
        fun hScore(y: Int): Double {
            var sum = 0.0; var n = 0
            val x0 = (cx - expectedSide * 0.27).toInt().coerceAtLeast(minX)
            val x1 = (cx + expectedSide * 0.27).toInt().coerceAtMost(maxX)
            for (x in x0..x1 step 2) { sum += kotlin.math.abs(lum(x, y - 1) - lum(x, y + 1)); n++ }
            return if (n == 0) 0.0 else sum / n
        }
        fun bestX(from: Int, to: Int, target: Int): Pair<Int, Double> {
            if (from > to) return Pair(target.coerceIn(minX, maxX), 0.0)
            var best = target.coerceIn(from, to); var bestScore = -1.0
            for (x in from..to) {
                val distancePenalty = kotlin.math.abs(x - target).toDouble() / expectedSide * 4.0
                val score = vScore(x) - distancePenalty
                if (score > bestScore) { bestScore = score; best = x }
            }
            return Pair(best, bestScore)
        }
        fun bestY(from: Int, to: Int, target: Int): Pair<Int, Double> {
            if (from > to) return Pair(target.coerceIn(minY, maxY), 0.0)
            var best = target.coerceIn(from, to); var bestScore = -1.0
            for (y in from..to) {
                val distancePenalty = kotlin.math.abs(y - target).toDouble() / expectedSide * 4.0
                val score = hScore(y) - distancePenalty
                if (score > bestScore) { bestScore = score; best = y }
            }
            return Pair(best, bestScore)
        }

        val (right, rs) = bestX((cx + expectedSide * 0.32).toInt().coerceAtLeast(minX), maxX, cx + half)
        val (bottom, bs) = bestY((cy + expectedSide * 0.32).toInt().coerceAtLeast(minY), maxY, cy + half)
        val (left, ls) = bestX(minX, (cx - expectedSide * 0.25).toInt().coerceAtMost(maxX), right - expectedSide)
        val (top, ts) = bestY(minY, (cy - expectedSide * 0.25).toInt().coerceAtMost(maxY), bottom - expectedSide)
        val width = right - left
        val height = bottom - top
        // v2.7.5 observation detector does not require the top edge to be perfect. On rows 2/3, internal
        // horizontal art often scores more strongly than the real top frame. Right, bottom and left are
        // stable, so they define the grid; sharedSide later reconstructs top uniformly for every slot.
        val valid = width in (expectedSide * 0.78).toInt()..(expectedSide * 1.36).toInt() &&
            height > (expectedSide * 0.40).toInt() &&
            minOf(rs, bs, ls) > 2.0
        if (!valid) return null
        return IconFrameV273(left, top, right, bottom)
    }

    private fun detectTrialSexV271(crop: Bitmap): Int {
        val x0 = 0
        val x1 = (crop.width * 0.34).toInt().coerceAtMost(crop.width)
        val y0 = (crop.height * 0.57).toInt()
        var blue = 0; var red = 0; var green = 0
        for (y in y0 until crop.height step 2) for (x in x0 until x1 step 2) {
            val c = crop.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (b > 105 && b > r * 1.18 && b > g * 1.04) blue++
            if (r > 115 && r > g * 1.18 && r > b * 1.08) red++
            if (g > 100 && g > r * 1.08 && g > b * 1.01) green++
        }
        val max = maxOf(blue, red, green)
        if (max < 3) return -1
        return when (max) { blue -> 0; red -> 1; else -> 2 }
    }

    private fun normalizeRecognitionBitmapV271(source: Bitmap): Bitmap {
        // First normalize the complete square frame, then remove the frame/background margin.
        val square = Bitmap.createScaledBitmap(source, 64, 64, true)
        val inner = Bitmap.createBitmap(square, 5, 5, 54, 54)
        val out = Bitmap.createScaledBitmap(inner, 48, 48, true).copy(Bitmap.Config.ARGB_8888, true)
        if (square !== source) square.recycle()
        if (inner !== out && inner !== source) inner.recycle()

        // Neutralize the three overlay zones. These pixels must never influence monster identity.
        val neutral = Color.rgb(128, 128, 128)
        for (y in 0 until out.height) for (x in 0 until out.width) {
            val rank = x < 15 && y < 15
            val sex = x < 17 && y >= 31
            val party = x >= 31 && y < 17
            val edge = x < 1 || y < 1 || x >= out.width - 1 || y >= out.height - 1
            if (rank || sex || party || edge) out.setPixel(x, y, neutral)
        }
        return out
    }

    private fun normalizeRecognitionBitmapV272(source: Bitmap): Bitmap {
        // The source is already the detected square frame. Normalize every sample to exactly 48x48.
        // Keep the common frame for geometric alignment, but neutralize all variable overlays.
        val out = Bitmap.createScaledBitmap(source, 48, 48, true).copy(Bitmap.Config.ARGB_8888, true)
        val neutral = Color.rgb(128, 128, 128)
        for (y in 0 until out.height) for (x in 0 until out.width) {
            val rank = x < 14 && y < 15
            val sex = x < 16 && y >= 31
            val party = x >= 31 && y < 17
            val outsideUseful = x < 2 || y < 2 || x >= 46 || y >= 46
            if (rank || sex || party || outsideUseful) out.setPixel(x, y, neutral)
        }
        return out
    }

    private data class TrialMatch(val no: Int, val score: Double, val secondNo: Int, val margin: Double)

    private fun matchRecognitionMonsterV271(core: Bitmap, refs: Map<Int, List<Bitmap>>): TrialMatch {
        if (refs.isEmpty()) return TrialMatch(-1, 0.0, -1, 0.0)
        var bestNo = -1; var bestScore = -1.0
        var secondNo = -1; var secondScore = -1.0
        refs.forEach { (no, samples) ->
            var monsterBest = -1.0
            samples.forEach { sample ->
                val score = compareNormalizedV271(core, sample)
                if (score > monsterBest) monsterBest = score
            }
            if (monsterBest > bestScore) {
                secondScore = bestScore; secondNo = bestNo
                bestScore = monsterBest; bestNo = no
            } else if (monsterBest > secondScore) {
                secondScore = monsterBest; secondNo = no
            }
        }
        val margin = if (secondScore < 0) bestScore else (bestScore - secondScore).coerceAtLeast(0.0)
        return TrialMatch(bestNo, bestScore.coerceAtLeast(0.0), secondNo, margin)
    }

    private fun compareNormalizedV271(aBmp: Bitmap, bBmp: Bitmap): Double {
        // v2.7.5 comparison: ignore global brightness/contrast differences caused by monsters that
        // are darkened because they cannot currently be used for breeding.  Compare standardized
        // luminance plus edge structure, with a small translation tolerance.
        val size = 40
        val a = if (aBmp.width == size && aBmp.height == size) aBmp else Bitmap.createScaledBitmap(aBmp, size, size, true)
        val b = if (bBmp.width == size && bBmp.height == size) bBmp else Bitmap.createScaledBitmap(bBmp, size, size, true)
        val ap = IntArray(size * size); val bp = IntArray(size * size)
        a.getPixels(ap, 0, size, 0, 0, size, size); b.getPixels(bp, 0, size, 0, 0, size, size)

        fun isMasked(x: Int, y: Int): Boolean {
            // Same geometry as the 48px mask, scaled to 40px.
            return (x < 12 && y < 13) || (x < 14 && y >= 26) || (x >= 26 && y < 14) ||
                x < 2 || y < 2 || x >= size - 2 || y >= size - 2
        }
        fun luminance(c: Int): Double = (Color.red(c) * 0.299 + Color.green(c) * 0.587 + Color.blue(c) * 0.114)
        val al = DoubleArray(size * size) { luminance(ap[it]) }
        val bl = DoubleArray(size * size) { luminance(bp[it]) }

        fun stats(arr: DoubleArray): Pair<Double, Double> {
            var sum = 0.0; var n = 0
            for (y in 0 until size) for (x in 0 until size) if (!isMasked(x, y)) { sum += arr[y * size + x]; n++ }
            val mean = if (n > 0) sum / n else 128.0
            var variance = 0.0
            for (y in 0 until size) for (x in 0 until size) if (!isMasked(x, y)) {
                val d = arr[y * size + x] - mean; variance += d * d
            }
            val sd = kotlin.math.sqrt(variance / maxOf(1, n)).coerceAtLeast(10.0)
            return Pair(mean, sd)
        }
        val (am, asd) = stats(al); val (bm, bsd) = stats(bl)
        var best = 0.0
        for (dy in -1..1) for (dx in -1..1) {
            var dot = 0.0; var aa = 0.0; var bb = 0.0
            var edgeDiff = 0.0; var edgeN = 0; var n = 0
            for (y in 3 until size - 3) for (x in 3 until size - 3) {
                val bx = x + dx; val by = y + dy
                if (bx !in 2 until size - 2 || by !in 2 until size - 2 || isMasked(x,y) || isMasked(bx,by)) continue
                val av = (al[y * size + x] - am) / asd
                val bv = (bl[by * size + bx] - bm) / bsd
                dot += av * bv; aa += av * av; bb += bv * bv; n++

                if (!isMasked(x+1,y) && !isMasked(x-1,y) && !isMasked(x,y+1) && !isMasked(x,y-1) &&
                    !isMasked(bx+1,by) && !isMasked(bx-1,by) && !isMasked(bx,by+1) && !isMasked(bx,by-1)) {
                    val agx = (al[y*size + x+1] - al[y*size + x-1]) / asd
                    val agy = (al[(y+1)*size + x] - al[(y-1)*size + x]) / asd
                    val bgx = (bl[by*size + bx+1] - bl[by*size + bx-1]) / bsd
                    val bgy = (bl[(by+1)*size + bx] - bl[(by-1)*size + bx]) / bsd
                    val ae = kotlin.math.sqrt(agx*agx + agy*agy)
                    val be = kotlin.math.sqrt(bgx*bgx + bgy*bgy)
                    edgeDiff += kotlin.math.abs(ae - be); edgeN++
                }
            }
            if (n > 150 && aa > 0.0 && bb > 0.0) {
                val corr = (dot / kotlin.math.sqrt(aa * bb)).coerceIn(-1.0, 1.0)
                val corrScore = ((corr + 1.0) / 2.0).coerceIn(0.0, 1.0)
                val edgeScore = if (edgeN > 0) (1.0 - (edgeDiff / edgeN) / 2.5).coerceIn(0.0, 1.0) else corrScore
                val score = (corrScore * 0.72 + edgeScore * 0.28).coerceIn(0.0, 1.0)
                if (score > best) best = score
            }
        }
        if (a !== aBmp) a.recycle(); if (b !== bBmp) b.recycle()
        return best
    }

    private fun saveRecognitionSampleV271(corePath: String, no: Int): Boolean {
        return try {
            val bmp = BitmapFactory.decodeFile(corePath) ?: return false
            val dir = File(recognitionIconDir(), no.toString().padStart(3, '0')).apply { mkdirs() }
            while ((dir.listFiles()?.count { it.isFile } ?: 0) >= 5) {
                val oldest = dir.listFiles()?.filter { it.isFile }?.minByOrNull { it.lastModified() } ?: break
                oldest.delete()
            }
            val f = File(dir, "core_${System.currentTimeMillis()}.png")
            val ok = f.outputStream().buffered().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle(); ok
        } catch (_: Throwable) { false }
    }

    private data class DisplayCandidateV280(val monster: Monster, val score: Double)

    private fun suggestDisplayCandidatesV271(corePath: String, limit: Int = 3): List<DisplayCandidateV280> {
        val core = BitmapFactory.decodeFile(corePath) ?: return emptyList()
        val scores = ArrayList<Pair<Monster, Double>>()
        monsters.forEach { m ->
            val f = monsterIconFile(m.no)
            if (!f.isFile) return@forEach
            val display = BitmapFactory.decodeFile(f.absolutePath) ?: return@forEach
            val norm = normalizeRecognitionBitmapV272(display)
            val score = compareNormalizedV271(core, norm)
            scores.add(Pair(m, score))
            norm.recycle(); display.recycle()
        }
        core.recycle()
        return scores.sortedByDescending { it.second }.take(limit).map { DisplayCandidateV280(it.first, it.second) }
    }

    private fun applyRecognitionsToOwnership(items: List<TrialRecognition>) {
        if (items.isEmpty()) return
        val grouped = items.filter { it.no > 0 }.groupBy { Pair(it.no, it.sex) }.mapValues { it.value.size }
        val edit = pref.edit()
        grouped.forEach { (key, count) ->
            val no = key.first
            when (key.second) {
                0 -> { maleCounts[no] = male(no) + count; edit.putInt("m$no", male(no)) }
                1 -> { femaleCounts[no] = female(no) + count; edit.putInt("f$no", female(no)) }
                else -> { bothCounts[no] = both(no) + count; edit.putInt("b$no", both(no)) }
            }
        }
        edit.apply()
    }

    private fun showTrialResultsV271(results: List<TrialRecognition>, pages: Int, failedPages: Int) {
        if (results.isEmpty()) {
            AlertDialog.Builder(this).setTitle("認識できませんでした")
                .setMessage("${pages}枚を解析しましたが、性別付きのモンスター枠を取得できませんでした。")
                .setPositiveButton("OK", null).show(); return
        }
        val accepted = results.filter { it.accepted && it.no > 0 }
        val pending = results.filter { !it.accepted || it.no <= 0 }
        val sexText = arrayOf("♂", "♀", "♂♀")
        val acceptedLines = accepted.groupBy { Pair(it.no, it.sex) }.entries.take(30).map { e ->
            val m = monsters.firstOrNull { it.no == e.key.first }
            "No.${e.key.first.toString().padStart(3, '0')} ${m?.name ?: ""}  ${sexText[e.key.second]} ×${e.value.size}"
        }
        val pendingLines = pending.take(15).mapIndexed { i, r ->
            val a = monsters.firstOrNull { it.no == r.no }?.name
            if (a == null) "${i + 1}. ${sexText[r.sex]}  未登録" else "${i + 1}. ${sexText[r.sex]}  候補 ${a} ${(r.confidence * 100).toInt()}%"
        }
        val (types, samples) = recognitionStats()
        val msg = buildString {
            append("解析画像: ${pages}枚")
            if (failedPages > 0) append("（読込失敗 ${failedPages}枚）")
            append("\n検出枠: ${results.size}体")
            append("\n自動確定: ${accepted.size}体 / 要登録: ${pending.size}体")
            append("\n判断用アイコン: ${types}種類 / ${samples}枚")
            if (acceptedLines.isNotEmpty()) { append("\n\n【自動確定】\n"); append(acceptedLines.joinToString("\n")) }
            if (pendingLines.isNotEmpty()) { append("\n\n【要登録】\n"); append(pendingLines.joinToString("\n")); if (pending.size > 15) append("\n…ほか ${pending.size - 15}体") }
            append("\n\nv2.8.0では5×3固定グリッドとv2.7.9の動画ページ判定を維持しています。未登録個体の選択画面は上位3候補だけを表示し、比較用の内部一致度も併記します。一致度は正解確率ではなく画像比較スコアです。")
        }
        AlertDialog.Builder(this)
            .setTitle("所有状態 解析結果（v2.8.2）")
            .setMessage(msg)
            .setNegativeButton("キャンセル", null)
            .setNeutralButton(if (pending.isEmpty()) "要登録なし" else "要登録を学習") { _, _ -> if (pending.isNotEmpty()) registerPendingRecognitionV271(pending, 0, mutableListOf()) }
            .setPositiveButton(if (accepted.isEmpty()) "確定候補なし" else "確定分を加算") { _, _ ->
                if (accepted.isNotEmpty()) {
                    applyRecognitionsToOwnership(accepted)
                    Toast.makeText(this, "自動確定した ${accepted.size}体を所有数へ加算しました", Toast.LENGTH_LONG).show(); showManagementPage()
                } else Toast.makeText(this, "自動確定できた候補がありません", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun registerPendingRecognitionV271(pending: List<TrialRecognition>, index: Int, registered: MutableList<TrialRecognition>) {
        var idx = index
        while (idx < pending.size && pending[idx].accepted) idx++
        if (idx >= pending.size) {
            val (types, samples) = recognitionStats()
            AlertDialog.Builder(this).setTitle("判断用アイコンを登録しました")
                .setMessage("今回登録/同時判定: ${registered.size}体\n判断用アイコン: ${types}種類 / ${samples}枚\n\n登録した個体を現在の所有数にも加算しますか？")
                .setNegativeButton("加算しない", null)
                .setPositiveButton("所有数へ加算") { _, _ ->
                    applyRecognitionsToOwnership(registered.distinctBy { it.cropPath })
                    Toast.makeText(this, "${registered.distinctBy { it.cropPath }.size}体を所有数へ加算しました", Toast.LENGTH_LONG).show(); showManagementPage()
                }.show(); return
        }
        val actualIndex = idx
        Toast.makeText(this, "候補を準備しています…", Toast.LENGTH_SHORT).show()
        Thread {
            val candidates = try { suggestDisplayCandidatesV271(pending[actualIndex].corePath, 3) } catch (_: Throwable) { emptyList() }
            runOnUiThread { showRecognitionChoiceV271(pending, actualIndex, registered, candidates) }
        }.start()
    }

    private fun showRecognitionChoiceV271(
        pending: List<TrialRecognition>, index: Int, registered: MutableList<TrialRecognition>, candidates: List<DisplayCandidateV280>
    ) {
        val r = pending[index]
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(6)) }
        scroll.addView(root)
        root.addView(ImageView(this).apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_INSIDE
            BitmapFactory.decodeFile(r.cropPath)?.let { setImageBitmap(it) }
        }, LinearLayout.LayoutParams(-1, dp(105)))
        root.addView(TextView(this).apply {
            text = "${arrayOf("♂", "♀", "♂♀")[r.sex]}  このゲーム内アイコンと同じモンスターを選択してください（${index + 1}/${pending.size}）"
            textSize = 13f; setTextColor(textMain); setPadding(0, dp(6), 0, dp(5))
        })
        root.addView(TextView(this).apply { text = "上位3候補（表示用アイコン＋名前＋一致度）"; textSize = 12f; setTextColor(textSub) })

        val candidateRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(candidateRows)
        val labels = monsters.map { "${it.no.toString().padStart(3, '0')}  ${it.name}" }
        val input = AutoCompleteTextView(this).apply {
            hint = "候補に無ければ No. または名前で検索"; threshold = 1
            setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, labels))
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })

        val dialog = AlertDialog.Builder(this)
            .setTitle("判断用アイコン登録 v2.8.2")
            .setView(scroll)
            .setNegativeButton("残りを中止") { _, _ -> if (registered.isNotEmpty()) registerPendingRecognitionV271(emptyList(), 0, registered) }
            .setNeutralButton("この個体を飛ばす") { _, _ -> registerPendingRecognitionV271(pending, index + 1, registered) }
            .setPositiveButton("検索欄の個体を登録", null)
            .create()

        fun candidateRow(c: DisplayCandidateV280): View {
            val m = c.monster
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(3), dp(6), dp(3)); background = roundedBg(Color.rgb(248,250,252), 7)
            }
            row.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val f = monsterIconFile(m.no)
                if (f.isFile) BitmapFactory.decodeFile(f.absolutePath)?.let { setImageBitmap(it) }
            }, LinearLayout.LayoutParams(dp(48), dp(48)))
            row.addView(TextView(this).apply {
                text = "No.${m.no.toString().padStart(3, '0')}  ${m.name}\n一致度 ${(c.score * 100.0).let { String.format(java.util.Locale.US, "%.1f", it) }}%"; textSize = 13f; setTextColor(textMain); setPadding(dp(10), 0, 0, 0)
            }, LinearLayout.LayoutParams(0, dp(50), 1f))
            row.setOnClickListener {
                dialog.dismiss(); commitRecognitionRegistrationV271(pending, index, registered, m)
            }
            return row
        }
        candidates.forEach { c -> candidateRows.addView(candidateRow(c), LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(3) }) }
        if (candidates.isEmpty()) candidateRows.addView(TextView(this).apply { text = "候補を作成できませんでした。下の検索を使用してください。"; setTextColor(textSub); textSize = 12f })

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val m = findMonsterFromInputV271(input.text.toString())
                if (m == null) Toast.makeText(this, "候補をタップするか、正しい図鑑No. / 名前を入力してください", Toast.LENGTH_LONG).show()
                else { dialog.dismiss(); commitRecognitionRegistrationV271(pending, index, registered, m) }
            }
        }
        dialog.show()
    }

    private fun findMonsterFromInputV271(rawValue: String): Monster? {
        val raw = rawValue.trim(); if (raw.isEmpty()) return null
        val noText = Regex("^(?:No\\.?\\s*)?(\\d{1,3})").find(raw)?.groupValues?.getOrNull(1)
        val byNo = noText?.toIntOrNull()?.let { n -> monsters.firstOrNull { it.no == n } }
        if (byNo != null) return byNo
        val nameFromLabel = raw.substringAfter(Regex("^\\d{1,3}\\s+").find(raw)?.value ?: "").trim()
        return monsters.firstOrNull { it.name == raw || it.name == nameFromLabel }
            ?: monsters.filter { it.name.contains(raw, ignoreCase = true) }.singleOrNull()
    }

    private fun commitRecognitionRegistrationV271(
        pending: List<TrialRecognition>, index: Int, registered: MutableList<TrialRecognition>, monster: Monster
    ) {
        val r = pending[index]
        if (!saveRecognitionSampleV271(r.corePath, monster.no)) {
            Toast.makeText(this, "判断用アイコンの保存に失敗しました", Toast.LENGTH_LONG).show()
            registerPendingRecognitionV271(pending, index, registered); return
        }
        r.no = monster.no; r.confidence = 1.0; r.secondNo = -1; r.margin = 1.0; r.accepted = true
        registered.add(r)

        // Re-check the remaining crops against the just confirmed game icon.  This is especially useful
        // when the same monster appears twice on one page; the user normally has to identify it only once.
        val learned = BitmapFactory.decodeFile(r.corePath)
        if (learned != null) {
            for (i in index + 1 until pending.size) {
                val other = pending[i]
                if (other.accepted) continue
                val otherBmp = BitmapFactory.decodeFile(other.corePath) ?: continue
                val score = compareNormalizedV271(learned, otherBmp)
                otherBmp.recycle()
                if (score >= 0.965) {
                    other.no = monster.no; other.confidence = score; other.secondNo = -1; other.margin = 1.0; other.accepted = true
                    registered.add(other)
                }
            }
            learned.recycle()
        }
        registerPendingRecognitionV271(pending, index + 1, registered)
    }

    private data class RecipePlan(
        val canBreed: Boolean,
        val assigned: List<Monster?>,
        val missingLabels: List<String>
    )

    private fun ruleCandidates(ruleRaw: String): List<Monster> {
        val rule = ruleRaw.trim()
        if (rule == "その他") return monsters.filter { owned(it) > 0 }
        val m = Regex("^(.+?)系モンスター(?:[（(]ランク(SS|S|A|B|C|D|E|F)(以上|以下)[）)])?$").find(rule)
            ?: return emptyList()
        val family = m.groupValues[1]
        val rank = m.groupValues[2]
        val relation = m.groupValues[3]
        val rankOrder = mapOf("F" to 0, "E" to 1, "D" to 2, "C" to 3, "B" to 4, "A" to 5, "S" to 6, "SS" to 7)
        val threshold = rankOrder[rank]
        return monsters.filter { mon ->
            if (mon.family != family || owned(mon) <= 0) return@filter false
            if (threshold == null || relation.isBlank()) return@filter true
            val value = rankOrder[mon.rank] ?: return@filter false
            if (relation == "以上") value >= threshold else value <= threshold
        }
    }

    /**
     * v2.8.23: determine whether every parent slot can be consumed at the same time.
     * This deliberately uses inventory counts, not just "is owned" flags, so recipes such as
     * A × A require two copies. Rule parents are assigned to concrete owned monsters and share
     * the same inventory pool as named parents.
     */
    private fun recipePlan(r: BreedingRecipe): RecipePlan {
        val parentNames = r.parents.take(4)
        if (parentNames.isEmpty()) return RecipePlan(false, emptyList(), listOf("親データなし"))
        val candidates = parentNames.mapIndexed { i, name ->
            val type = r.parentTypes.getOrNull(i).orEmpty()
            if (type.equals("rule", true)) ruleCandidates(name)
            else monsterByName[name]?.let { listOf(it) } ?: emptyList()
        }
        val order = candidates.indices.sortedBy { candidates[it].size }
        val used = HashMap<Int, Int>()
        val assigned = MutableList<Monster?>(parentNames.size) { null }
        fun dfs(depth: Int): Boolean {
            if (depth >= order.size) return true
            val slot = order[depth]
            for (m in candidates[slot]) {
                val now = used[m.no] ?: 0
                if (now >= owned(m)) continue
                used[m.no] = now + 1
                assigned[slot] = m
                if (dfs(depth + 1)) return true
                assigned[slot] = null
                if (now == 0) used.remove(m.no) else used[m.no] = now
            }
            return false
        }
        val ok = dfs(0)
        if (ok) return RecipePlan(true, assigned.toList(), emptyList())

        // Build a human-readable shortage summary. For rule slots we report the rule itself;
        // named duplicates report the required/owned quantity.
        val missing = mutableListOf<String>()
        val namedNeeds = linkedMapOf<Int, Pair<Monster, Int>>()
        parentNames.forEachIndexed { i, name ->
            val type = r.parentTypes.getOrNull(i).orEmpty()
            if (type.equals("rule", true)) {
                if (ruleCandidates(name).isEmpty()) missing += name
            } else {
                val m = monsterByName[name]
                if (m == null) missing += name
                else {
                    val prev = namedNeeds[m.no]?.second ?: 0
                    namedNeeds[m.no] = m to (prev + 1)
                }
            }
        }
        namedNeeds.values.forEach { (m, need) ->
            if (owned(m) < need) missing += if (need > 1) "${m.name} ${owned(m)}/$need" else m.name
        }
        if (missing.isEmpty()) missing += "素材の同時消費条件を満たしません"
        return RecipePlan(false, List(parentNames.size) { null }, missing)
    }

    private fun postBreedingSummary(r: BreedingRecipe, plan: RecipePlan): String? {
        if (!plan.canBreed) return null
        val result = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName] ?: return null
        val consumed = plan.assigned.filterNotNull().groupingBy { it.no }.eachCount()
        fun after(m: Monster): Int = owned(m) - (consumed[m.no] ?: 0) + if (m.no == result.no) 1 else 0
        val parts = mutableListOf("子 ${result.name} 所持${after(result)}")
        plan.assigned.filterNotNull().distinctBy { it.no }.filter { it.no != result.no }.take(3).forEach { m ->
            parts += "${m.name} 所持${after(m)}"
        }
        return "配合後見込み：" + parts.joinToString(" / ")
    }

    private fun captureBreedingReturnState(): BreedingReturnState? {
        if (!::breedList.isInitialized || !::breedSearch.isInitialized) return null
        val first = breedList.firstVisiblePosition
        val top = breedList.getChildAt(0)?.top ?: 0
        return BreedingReturnState(
            breedSearch.text?.toString().orEmpty(),
            breedDirection.selectedItemPosition,
            breedMatchMode.selectedItemPosition,
            breedSort.selectedItemPosition,
            breedSortOrder.selectedItemPosition,
            breedType.selectedItem?.toString().orEmpty(),
            breedRank.selectedItem?.toString().orEmpty(),
            breedFamily.selectedItem?.toString().orEmpty(),
            breedSize.selectedItem?.toString().orEmpty(),
            breedCanMake.isChecked,
            breedCannotMake.isChecked,
            breedWantedChild.isChecked,
            first,
            top
        )
    }

    private fun spinnerSelectText(spinner: Spinner, value: String) {
        val a = spinner.adapter ?: return
        for (i in 0 until a.count) {
            if (a.getItem(i)?.toString() == value) {
                spinner.setSelection(i)
                return
            }
        }
    }

    private fun jumpFromBreedingToManagement(m: Monster) {
        breedingReturnState = captureBreedingReturnState()
        showManagementPage(m.no, 1)
    }

    private fun restoreBreedingAfterManagementJump() {
        val s = breedingReturnState
        managementFocusNo = null
        managementReturnMode = 0
        if (s == null) {
            showBreedingPage()
            return
        }
        showBreedingPage(s.query, s.direction)
        breedMatchMode.setSelection(s.matchMode)
        breedSort.setSelection(s.sortMode)
        breedSortOrder.setSelection(s.sortOrder)
        spinnerSelectText(breedType, s.typeText)
        spinnerSelectText(breedRank, s.rankText)
        spinnerSelectText(breedFamily, s.familyText)
        spinnerSelectText(breedSize, s.sizeText)
        breedCanMake.isChecked = s.canMake
        breedCannotMake.isChecked = s.cannotMake
        breedWantedChild.isChecked = s.wantedChild
        applyBreedingFilter()
        breedList.post { breedList.setSelectionFromTop(s.firstVisible, s.topOffset) }
    }

    private fun showBreedingPage(query: String = "", direction: Int = 0) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(4))
            setBackgroundColor(bg)
        }
        root.addView(topMenu(1))

        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = "配合表"; textSize = 20f; setTextColor(textMain); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        breedStats = TextView(this).apply { textSize = 12.5f; setTextColor(textSub); gravity = Gravity.END }
        titleRow.addView(breedStats)
        root.addView(titleRow, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(3) })

        val directionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        breedDirection = makeSpinner(arrayOf("子 → 親", "親 → 子"))
        breedDirection.setSelection(direction)
        directionRow.addView(breedDirection, LinearLayout.LayoutParams(0, dp(42), 0.34f).apply { marginEnd = dp(4) })
        breedSearch = EditText(this).apply {
            hint = if (direction == 0) "モンスター名・図鑑No.で検索" else "親モンスター名・系統条件"
            setSingleLine(true); textSize = 15f; setText(query)
            background = roundedBg(Color.WHITE, 10)
            setPadding(dp(12), 0, dp(12), 0)
        }
        directionRow.addView(breedSearch, LinearLayout.LayoutParams(0, dp(42), 0.66f))
        root.addView(directionRow)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val filterToggle = Button(this).apply {
            text = "詳細フィルタ ▼"; textSize = 12.5f
            styleButton(this, Color.rgb(96, 110, 125))
        }
        actionRow.addView(filterToggle, LinearLayout.LayoutParams(0, dp(41), 0.42f).apply { marginEnd = dp(4) })
        actionRow.addView(Button(this).apply {
            text = "高度な配合ルート検索（3世代）"; textSize = 12.5f
            styleButton(this, Color.rgb(88, 86, 214))
            setOnClickListener { showAdvancedRouteSearch(breedSearch.text?.toString().orEmpty()) }
        }, LinearLayout.LayoutParams(0, dp(41), 0.58f))
        root.addView(actionRow, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(3) })

        // v2.8.23: frequently used planning filters are always visible, matching the management page.
        val quickFilters = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, dp(2), 0)
        }
        breedCanMake = CheckBox(this).apply { text = "配合可"; textSize = 12f; setPadding(0,0,0,0) }
        breedCannotMake = CheckBox(this).apply { text = "配合不可"; textSize = 12f; setPadding(0,0,0,0) }
        breedWantedChild = CheckBox(this).apply { text = "★ほしい（子）"; textSize = 11.5f; setPadding(0,0,0,0) }
        quickFilters.addView(breedCanMake, LinearLayout.LayoutParams(0, dp(40), 1f))
        quickFilters.addView(breedCannotMake, LinearLayout.LayoutParams(0, dp(40), 1.12f))
        quickFilters.addView(breedWantedChild, LinearLayout.LayoutParams(0, dp(40), 1.45f))
        root.addView(quickFilters, LinearLayout.LayoutParams(-1, dp(41)))

        val filterPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(5), dp(4), dp(5), dp(5))
            background = roundedBg(Color.rgb(238, 242, 247), 10)
        }
        val searchOptions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        breedMatchMode = makeSpinner(arrayOf("検索:部分一致", "検索:完全一致"))
        breedSortOrder = makeSpinner(arrayOf("昇順", "降順"))
        searchOptions.addView(breedMatchMode, LinearLayout.LayoutParams(0, dp(39), 1f).apply { marginEnd = dp(3) })
        searchOptions.addView(breedSortOrder, LinearLayout.LayoutParams(0, dp(39), 1f).apply { marginStart = dp(3) })
        filterPanel.addView(searchOptions)
        breedSort = makeSpinner(arrayOf("ソート:結果No", "ソート:結果名", "ソート:親No", "ソート:親名", "ソート:配合種別"))
        filterPanel.addView(breedSort, LinearLayout.LayoutParams(-1, dp(39)))
        val f1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        breedType = makeSpinner(arrayOf("配合:すべて", "2体配合", "4体配合"))
        breedRank = makeSpinner(rankItems())
        f1.addView(breedType, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        f1.addView(breedRank, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        filterPanel.addView(f1)
        val f2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        breedFamily = makeSpinner(familyItems())
        breedSize = makeSpinner(sizeItems())
        f2.addView(breedFamily, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3) })
        f2.addView(breedSize, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(3) })
        filterPanel.addView(f2)
        root.addView(filterPanel)
        filterToggle.setOnClickListener {
            val show = filterPanel.visibility != View.VISIBLE
            filterPanel.visibility = if (show) View.VISIBLE else View.GONE
            filterToggle.text = if (show) "詳細フィルタ ▲" else "詳細フィルタ ▼"
        }

        breedList = ListView(this).apply { divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = true }
        breedingAdapter = BreedingAdapter(this)
        breedList.adapter = breedingAdapter
        root.addView(breedList, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        breedSearch.addTextChangedListener(watcher { applyBreedingFilter() })
        breedMatchMode.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSort.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSortOrder.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedDirection.onItemSelectedListener = filterListener {
            breedSearch.hint = if (breedDirection.selectedItemPosition == 0) "モンスター名・図鑑No.で検索" else "親モンスター名・系統条件"
            applyBreedingFilter()
        }
        breedType.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedRank.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedFamily.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedSize.onItemSelectedListener = filterListener { applyBreedingFilter() }
        breedCanMake.setOnCheckedChangeListener { _, _ -> applyBreedingFilter() }
        breedCannotMake.setOnCheckedChangeListener { _, _ -> applyBreedingFilter() }
        breedWantedChild.setOnCheckedChangeListener { _, _ -> applyBreedingFilter() }
        applyBreedingFilter()
    }

    private fun showBreedingForMonster(m: Monster) {
        showBreedingPage(m.name, 0)
    }

    private fun applyBreedingFilter() {
        if (!::breedingAdapter.isInitialized) return
        val q = breedSearch.text?.toString()?.trim().orEmpty()
        val exact = breedMatchMode.selectedItemPosition == 1
        val direction = breedDirection.selectedItemPosition
        val type = breedType.selectedItem?.toString() ?: "配合:すべて"
        val rank = breedRank.selectedItem?.toString() ?: "ランク:すべて"
        val family = breedFamily.selectedItem?.toString() ?: "系統:すべて"
        val size = breedSize.selectedItem?.toString() ?: "サイズ:すべて"

        filteredRecipes.clear()
        filteredRecipes.addAll(recipes.filter { r ->
            val resultMonster = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
            val qOk = if (q.isEmpty()) true else if (direction == 0) {
                textMatches(r.resultName, q, exact) ||
                    (if (exact) r.resultNo?.toString() == q else r.resultNo?.toString()?.contains(q) == true)
            } else {
                r.parents.any { textMatches(it, q, exact) }
            }
            val canMake = recipePlan(r).canBreed
            val availabilityOk = when {
                breedCanMake.isChecked && !breedCannotMake.isChecked -> canMake
                !breedCanMake.isChecked && breedCannotMake.isChecked -> !canMake
                else -> true
            }
            val wantedOk = !breedWantedChild.isChecked || (resultMonster != null && wanted(resultMonster.no) > 0)
            qOk && availabilityOk && wantedOk &&
            (type == "配合:すべて" || r.type == type) &&
            (rank == "ランク:すべて" || resultMonster?.rank == rank || r.resultRank == rank) &&
            (family == "系統:すべて" || resultMonster?.family == family || r.resultFamily == family) &&
            (size == "サイズ:すべて" || resultMonster?.size == size || r.resultSize == size)
        })
        val sortMode = breedSort.selectedItemPosition
        val desc = breedSortOrder.selectedItemPosition == 1
        val comparator = when(sortMode) {
            1 -> compareBy<BreedingRecipe> { it.resultName.lowercase() }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            2 -> compareBy<BreedingRecipe> { firstParentNo(it) }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            3 -> compareBy<BreedingRecipe> { firstParentName(it).lowercase() }.thenBy { it.resultName.lowercase() }
            4 -> compareBy<BreedingRecipe> { it.type }.thenBy { it.resultNo ?: Int.MAX_VALUE }
            else -> compareBy<BreedingRecipe> { it.resultNo ?: Int.MAX_VALUE }.thenBy { it.resultName.lowercase() }
        }
        filteredRecipes.sortWith(if (desc) comparator.reversed() else comparator)
        breedingAdapter.notifyDataSetChanged()
        breedStats.text = "${recipes.size}レシピ / 表示 ${filteredRecipes.size}"
    }

    private fun recipeMissingMonsters(r: BreedingRecipe): List<Monster> {
        val out = mutableListOf<Monster>()
        val needs = linkedMapOf<Int, Pair<Monster, Int>>()
        r.parents.take(4).forEachIndexed { i, name ->
            if (r.parentTypes.getOrNull(i).orEmpty().equals("rule", true)) return@forEachIndexed
            val m = monsterByName[name] ?: return@forEachIndexed
            val need = (needs[m.no]?.second ?: 0) + 1
            needs[m.no] = m to need
        }
        needs.values.forEach { (m, need) -> repeat((need - owned(m)).coerceAtLeast(0)) { out += m } }
        return out
    }

    private fun addRecipeMissingToWanted(r: BreedingRecipe) {
        val missing = recipeMissingMonsters(r)
        if (missing.isEmpty()) {
            Toast.makeText(this, "不足している具体的な素材はありません", Toast.LENGTH_SHORT).show()
            return
        }
        val grouped = missing.groupingBy { it.no }.eachCount()
        grouped.forEach { (no, need) -> if (wanted(no) < need) setWanted(no, need) }
        breedingAdapter.notifyDataSetChanged()
        Toast.makeText(this, "不足素材 ${grouped.size}種類を★ほしいに追加しました", Toast.LENGTH_SHORT).show()
    }

    private inner class BreedingAdapter(context: Context) : BaseAdapter() {
        override fun getCount() = filteredRecipes.size
        override fun getItem(position: Int) = filteredRecipes[position]
        override fun getItemId(position: Int) = getItem(position).id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = getItem(position)
            val expanded = expandedRecipeIds.contains(r.id)
            val plan = recipePlan(r)
            val outer = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(4), dp(3), dp(4))
            }
            val cardBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (plan.canBreed) ownedCardBg else Color.WHITE)
                    cornerRadius = dp(12).toFloat()
                    val resultNo = r.resultNo ?: monsterByName[r.resultName]?.no
                    if (resultNo != null && wanted(resultNo) > 0) setStroke(dp(2), Color.rgb(235, 177, 45))
                }
                elevation = dp(1).toFloat()
            }

            val result = r.resultNo?.let { n -> monsters.firstOrNull { it.no == n } } ?: monsterByName[r.resultName]
            val header = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            if (result != null) {
                val frame = FrameLayout(this@MainActivity)
                val iv = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
                val fb = TextView(this@MainActivity).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = roundedBg(Color.rgb(96,125,139), 8) }
                frame.addView(iv, FrameLayout.LayoutParams(dp(48), dp(48)))
                frame.addView(fb, FrameLayout.LayoutParams(dp(48), dp(48)))
                applyMonsterIcon(iv, fb, result)
                frame.isClickable = true
                frame.contentDescription = "${result.name}を管理表で見る"
                frame.setOnClickListener { jumpFromBreedingToManagement(result) }
                header.addView(frame, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) })
            }
            val resultInfo = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                if (result != null) setOnClickListener { jumpFromBreedingToManagement(result) }
            }
            resultInfo.addView(TextView(this@MainActivity).apply {
                text = "${r.resultNo?.let { String.format("No.%03d", it) } ?: "No.---"}  ${result?.name ?: r.resultName}"
                textSize = 15.5f; setTextColor(textMain); setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            resultInfo.addView(TextView(this@MainActivity).apply {
                text = if (result != null) "${result.rank} / ${result.family} / ${result.size}　[${r.type}]" else "[${r.type}]"
                textSize = 12f; setTextColor(textSub)
            })
            header.addView(resultInfo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (result != null) {
                header.addView(TextView(this@MainActivity).apply {
                    text = "子 ★${wanted(result.no)}"; textSize = 10.5f; gravity = Gravity.CENTER
                    setTextColor(Color.rgb(166, 104, 0)); background = roundedBg(Color.rgb(255, 244, 204), 9)
                    setPadding(dp(6), dp(3), dp(6), dp(3))
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)).apply { marginEnd = dp(5) })
            }
            header.addView(TextView(this@MainActivity).apply {
                text = if (plan.canBreed) "配合可" else "素材不足 ${plan.missingLabels.size}"
                textSize = 10.5f; gravity = Gravity.CENTER
                setTextColor(if (plan.canBreed) Color.rgb(0, 110, 75) else Color.rgb(178, 102, 0))
                background = roundedBg(if (plan.canBreed) Color.rgb(224, 247, 239) else Color.rgb(255, 244, 214), 9)
                setPadding(dp(5), dp(3), dp(5), dp(3))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)).apply { marginEnd = dp(4) })
            header.addView(TextView(this@MainActivity).apply {
                text = if (expanded) "▲" else "▼"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(textSub)
            }, LinearLayout.LayoutParams(dp(32), dp(38)))
            cardBox.addView(header)

            val materialRow = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(2)) }
            r.parents.take(4).forEachIndexed { index, name ->
                if (index > 0) materialRow.addView(TextView(this@MainActivity).apply {
                    text = "×"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(textMain)
                }, LinearLayout.LayoutParams(dp(24), dp(58)))
                materialRow.addView(makeRecipeMaterialMini(name, expanded), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            cardBox.addView(materialRow)
            postBreedingSummary(r, plan)?.let { summary ->
                cardBox.addView(TextView(this@MainActivity).apply {
                    text = summary; textSize = 10.5f; setTextColor(Color.rgb(55, 95, 130)); gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(5), dp(3), dp(5), dp(2))
                })
            }

            if (expanded) {
                cardBox.addView(View(this@MainActivity).apply { setBackgroundColor(divider) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(6) })
                r.parents.distinct().forEach { name ->
                    val pm = monsterByName[name] ?: return@forEach
                    val line = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    line.addView(TextView(this@MainActivity).apply {
                        text = "${String.format("No.%03d", pm.no)} ${pm.name}　所持${owned(pm)}"
                        textSize = 12.5f; setTextColor(textMain)
                    }, LinearLayout.LayoutParams(0, dp(36), 1f))
                    line.addView(TextView(this@MainActivity).apply {
                        text = "★ ${wanted(pm.no)}"; textSize = 12f; gravity = Gravity.CENTER
                        setTextColor(Color.rgb(166,104,0)); background = roundedBg(Color.rgb(255,244,204), 8)
                    }, LinearLayout.LayoutParams(dp(56), dp(31)))
                    line.addView(Button(this@MainActivity).apply { text="−"; textSize=18f; styleCountButton(this, Color.rgb(220,70,80)); setOnClickListener { changeWanted(pm,-1); notifyDataSetChanged() } }, LinearLayout.LayoutParams(dp(32), dp(31)).apply { marginStart=dp(2) })
                    line.addView(Button(this@MainActivity).apply { text="+"; textSize=18f; styleCountButton(this, primary); setOnClickListener { changeWanted(pm,1); notifyDataSetChanged() } }, LinearLayout.LayoutParams(dp(32), dp(31)).apply { marginStart=dp(2) })
                    cardBox.addView(line)
                }
                val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                actions.addView(Button(this@MainActivity).apply {
                    text = "不足素材を★ほしいに追加"; textSize = 12.5f; styleButton(this, Color.rgb(0, 150, 110))
                    setOnClickListener { addRecipeMissingToWanted(r) }
                }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin=dp(5) })
                val parentSearch = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
                r.parents.distinct().take(2).forEachIndexed { i, name ->
                    parentSearch.addView(Button(this@MainActivity).apply {
                        text = "$name から子を検索 ＞"; textSize = 11f
                        setOnClickListener { showBreedingPage(name, 1) }
                    }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { if (i==0) marginEnd=dp(2) else marginStart=dp(2) })
                }
                actions.addView(parentSearch)
                actions.addView(Button(this@MainActivity).apply {
                    text = "高度な配合ルートを見る（3世代）"; textSize = 12f
                    styleButton(this, Color.rgb(88,86,214)); setOnClickListener { showAdvancedRoutesFor(r.resultName, 3) }
                }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin=dp(3) })
                cardBox.addView(actions)
            }
            cardBox.setOnClickListener {
                if (expandedRecipeIds.contains(r.id)) expandedRecipeIds.remove(r.id) else expandedRecipeIds.add(r.id)
                notifyDataSetChanged()
            }
            outer.addView(cardBox)
            return outer
        }

        private fun makeRecipeMaterialMini(name: String, expanded: Boolean): View {
            val m = monsterByName[name]
            val box = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(2), dp(2), dp(2)) }
            if (m != null) {
                val frame = FrameLayout(this@MainActivity)
                val iv = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
                val fb = TextView(this@MainActivity).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = roundedBg(Color.rgb(96,125,139), 7) }
                val sz = if (expanded) 46 else 40
                frame.addView(iv, FrameLayout.LayoutParams(dp(sz), dp(sz)))
                frame.addView(fb, FrameLayout.LayoutParams(dp(sz), dp(sz)))
                applyMonsterIcon(iv, fb, m)
                box.addView(frame, LinearLayout.LayoutParams(dp(sz), dp(sz)))
                box.addView(TextView(this@MainActivity).apply {
                    text = m.name; textSize = if (expanded) 11.5f else 10.5f; gravity = Gravity.CENTER; maxLines = 1; setTextColor(textMain)
                })
                box.addView(TextView(this@MainActivity).apply {
                    text = if (owned(m) > 0) "✓ 所持 ${owned(m)}" else "× 未所持"
                    textSize = 10f; gravity = Gravity.CENTER
                    setTextColor(if (owned(m)>0) Color.rgb(35,105,210) else Color.rgb(210,65,75))
                })
                box.addView(TextView(this@MainActivity).apply {
                    text = "★${wanted(m.no)}"; textSize = 10f; gravity = Gravity.CENTER
                    setTextColor(Color.rgb(166,104,0))
                })
                box.isClickable = true
                box.contentDescription = "${m.name}を管理表で見る"
                box.setOnClickListener { jumpFromBreedingToManagement(m) }
            } else {
                val family = name.removeSuffix("モンスター").removeSuffix("系").trim()
                val isFamilyRule = name.contains("系") && family in listOf("スライム","ドラゴン","自然","魔獣","物質","悪魔","ゾンビ","？？？","???")
                if (isFamilyRule) {
                    val sz = if (expanded) 46 else 40
                    box.addView(ImageView(this@MainActivity).apply {
                        setImageResource(familyIconRes(family))
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        contentDescription = "$family 系統アイコン"
                    }, LinearLayout.LayoutParams(dp(sz), dp(sz)))
                    box.addView(TextView(this@MainActivity).apply {
                        text = "条件"; textSize = 9.5f; gravity = Gravity.CENTER; setTextColor(textSub)
                    })
                    box.addView(TextView(this@MainActivity).apply {
                        text = "${family}系モンスター"; textSize = if (expanded) 11.5f else 10.5f; gravity = Gravity.CENTER; maxLines = 1; setTextColor(textMain)
                    })
                    box.addView(TextView(this@MainActivity).apply {
                        text = "★—"; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.rgb(166,104,0))
                    })
                } else {
                    box.addView(TextView(this@MainActivity).apply {
                        text = "条件\n$name"; textSize = 10.5f; gravity = Gravity.CENTER; maxLines = 2; setTextColor(textSub)
                        background = roundedBg(Color.rgb(245,247,250), 8); setPadding(dp(4),dp(5),dp(4),dp(5))
                    })
                }
            }
            return box
        }
    }

    private fun showRecipeDetail(r: BreedingRecipe) {
        // v2.8.12: detail popup is intentionally replaced by inline expandable cards.
        if (expandedRecipeIds.contains(r.id)) expandedRecipeIds.remove(r.id) else expandedRecipeIds.add(r.id)
        if (::breedingAdapter.isInitialized) breedingAdapter.notifyDataSetChanged()
    }


    // ---------------- Advanced breeding route search v2.8.9 tree UI + route dedupe ----------------

    private fun showAdvancedRouteSearch(rawQuery: String) {
        val q = rawQuery.trim()
        if (q.isBlank()) {
            Toast.makeText(this, "作りたいモンスター名または図鑑No.を入力してください", Toast.LENGTH_LONG).show()
            return
        }

        val no = Regex("\\d+").find(q)?.value?.toIntOrNull()
        val exactByNo = no?.let { n -> monsters.firstOrNull { it.no == n } }
        val exactByName = monsterByName[q]
        val candidates = when {
            exactByNo != null -> listOf(exactByNo)
            exactByName != null -> listOf(exactByName)
            else -> monsters.filter { it.name.contains(q, ignoreCase = true) }
                .filter { m -> recipes.any { it.resultName == m.name } }
                .take(40)
        }

        if (candidates.isEmpty()) {
            Toast.makeText(this, "配合ルートを検索できるモンスターが見つかりません", Toast.LENGTH_LONG).show()
            return
        }
        if (candidates.size == 1) {
            showAdvancedRoutesFor(candidates.first().name, 3)
            return
        }

        AlertDialog.Builder(this)
            .setTitle("高度な配合ルート：対象を選択")
            .setItems(candidates.map { String.format("No.%03d  %s", it.no, it.name) }.toTypedArray()) { _, which ->
                showAdvancedRoutesFor(candidates[which].name, 3)
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showAdvancedRoutesFor(targetName: String, generations: Int = 3) {
        val plans = buildAdvancedRoutePlans(targetName, generations, 16)
        if (plans.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("高度な配合ルート")
                .setMessage("$targetName の配合レシピが見つかりませんでした。")
                .setPositiveButton("閉じる", null)
                .show()
            return
        }

        val target = monsterByName[targetName]
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }
        box.addView(TextView(this).apply {
            text = buildString {
                append(target?.let { String.format("No.%03d  %s", it.no, it.name) } ?: targetName)
                append("\n検索深度: ${generations}世代（目的 → 親 → 祖父母）")
                append("\n所持済み素材を優先して候補を表示")
                append("\n※各アイコンをタップすると★ほしい+1")
            }
            textSize = 15f
            setTextColor(textSub)
            setPadding(dp(4), dp(2), dp(4), dp(10))
        })

        plans.forEachIndexed { index, plan ->
            val totalLeaves = plan.ownedLeaves + plan.missingLeaves
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = roundedBg(if (index % 2 == 0) primarySoft else Color.WHITE, 11)
                elevation = dp(1).toFloat()
            }
            card.addView(TextView(this).apply {
                text = "候補 ${index + 1}   所持 ${plan.ownedLeaves}/$totalLeaves   未所持 ${plan.missingLeaves}   配合 ${plan.steps}回"
                textSize = 15f
                setTextColor(textMain)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            card.addView(buildBreedingTreeView(plan.root), LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            })
            val missing = missingLeafRequirements(plan.root)
            if (missing.isNotEmpty()) {
                card.addView(Button(this).apply {
                    text = "★ このルートの未所持素材をすべて追加"
                    textSize = 12f
                    styleButton(this, Color.rgb(245, 158, 11))
                    setOnClickListener {
                        missing.forEach { (no, required) -> if (wanted(no) < required) setWanted(no, required) }
                        if (::monsterAdapter.isInitialized) { monsterAdapter.notifyDataSetChanged(); applyManagementFilter() }
                        Toast.makeText(this@MainActivity, "未所持素材 ${missing.size}種類を★ほしいに反映しました", Toast.LENGTH_LONG).show()
                    }
                }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(8) })
            }
            box.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            })
        }

        if (plans.size >= 16) {
            box.addView(TextView(this).apply {
                text = "※候補数が多いため、所持状況と必要素材数を基準に上位16件を表示しています。"
                textSize = 12f
                setTextColor(textSub)
                setPadding(dp(4), dp(2), dp(4), dp(4))
            })
        }

        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("高度な配合ルート")
            .setView(scroll)
            .setNegativeButton("閉じる", null)
            .setPositiveButton("通常の配合表で見る") { _, _ -> showBreedingPage(targetName, 0) }
            .show()
    }

    private fun buildBreedingTreeView(root: RouteNode): View {
        val outer = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isFillViewport = true
        }
        val tree = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2), dp(2), dp(2), dp(4))
        }

        fun nodeView(node: RouteNode, compact: Boolean): View {
            val m = monsterByName[node.name]
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(2), dp(2), dp(2))
            }
            box.addView(TextView(this).apply {
                text = m?.let { "No.${it.no.toString().padStart(3, '0')}" } ?: if (node.isRule) "条件" else "No.--"
                textSize = if (compact) 9f else 10f
                setTextColor(textSub)
                gravity = Gravity.CENTER
                maxLines = 1
            }, LinearLayout.LayoutParams(-1, dp(if (compact) 15 else 17)))
            box.addView(TextView(this).apply {
                text = m?.name ?: node.name
                textSize = if (compact) 9f else 10f
                setTextColor(textMain)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(-1, dp(if (compact) 30 else 34)))

            val iconSize = dp(if (compact) 44 else 52)
            val iconFrame = android.widget.FrameLayout(this).apply {
                background = roundedBg(if (node.isOwned) primarySoft else Color.rgb(244, 246, 248), 7)
            }
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            var iconSet = false
            if (m != null) {
                val f = monsterIconFile(m.no)
                if (f.isFile) BitmapFactory.decodeFile(f.absolutePath)?.let { iv.setImageBitmap(it); iconSet = true }
            }
            if (!iconSet && node.isRule) {
                val family = node.name.removeSuffix("モンスター").removeSuffix("系").trim()
                val res = familyIconRes(family)
                if (res != 0) { iv.setImageResource(res); iv.scaleType = ImageView.ScaleType.FIT_CENTER; iconSet = true }
            }
            if (iconSet) iconFrame.addView(iv, android.widget.FrameLayout.LayoutParams(-1, -1))
            else iconFrame.addView(TextView(this).apply {
                text = if (node.isRule) "条件" else "?"
                textSize = if (compact) 11f else 14f
                setTextColor(textSub); gravity = Gravity.CENTER
            }, android.widget.FrameLayout.LayoutParams(-1, -1))
            if (node.isOwned) iconFrame.addView(TextView(this).apply {
                text = "✓"; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = roundedBg(primary, 10)
            }, android.widget.FrameLayout.LayoutParams(dp(20), dp(20), Gravity.TOP or Gravity.END))
            if (m != null) {
                val w = wanted(m.no)
                if (w > 0) iconFrame.addView(TextView(this).apply {
                    text = "★$w"; textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    background = roundedBg(Color.rgb(245, 158, 11), 9)
                }, android.widget.FrameLayout.LayoutParams(dp(28), dp(18), Gravity.BOTTOM or Gravity.START))
                iconFrame.setOnClickListener { changeWanted(m, 1, true) }
            }
            box.addView(iconFrame, LinearLayout.LayoutParams(iconSize, iconSize))
            return box
        }

        fun generationRow(nodes: List<RouteNode>, compact: Boolean): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                nodes.forEach { n ->
                    addView(nodeView(n, compact), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
            }
        }

        // v2.8.10: 2体配合だけでなく4体配合も、表示上で親を欠落させず全員描画する。
        // さらに各親が4体配合で作られる場合も、その祖父母を全員表示する。
        val parents = root.children
        val fallbackParent = RouteNode("—", terminalNote = "親情報なし")
        val shownParents = if (parents.isEmpty()) listOf(fallbackParent) else parents
        val grandparentGroups = shownParents.map { parent ->
            if (parent.children.isEmpty()) {
                listOf(
                    RouteNode("—", terminalNote = "この世代では展開なし"),
                    RouteNode("—", terminalNote = "この世代では展開なし")
                )
            } else parent.children
        }
        val groupWidths = grandparentGroups.map { kids ->
            // 祖父母1体あたり約64dpを確保。4体配合でもアイコンを潰さず横スクロールで見せる。
            maxOf(dp(138), dp(64) * kids.size)
        }
        val contentWidth = maxOf(dp(330), groupWidths.sum())
        tree.minimumWidth = contentWidth

        tree.addView(TextView(this).apply {
            text = "祖父母"
            textSize = 10f
            setTextColor(textSub)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))

        val grandparentsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        }
        grandparentGroups.forEachIndexed { i, kids ->
            grandparentsRow.addView(generationRow(kids, true), LinearLayout.LayoutParams(groupWidths[i], ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        tree.addView(grandparentsRow, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))

        val grandConnectors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        grandparentGroups.forEachIndexed { i, kids ->
            val connector = when (kids.size) {
                0, 1 -> "│"
                2 -> "└───┬───┘"
                3 -> "└─┬─┬─┘"
                4 -> "└─┬─┬─┬─┘"
                else -> "└──┬──┘"
            }
            grandConnectors.addView(TextView(this).apply {
                text = connector
                textSize = 12f
                setTextColor(textSub)
                gravity = Gravity.CENTER
                typeface = android.graphics.Typeface.MONOSPACE
            }, LinearLayout.LayoutParams(groupWidths[i], dp(20)))
        }
        tree.addView(grandConnectors, LinearLayout.LayoutParams(contentWidth, dp(20)))

        tree.addView(TextView(this).apply {
            text = if (shownParents.size > 2) "親（${shownParents.size}体配合）" else "親"
            textSize = 10f
            setTextColor(textSub)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))

        val parentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        shownParents.forEachIndexed { i, n ->
            parentRow.addView(nodeView(n, false), LinearLayout.LayoutParams(groupWidths[i], ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        tree.addView(parentRow, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))

        tree.addView(TextView(this).apply {
            text = when (shownParents.size) {
                1 -> "│"
                2 -> "└────────┬────────┘"
                3 -> "└────┬────┬────┘"
                4 -> "└───┬───┬───┬───┘"
                else -> "└──────┬──────┘"
            }
            textSize = 12f
            setTextColor(textSub)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.MONOSPACE
        }, LinearLayout.LayoutParams(contentWidth, dp(20)))

        tree.addView(TextView(this).apply {
            text = "子"
            textSize = 10f
            setTextColor(textSub)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))
        val childWrap = LinearLayout(this).apply { gravity = Gravity.CENTER }
        childWrap.addView(nodeView(root, false), LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
        tree.addView(childWrap, LinearLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))

        outer.addView(tree, android.widget.FrameLayout.LayoutParams(contentWidth, ViewGroup.LayoutParams.WRAP_CONTENT))
        return outer
    }

    private fun buildAdvancedRoutePlans(targetName: String, generations: Int, maxPlans: Int): List<RoutePlan> {
        val directRecipes = recipes.filter { it.resultName == targetName }
        if (directRecipes.isEmpty()) return emptyList()
        val roots = mutableListOf<RouteNode>()
        directRecipes.forEach { recipe ->
            val childOptionLists = recipe.parents.mapIndexed { i, parent ->
                val parentType = recipe.parentTypes.getOrNull(i).orEmpty()
                buildRouteNodeOptions(parent, parentType, 2, generations, setOf(targetName), 10)
            }
            combineRouteOptions(childOptionLists, 24).forEach { children ->
                roots += RouteNode(targetName, recipe = recipe, children = children)
            }
        }
        return roots.map { root ->
            val metrics = routeMetrics(root)
            RoutePlan(root, metrics.first, metrics.second, metrics.third)
        }
            // v2.8.9: 同じ完成ツリーを1件にまとめる。
            // 親A×親B と 親B×親A のような左右入れ替えも同一ルートとして扱う。
            .distinctBy { visibleRouteKey(it.root) }
            .sortedWith(
                compareBy<RoutePlan> { it.missingLeaves }
                    .thenByDescending { it.ownedLeaves }
                    .thenBy { it.steps }
                    .thenBy { canonicalRouteKey(it.root) }
            ).take(maxPlans)
    }

    /**
     * v2.8.10: 実際に3世代ツリーへ表示される内容だけから作る重複判定キー。
     * 2体/4体配合の全親と、その各親の全祖父母を含める。左右順は同一扱い。
     */
    private fun visibleRouteKey(root: RouteNode): String {
        fun nodeId(n: RouteNode): String = (if (n.isRule) "R:" else "M:") + n.name.trim()
        val parentBranches = root.children.map { parent ->
            val grandparents = parent.children.map { nodeId(it) }.sorted().joinToString("+")
            "${nodeId(parent)}[$grandparents]"
        }.sorted()
        return "${nodeId(root)}(${parentBranches.joinToString("|")})"
    }

    /**
     * 配合ルートの表示上の同一性を判定するための正規化キー。
     * レシピIDや親の左右順には依存せず、各世代のモンスター/条件と子構成だけで判定する。
     */
    private fun canonicalRouteKey(node: RouteNode): String {
        val kind = if (node.isRule) "RULE" else "MONSTER"
        val self = "$kind:${node.name.trim()}"
        if (node.children.isEmpty()) return self
        val children = node.children.map { canonicalRouteKey(it) }.sorted()
        return "$self(${children.joinToString("|")})"
    }

    private fun buildRouteNodeOptions(
        name: String,
        parentType: String,
        level: Int,
        maxGenerations: Int,
        path: Set<String>,
        maxOptions: Int
    ): List<RouteNode> {
        val isRule = parentType.equals("rule", ignoreCase = true) || monsterByName[name] == null
        if (isRule) {
            val ownedRule = ownedMonsterForRule(name)
            return listOf(RouteNode(
                name = name,
                isOwned = ownedRule != null,
                isRule = true,
                terminalNote = ownedRule?.let { "所持候補: ${it.name}" } ?: "条件を満たすモンスターが必要"
            ))
        }

        // v2.8.10: 目的→親→祖父母…の同一枝で同じモンスターが再登場したら、
        // 「停止ノード」として残すのではなく、その候補ルート自体を除外する。
        if (name in path) return emptyList()

        val monster = monsterByName[name]
        if (monster != null && owned(monster) > 0) {
            return listOf(RouteNode(name = name, isOwned = true, terminalNote = "所持済み ${owned(monster)}体"))
        }
        if (level >= maxGenerations) {
            return listOf(RouteNode(name = name, terminalNote = "この世代では素材として扱う"))
        }

        val options = recipes.filter { it.resultName == name }
            .sortedWith(compareByDescending<BreedingRecipe> { immediateOwnedScore(it) }.thenBy { it.parents.size }.thenBy { it.id })
            .take(5)
        if (options.isEmpty()) {
            return listOf(RouteNode(name = name, terminalNote = "配合表に作成レシピなし"))
        }

        val out = mutableListOf<RouteNode>()
        options.forEach { recipe ->
            val childLists = recipe.parents.mapIndexed { i, child ->
                buildRouteNodeOptions(
                    child,
                    recipe.parentTypes.getOrNull(i).orEmpty(),
                    level + 1,
                    maxGenerations,
                    path + name,
                    maxOptions
                )
            }
            combineRouteOptions(childLists, maxOptions).forEach { children ->
                if (out.size < maxOptions) out += RouteNode(name, recipe = recipe, children = children)
            }
        }
        return out.take(maxOptions)
    }

    private fun combineRouteOptions(lists: List<List<RouteNode>>, limit: Int): List<List<RouteNode>> {
        if (lists.isEmpty()) return listOf(emptyList())
        // 循環検出などで1枝でも候補なしになったレシピは、ルート全体を不成立として除外。
        if (lists.any { it.isEmpty() }) return emptyList()
        var acc: List<List<RouteNode>> = listOf(emptyList())
        for (list in lists) {
            val next = ArrayList<List<RouteNode>>()
            for (prefix in acc) {
                for (node in list) {
                    next += prefix + node
                    if (next.size >= limit) break
                }
                if (next.size >= limit) break
            }
            acc = next
            if (acc.isEmpty()) break
        }
        return acc.take(limit)
    }

    private fun immediateOwnedScore(recipe: BreedingRecipe): Int {
        var score = 0
        recipe.parents.forEachIndexed { i, name ->
            val type = recipe.parentTypes.getOrNull(i).orEmpty()
            if (type.equals("rule", ignoreCase = true)) {
                if (ownedMonsterForRule(name) != null) score++
            } else {
                val m = monsterByName[name]
                if (m != null && owned(m) > 0) score++
            }
        }
        return score
    }

    private fun ownedMonsterForRule(rule: String): Monster? {
        val family = rule.removeSuffix("モンスター").removeSuffix("系").trim()
        if (family.isBlank()) return null
        return monsters.firstOrNull { it.family == family && owned(it) > 0 }
    }

    private fun routeMetrics(node: RouteNode): Triple<Int, Int, Int> {
        if (node.recipe == null || node.children.isEmpty()) {
            return if (node.isOwned) Triple(1, 0, 0) else Triple(0, 1, 0)
        }
        var ownedLeaves = 0
        var missingLeaves = 0
        var steps = 1
        node.children.forEach { child ->
            val m = routeMetrics(child)
            ownedLeaves += m.first
            missingLeaves += m.second
            steps += m.third
        }
        return Triple(ownedLeaves, missingLeaves, steps)
    }

    private fun missingLeafRequirements(root: RouteNode): Map<Int, Int> {
        val counts = linkedMapOf<Int, Int>()
        fun walk(node: RouteNode) {
            if (node.recipe == null || node.children.isEmpty()) {
                val m = monsterByName[node.name]
                if (m != null && !node.isRule && !node.isOwned) counts[m.no] = (counts[m.no] ?: 0) + 1
                return
            }
            node.children.forEach(::walk)
        }
        walk(root)
        return counts
    }

    private fun renderAdvancedRoute(root: RouteNode): String {
        val sb = StringBuilder()
        fun noText(name: String): String {
            val m = monsterByName[name]
            return m?.let { String.format("No.%03d %s", it.no, it.name) } ?: name
        }
        fun appendNode(node: RouteNode, depth: Int, last: Boolean) {
            val indent = if (depth == 0) "" else "   ".repeat((depth - 1).coerceAtLeast(0)) + if (last) "└─ " else "├─ "
            val generationLabel = when (depth) {
                0 -> "目的"
                1 -> "親"
                2 -> "祖父母"
                else -> "${depth + 1}世代"
            }
            sb.append(indent).append(generationLabel).append(" ").append(noText(node.name))
            if (depth == 0 && node.recipe != null) sb.append("  [").append(node.recipe.type).append("]")
            when {
                node.isOwned -> sb.append("  ✓ ").append(node.terminalNote)
                node.isRule -> sb.append("  [条件] ").append(node.terminalNote)
                node.recipe != null && depth > 0 -> sb.append("  ← ").append(node.recipe.type)
                node.recipe == null && node.terminalNote.isNotBlank() -> sb.append("  △ ").append(node.terminalNote)
            }
            sb.append('\n')
            node.children.forEachIndexed { i, child -> appendNode(child, depth + 1, i == node.children.lastIndex) }
        }
        appendNode(root, 0, true)
        return sb.toString().trimEnd()
    }

    // ---------------- Memo / backup ----------------

    private fun editMemo(m: Monster) {
        val input = EditText(this).apply {
            setSingleLine(false); minLines=2; maxLines=5; setText(notes[m.no].orEmpty()); setSelection(text.length)
        }
        val container = FrameLayout(this).apply {
            setPadding(dp(16),0,dp(16),0)
            addView(input, FrameLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this).setTitle("No.${m.no} ${m.name} のメモ").setView(container)
            .setNegativeButton("キャンセル",null)
            .setPositiveButton("保存") { _,_ ->
                notes[m.no]=input.text.toString()
                pref.edit().putString("note${m.no}",notes[m.no].orEmpty()).apply()
            }.show()
    }

    private fun buildStateJson(): String {
        val arr = JSONArray()
        monsters.forEach { m ->
            arr.put(JSONObject().apply {
                put("no", m.no)
                put("male", male(m.no))
                put("female", female(m.no))
                put("both", both(m.no))
                put("favorite", favorites[m.no] ?: false)
                put("wanted", wanted(m.no))
                put("note", notes[m.no].orEmpty())
            })
        }
        return arr.toString()
    }

    private fun applyStateJson(text: String) {
        val arr = JSONArray(text)
        val e = pref.edit()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val no = o.getInt("no")
            if (no !in 1..659) continue
            val mv = o.optInt("male", 0).coerceAtLeast(0)
            val fv = o.optInt("female", 0).coerceAtLeast(0)
            val bv = o.optInt("both", 0).coerceAtLeast(0)
            val n = o.optString("note", "")
            val fav = o.optBoolean("favorite", false)
            val want = o.optInt("wanted", 0).coerceAtLeast(0)
            maleCounts[no] = mv
            femaleCounts[no] = fv
            bothCounts[no] = bv
            notes[no] = n
            favorites[no] = fav
            wantedCounts[no] = want
            e.putInt("m$no", mv).putInt("f$no", fv).putInt("b$no", bv)
                .putString("note$no", n).putBoolean("fav$no", fav).putInt("want$no", want)
        }
        e.apply()
        if (::monsterAdapter.isInitialized) applyManagementFilter()
    }

    private fun startFullBackup() {
        AlertDialog.Builder(this)
            .setTitle("完全バックアップ")
            .setMessage("所有数・ほしい数・メモ・お気に入り・モンスターデータ修正・表示用モンスター画像・判断用アイコンを、1つのZIPに保存します。\n\nアプリ更新前や機種変更前に保存してください。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("保存先を選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/zip"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_TITLE, "TerrySP_full_backup_v2.8.23.zip")
                }, 1007)
            }.show()
    }

    private fun startFullRestore() {
        AlertDialog.Builder(this)
            .setTitle("完全復元")
            .setMessage("完全バックアップZIPから、所有数・ほしい数・メモ・お気に入り・モンスターデータ修正・表示用画像・判断用アイコンを復元します。\n\n同じ図鑑No.のデータや画像はバックアップ内容で上書きされます。")
            .setNegativeButton("キャンセル", null)
            .setPositiveButton("ZIPを選択") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/zip"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 1008)
            }.show()
    }

    private fun addFileToZip(zip: ZipOutputStream, file: File, entryName: String) {
        if (!file.isFile) return
        zip.putNextEntry(ZipEntry(entryName))
        file.inputStream().buffered().use { input -> input.copyTo(zip) }
        zip.closeEntry()
    }

    private fun writeFullBackupZip(uri: Uri) {
        Toast.makeText(this, "完全バックアップを作成しています…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                contentResolver.openOutputStream(uri)?.buffered()?.use { raw ->
                    ZipOutputStream(raw).use { zip ->
                        val manifest = JSONObject().apply {
                            put("format", "terrysp-full-backup")
                            put("formatVersion", 1)
                            put("appVersion", "2.8.20")
                            put("package", packageName)
                        }.toString(2)
                        zip.putNextEntry(ZipEntry("backup_manifest.json"))
                        zip.write(manifest.toByteArray(StandardCharsets.UTF_8))
                        zip.closeEntry()

                        zip.putNextEntry(ZipEntry("state.json"))
                        zip.write(buildStateJson().toByteArray(StandardCharsets.UTF_8))
                        zip.closeEntry()

                        zip.putNextEntry(ZipEntry("monster_data.json"))
                        zip.write(buildMonsterDataJson().toByteArray(StandardCharsets.UTF_8))
                        zip.closeEntry()

                        val iconDir = File(filesDir, "monster_icons")
                        iconDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach {
                            addFileToZip(zip, it, "monster_icons/${it.name}")
                        }

                        val recognitionRoot = recognitionIconDir()
                        recognitionRoot.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { monsterDir ->
                            monsterDir.listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach { sample ->
                                addFileToZip(zip, sample, "recognition_icons/${monsterDir.name}/${sample.name}")
                            }
                        }
                    }
                } ?: throw IllegalStateException("保存先を開けませんでした")
                runOnUiThread {
                    val stats = recognitionStats()
                    Toast.makeText(this, "完全バックアップを保存しました（判断用 ${stats.first}種類 / ${stats.second}枚）", Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("バックアップに失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun restoreFullBackupZip(uri: Uri) {
        Toast.makeText(this, "完全バックアップを復元しています…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp = File(cacheDir, "full_restore_tmp").apply { deleteRecursively(); mkdirs() }
            try {
                var stateText: String? = null
                var monsterDataText: String? = null
                var manifestOk = false
                var totalBytes = 0L
                var restoredIcons = 0
                var restoredRecognition = 0
                contentResolver.openInputStream(uri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            if (entry.isDirectory) { zip.closeEntry(); continue }
                            val name = entry.name.replace('\\', '/')
                            if (name.startsWith("/") || name.contains("../")) throw IllegalArgumentException("不正なZIPパスです")
                            val out = java.io.ByteArrayOutputStream()
                            val buf = ByteArray(8192)
                            var entryBytes = 0L
                            while (true) {
                                val n = zip.read(buf)
                                if (n <= 0) break
                                entryBytes += n
                                totalBytes += n
                                if (entryBytes > 16L * 1024 * 1024 || totalBytes > 256L * 1024 * 1024) {
                                    throw IllegalArgumentException("バックアップZIPが大きすぎます")
                                }
                                out.write(buf, 0, n)
                            }
                            val bytes = out.toByteArray()
                            when {
                                name == "backup_manifest.json" -> {
                                    val m = JSONObject(String(bytes, StandardCharsets.UTF_8))
                                    manifestOk = m.optString("format") == "terrysp-full-backup" && m.optInt("formatVersion", 0) == 1
                                }
                                name == "state.json" -> stateText = String(bytes, StandardCharsets.UTF_8)
                                name == "monster_data.json" -> monsterDataText = String(bytes, StandardCharsets.UTF_8)
                                Regex("^monster_icons/monster_\\d{3}\\.img$").matches(name) -> {
                                    val f = File(tmp, name).apply { parentFile?.mkdirs() }
                                    f.writeBytes(bytes); restoredIcons++
                                }
                                Regex("^recognition_icons/\\d{3}/[A-Za-z0-9_.-]+$").matches(name) -> {
                                    val f = File(tmp, name).apply { parentFile?.mkdirs() }
                                    f.writeBytes(bytes); restoredRecognition++
                                }
                            }
                            zip.closeEntry()
                        }
                    }
                } ?: throw IllegalStateException("ZIPを開けませんでした")

                if (!manifestOk) throw IllegalArgumentException("テリワンSP完全バックアップZIPではありません")
                val state = stateText ?: throw IllegalArgumentException("state.jsonがありません")
                JSONArray(state) // validate before changing app data
                monsterDataText?.let { JSONArray(it) }

                val iconDst = File(filesDir, "monster_icons").apply { mkdirs() }
                File(tmp, "monster_icons").listFiles()?.forEach { src -> src.copyTo(File(iconDst, src.name), overwrite = true) }
                val recDst = recognitionIconDir()
                File(tmp, "recognition_icons").listFiles()?.filter { it.isDirectory }?.forEach { srcDir ->
                    val dstDir = File(recDst, srcDir.name).apply { mkdirs() }
                    srcDir.listFiles()?.forEach { src -> src.copyTo(File(dstDir, src.name), overwrite = true) }
                }

                runOnUiThread {
                    applyStateJson(state)
                    monsterDataText?.let { applyMonsterDataJson(it) }
                    if (::monsterAdapter.isInitialized) monsterAdapter.notifyDataSetChanged()
                    val stats = recognitionStats()
                    AlertDialog.Builder(this).setTitle("完全復元が完了しました")
                        .setMessage("管理データを復元しました。\n表示用画像: ${restoredIcons}件\n判断用アイコン: ${restoredRecognition}枚\n\n現在の判断用アイコン: ${stats.first}種類 / ${stats.second}枚")
                        .setPositiveButton("OK") { _, _ -> showSettingsPage() }.show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("完全復元に失敗しました")
                        .setMessage(t.message ?: t::class.java.simpleName).setPositiveButton("OK", null).show()
                }
            } finally {
                try { tmp.deleteRecursively() } catch (_: Throwable) { }
            }
        }.start()
    }

    private fun backup() {
        backupPayload = buildStateJson()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type="application/json"; putExtra(Intent.EXTRA_TITLE,"terrysp_backup.json")
        },1001)
    }

    private fun restore() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="application/json"; addCategory(Intent.CATEGORY_OPENABLE)
        },1002)
    }

    override fun onResume() {
        super.onResume()
        // A finished integrated screen recording is handed back through app-private preferences.
        // Delay slightly so a cold-started Activity can finish building its UI first.
        window.decorView.postDelayed({ consumeRecordedVideoWhenReadyV280(0) }, 250L)
    }

    private fun consumeRecordedVideoWhenReadyV280(attempt: Int) {
        val key = "pending_recorded_video_v277"
        if (pref.getString(key, null) != null) {
            pref.edit().remove("recording_finalize_pending_v280").apply()
            consumeRecordedVideoV277()
            return
        }
        if (pref.getBoolean("recording_finalize_pending_v280", false) && attempt < 16) {
            window.decorView.postDelayed({ consumeRecordedVideoWhenReadyV280(attempt + 1) }, 250L)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1011) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                startIntegratedScreenRecordingV278()
            } else {
                AlertDialog.Builder(this).setTitle("通知の許可が必要です")
                    .setMessage("Android 13では録画中の状態と［録画停止］を分かりやすく表示するため、通知を許可してください。")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if (req == 1012) {
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) startIntegratedScreenRecordingV278()
            else AlertDialog.Builder(this).setTitle("フローティングパネルを表示できません")
                .setMessage("『他のアプリの上に重ねて表示』が許可されていません。")
                .setPositiveButton("OK", null).show()
            return
        }
        if (res != RESULT_OK || data == null) {
            if (req == 1010) {
                try { startService(Intent(this, RecordingOverlayService::class.java).apply { action = RecordingOverlayService.ACTION_SET_WAITING }) } catch (_: Throwable) { }
            }
            if (req == 1003) pendingImageMonsterNo = null
            return
        }
        // Multiple image selection may return only clipData and no data URI.
        if (req != 1005 && req != 1010 && data.data == null) {
            if (req == 1003) pendingImageMonsterNo = null
            return
        }
        try {
            if(req==1010) {
                beginScreenRecordServiceV277(res, data)
            } else if(req==1017) {
                handleMonsterDexScreenshot(data.data!!)
            } else if(req==1020) {
                handleMonsterDexOcrValidationV2816(data.data!!)
            } else if(req==1021) {
                handleMonsterDexOcrUpdateV2822(data.data!!)
            } else if(req==1018) {
                writeMonsterDataBackup(data.data!!)
            } else if(req==1019) {
                restoreMonsterDataBackup(data.data!!)
            } else if(req==1013) {
                writeOwnershipBackup(data.data!!)
            } else if(req==1014) {
                restoreOwnershipBackup(data.data!!)
            } else if(req==1015) {
                writeRecognitionBackup(data.data!!)
            } else if(req==1016) {
                restoreRecognitionBackup(data.data!!)
            } else if(req==1007) {
                writeFullBackupZip(data.data!!)
            } else if(req==1008) {
                restoreFullBackupZip(data.data!!)
            } else if(req==1005) {
                handleTrialScreenshots(data)
            } else if(req==1009) {
                handleTrialVideo(data.data!!)
            } else if(req==1006) {
                importMonsterImagesZip(data.data!!)
            } else if(req==1003) {
                val no = pendingImageMonsterNo
                pendingImageMonsterNo = null
                if (no != null) saveSelectedMonsterImage(data.data!!, no)
            } else if(req==1004) {
                writeMonsterImagesZip(data.data!!)
            } else if(req==1001) {
                contentResolver.openOutputStream(data.data!!)?.use { it.write(backupPayload.toByteArray(StandardCharsets.UTF_8)) }
                Toast.makeText(this,"バックアップを保存しました",Toast.LENGTH_SHORT).show()
            } else if(req==1002) {
                val text=contentResolver.openInputStream(data.data!!)?.bufferedReader()?.readText() ?: return
                applyStateJson(text)
                Toast.makeText(this,"復元しました",Toast.LENGTH_SHORT).show()
            }
        } catch (_:Exception) {
            Toast.makeText(this,"ファイルを読み込めませんでした",Toast.LENGTH_LONG).show()
        }
    }
}
